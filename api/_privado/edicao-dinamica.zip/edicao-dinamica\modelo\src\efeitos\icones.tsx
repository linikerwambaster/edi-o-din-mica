// Ícones vetoriais simples (traço), escolhidos pelo nome no plano: "icone": "grafico"
const P: Record<string, string> = {
  grafico: "M4 20V10M10 20V4M16 20v-7M22 20H2",
  filme: "M3 5h18v14H3zM3 9h18M8 5l-2 4M14 5l-2 4M20 5l-2 4M10 12.5v4l3.5-2z",
  mic: "M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3zM5 11a7 7 0 0 0 14 0M12 18v4M8 22h8",
  terminal: "M3 4h18v16H3zM7 9l3 3-3 3M12 15h5",
  check: "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM7 12l3.5 3.5L17 9",
  relogio: "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM12 6v6l4 2",
  dinheiro: "M2 6h20v12H2zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM6 12h.01M18 12h.01",
  ia: "M12 2l2.2 6.6L21 11l-6.8 2.4L12 20l-2.2-6.6L3 11l6.8-2.4zM19 2v4M17 4h4",
  pessoa: "M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM4 21a8 8 0 0 1 16 0",
  tesoura: "M6 3a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM6 15a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM20 4L8.1 15.9M14.5 14.5L20 20M8.1 8.1L12 12",
  legenda: "M3 5h18v14H3zM7 13h4M13 13h4M7 16h10",
  raio: "M13 2L4 14h7l-1 8 9-12h-7z",
  alvo: "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM12 6a6 6 0 1 0 0 12 6 6 0 0 0 0-12zM12 10a2 2 0 1 0 0 4 2 2 0 0 0 0-4z",
  foguete: "M12 2c4 3 5 8 4 12l-4 3-4-3c-1-4 0-9 4-12zM12 9a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM8 14l-3 3 1 4 3-3M16 14l3 3-1 4-3-3",
  cadeado: "M5 11h14v10H5zM8 11V7a4 4 0 0 1 8 0v4",
  play: "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM10 8v8l6-4z",
  usuarios: "M9 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM2 21a7 7 0 0 1 14 0M17 4a4 4 0 0 1 0 8M22 21a7 7 0 0 0-5-6.7",
  arquivo: "M6 2h9l5 5v15H6zM14 2v6h6M10 6h2M10 9h2M10 12h2M10 15h2",
  pasta: "M3 6h6l2 2h10v11H3z",
  carrinho: "M3 3h2l2.4 12h11l2-8H6.2M9 20a1 1 0 1 0 0 .01M18 20a1 1 0 1 0 0 .01",
};

export const Icone: React.FC<{ nome?: string; tam?: number; cor?: string }> = ({ nome = "check", tam = 56, cor = "#0B2239" }) => (
  <svg width={tam} height={tam} viewBox="0 0 24 24" fill="none" stroke={cor} strokeWidth={2.3} strokeLinecap="round" strokeLinejoin="round">
    <path d={P[nome] ?? P.check} />
  </svg>
);

export const ICONES = Object.keys(P);

// Estrela de 8 raios (marca do Claude) para selos
export const EstrelaClaude: React.FC<{ tam?: number; giro?: number }> = ({ tam = 34, giro = 0 }) => (
  <svg width={tam} height={tam} viewBox="0 0 40 40" style={{ rotate: `${giro}deg` }}>
    {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
      <rect key={i} x={18.6} y={4} width={2.8} height={14} rx={1.4} fill="#D97757" transform={`rotate(${i * 45} 20 20)`} />
    ))}
  </svg>
);
