# Problemas comuns

**`transcrever.mjs` diz que o computador não roda WebGPU**
Atualize o driver da placa de vídeo e o Node.js (18+). Em computadores sem placa compatível, use um modelo menor (`node scripts/transcrever.mjs public/video.mp4 src/dados/palavras.json base pt`) ou transcreva em outro computador e copie o `palavras.json` (formato: `[{"text":"palavra","startMs":0,"endMs":320}]`, tempos do arquivo original).

**Palavras com grafia errada (ex.: "Cloud Code")**
Coloque em `correcoes` no plano: `{"Cloud Code": "Claude Code", "ticked": "ticket"}`.

**Legenda adiantada ou atrasada**
Os tempos vêm da transcrição. Confira com a energia da voz no `roteiro.txt`; se um corte cortou o começo de uma palavra, aumente a margem do corte em 0,05 s.

**Corte cortou uma palavra pela metade**
Use os tempos do `roteiro.txt` (já têm margem). Se precisar, comece o trecho 0,05 s antes.

**Texto atrás da cabeça não aparece atrás**
Precisa do `recorte` cobrindo aquele trecho (comece o recorte ~0,7 s antes) e `"atras": true` no efeito. Confira `"recorte": {"arquivo": "recorte.webm", "inicio": <mesmo início usado no script>}`.

**Vídeo HDR do iPhone ficou estourado ou lavado**
Use o `preparar.mjs` (faz a conversão certa). O ffmpeg precisa ter o filtro `zscale` (Windows: `winget install Gyan.FFmpeg`; Mac: `brew install ffmpeg`).

**Render lento**
Normal: ~4 a 6 min por minuto de vídeo num notebook comum. Para revisar, use quadros parados (`--frames=30,90`) e a amostra de 15 s.

**Licenças**
Remotion é gratuito para pessoas e empresas de até 3 pessoas (empresas maiores precisam de licença em remotion.pro). O modelo de recorte (Robust Video Matting) é GPL-3.0 e é baixado do projeto oficial.
