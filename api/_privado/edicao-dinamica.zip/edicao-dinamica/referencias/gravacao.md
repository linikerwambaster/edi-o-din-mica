# Como gravar para a edição ficar boa (passe isto ao usuário)

1. **Celular em pé (vertical)**, na altura dos olhos, apoiado. 4K ou 1080p, 30 ou 60 fps.
2. **Deixe espaço acima da cabeça.** É ali que os cartões, contadores e textos entram. Rosto no centro ou um pouco abaixo.
3. **Luz de frente** (janela ou luminária na sua frente). Fundo sem bagunça.
4. **Fale e faça pausas à vontade.** Errou? Pare um segundo e repita a frase inteira: a edição fica com a melhor tomada.
5. **"Fale a edição."** Os efeitos acompanham o que você diz. Se quiser algo específico, fale e aponte:
   - "olha a legenda aqui" → a legenda muda naquele momento;
   - "agora uma legenda dinâmica" → a legenda vira o estilo dinâmico;
   - "faz 6 anos que..." → aparece um contador;
   - "olha isso!" → zoom de ênfase.
6. **Não troque o fundo depois.** O fundo real fica mais crível do que qualquer cenário trocado; os efeitos vão por cima e, quando preciso, atrás de você.
7. Termine com a chamada ("toque em saiba mais", "clica no link") olhando para a câmera.
