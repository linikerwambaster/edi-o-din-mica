# Catálogo de efeitos

Todos os campos de tempo (`de`, `ate`, `foco`, `sai`, `trava`, `acende`, `afunda`, `enfase`, `conta`, `chega`, `pulso`, `corte`) são **segundos do vídeo original**.
Campos comuns a todos: `de` (entra), `ate` (sai), `hud` (nome no contador "EDITANDO AO VIVO"), `y` (altura em px, 0 = topo), `atras` (true = desenha atrás da pessoa; precisa de `recorte`), `ocultaLegenda` (true = esconde a legenda enquanto aparece).
Padrão de altura: a faixa `layout.topoLivre` (acima da cabeça). Use `y` para mover.

| tipo | quando a pessoa fala... | campos próprios |
|---|---|---|
| `cartao` | um público, profissão, ferramenta, papel ("você que é gestor") | `texto`, `icone`, `posicao` (esquerda/direita/centro), `foco` (vai pro centro), `selo` (texto do selo no foco, ex.: "PRINCIPALMENTE"), `sai` (sai de lado), `tam` |
| `barra` | progresso, migração, "ainda não fez", antes → depois | `esquerda`, `direita`, `valor` (0–100), `trava` (momento em que trava), `textoTrava` (ex.: "0% MIGRADO"), `acende` (acende o rótulo da direita) |
| `palavra` | uma palavra forte para ficar gigante (com `atras: true` passa atrás da cabeça) | `texto` (use `\n` para 2 linhas), `tam` (padrão 230), `cor`, `afunda` (encolhe e apaga, ex.: "ficar PARA TRÁS"), `ritmo` (quadros entre letras, padrão 1.5; use ~0.5 em frases curtas) |
| `etiqueta` | preço, valor, ticket, custo | `texto`, `sub`, `simbolo` (padrão "R$"), `enfase`, `posicao` |
| `leque` | "muito mais", "vários", "vários vídeos/clientes" | `imagens` (caminhos em `public/`), `texto`, `posicao` |
| `chip` | gancho para o próximo trecho, pergunta, "vou te explicar" | `texto`, `antes` (ex.: "?"), `depois` (ex.: "↓"), `tam` |
| `prompt` | "eu falo/peço/digito para a IA" | `texto` (o pedido, que vai sendo digitado); a onda é a voz real |
| `timeline` | "cortou as pausas", "tirou os erros" | `corte` (momento das tesouradas), `titulo`, `sub`; o tempo removido é calculado dos cortes |
| `vitrine` | "coloca a legenda", "no tempo certo" | mostra as palavras com o tempo exato de cada uma (esconde a legenda normal) |
| `contador` | números ditos ("6 anos", "10 mil") | `inicio`, `fim`, `conta`, `chega`, `rotulo`, `prefixo`, `sufixo`, `digitos`, `posicao` |
| `checklist` | "faz tudo", lista de entregas | `titulo`, `itens` (lista), `passo` (quadros entre itens) |
| `titulo` | frase-tese, promessa do vídeo | `texto`, `destaque` (trecho colorido), `sub`, `selo` ("claude" mostra a estrela) |
| `cta` | chamada final ("toque em saiba mais", "clica no link") | `texto`, `seta`, `pulso` (momento em que pulsa) |
| `zoom` | "olha isso!", ênfase forte | `intensidade` (padrão 0.1 = +10%) |
| `flash` | virada de assunto, "agora...", transição | (só `de`) |
| `brasil` | um dado REAL sobre o Brasil ("7 em cada 10...") | `porcentagem` (parte acesa do mapa), `titulo`, `texto`, `fonte` (obrigatório: de onde veio o dado), `legendaAceso`, `legendaApagado`, `y`. Escurece a tela e desenha o mapa em pontos |
| `segue` | "olha minha mão", "acompanha o movimento" | `pontos`: `[[segundo, x, y], ...]` com x e y de 0 a 1 do quadro ORIGINAL, um a cada 0,25 s; `texto`; `lado` ("cima"/"baixo"). Para achar os pontos: tire quadros com grade (`ffmpeg -ss <início> -i public/video.mp4 -t 7 -vf "fps=4,drawgrid=w=iw/10:h=ih/10:t=1:c=yellow@0.4,tile=7x4" folha.jpg`), olhe e anote o centro da palma |
| `imagem` | cena com foto (modo sem aparecer ou B-roll) | `arquivo`, `modo` ("cheia" ou "quadro"), `movimento` (zoom-in, zoom-out, esquerda, direita), `escurece` (0 a 1), `desfoque` (px), `y` e `largura` no modo quadro. Fica embaixo dos outros efeitos |
| `celular` | "pronto pra postar", mostrar um resultado | `arquivo` (vídeo em public/), `y`, `largura` |
| `rebobinar` | "volta a fita", "agora imagina diferente" | `imagens` (as cenas anteriores, de trás pra frente), `texto` |
| `aberto` | algo sai do enquadre vertical (mãos abertas, objeto ao lado) | só `de`/`ate`. Vídeo HORIZONTAL: a câmera abre para o quadro inteiro (fundo desfocado) e depois volta. Use junto com `segue` quando a mão sai do corte |

Ícones disponíveis (`icone`): grafico, filme, mic, terminal, check, relogio, dinheiro, ia, pessoa, tesoura, legenda, raio, alvo, foguete, cadeado, play, usuarios, arquivo, pasta, carrinho.

## Legenda
- `legenda.estilo`: `"simples"` (frase a frase, branca com contorno; padrão), `"dinamica"` (2–3 palavras grandes, palavra falada em destaque colorido), `"neon"` (palavras em tubo de neon que acendem quando são faladas; cores em `legenda.corNeon` e `legenda.corNeon2`), `"nenhuma"`.
- Demonstração boa: `"nenhuma"` enquanto a pessoa PEDE a legenda e o estilo pedido a partir da resposta ("ela coloca uma legenda").
- `legenda.trechos`: troca o estilo num intervalo (ex.: quando a pessoa diz "agora uma legenda dinâmica").
- Correções de grafia: `correcoes` no plano.

## Ritmo
- Um elemento novo a cada 1–3 s quando a fala justifica. Silêncio visual também é ok por 1–2 s.
- No máximo 2 elementos ao mesmo tempo na faixa de cima, sem cobrir o rosto.
- Elementos saem quando o assunto muda (use `ate` / `sai`).

## Antes e depois (trecho "bruto")
Nos `cortes`, `[início, fim, "bruto"]` mostra a gravação original daquele trecho (inteira, com pausas e erros), com o rótulo "GRAVAÇÃO ORIGINAL / SEM EDIÇÃO", sem legenda, sem efeitos e sem o HUD. O corte seguinte abre da caixa da gravação para o vertical editado. Prepare o arquivo sem tratamento só do trecho (`preparar.mjs ... public/bruto.mp4 --de=.. --ate=..`) e informe `"videoBruto": { "arquivo": "bruto.mp4", "inicio": .. }`. Bom gatilho: "quer ver como eu gravei?", "olha a diferença".

## HUD
`hud.top` muda a altura do contador "EDITANDO AO VIVO" (padrão 96, abaixo da barra dos apps; em vídeo para página/VSL pode subir para 44).

## Escala
Qualquer efeito aceita `"escala"` (ex.: 1.3) para ficar maior em volta da altura `y`. Cuidado com a largura: o que passar de 1080 px é cortado.

## Cartão grande ("palco"), estilo dos Reels de motion
A pessoa vira um CARTÃO grande arredondado na metade de baixo e o motion ocupa a metade de cima. Nada do rosto é cortado: no vídeo em pé o quadro inteiro encolhe e aparece a faixa `palco.foco` ([y0, y1] do quadro, do cabelo ao peito; padrão [60, 1260]); no vídeo deitado aparece o quadro horizontal inteiro, ou com `palco.alturaDeitado` (ex.: 760) um cartão mais alto que corta só as laterais, centrado na pessoa.
- `{ "tipo": "palco", "de": .., "ate": .. }` (opcional `"lado": "cima"`). Use em blocos de 3 a 15 s; alterne com trechos em tela cheia.
- `palco.legendaTop`: altura da legenda enquanto o cartão está na tela (no peito, nunca em cima da boca). Combine com `legenda.estilo: "pequena"` (palavra por palavra, pequena, palavra falada colorida).
- Com o palco, posicione o motion com `y` entre 150 e o topo do cartão.

| tipo | quando usar | campos |
|---|---|---|
| `gancho` | 1º segundo / pergunta forte | `texto` (com `\n`), `destaque`, `sub`, `tam`, `ritmo` (quadros entre palavras) |
| `calendario` | "3 dias", "esperando" | `inicio`, `fim`, `conta`, `chega`, `mes` (topo), `texto`, `rotulo` |
| `etiquetas` | lista de problemas/tarefas citadas | `titulo`, `itens: [{ "texto", "icone", "em", "risca" }]` (`risca` = X vermelho em cima) |
| `apps` | citou Claude/Codex | `itens: [{ "marca": "claude" \| "codex", "em", "texto" }]` |
| `fluxo` | passo a passo (arquivo → Claude → resultado) | `itens: [{ "texto", "icone" ou "marca" (claude, codex, ambos + `em2`), "em" }]` (até 3) |
| `claude` | "joga no Claude Code" | `arquivo`, `solta` (arquivo cai), `digita`, `texto`, `itens` (checklist com `em`) |
| `botao` | CTA "clica aqui" | `texto`, `seta`, `clique` (cursor clica), `cor` |
| `luz` | transição entre assuntos (1 s) | sem campos: um feixe de luz quente atravessa a tela (`cor` opcional). Com `arquivo` (vídeo de luz seu em public/) e `inicio`, usa o vídeo |
| `brasil2` | pesquisa/estatística do Brasil, com palco | `porcentagem`, `inicio`/`fim` ("X DE 10"), `conta`/`chega`, `titulo`, `rotulo`, `texto`, `fonte` |

Sons prontos em `public/sons/` (gerados para a skill, livres para usar): `clique.wav`, `ding.wav`, `whoosh.wav`, `kaching.wav`, `errado.wav`, `papel.wav`, `relogio.wav`, `maquina.wav`. Na transição `luz`: `papel.wav` + `clique.wav`.

Some um clique (`sons/clique.wav`) em cada item que aparece e em cada número da contagem; `errado` quando risca; `kaching` só quando um preço é falado.

## Cada vídeo com uma cara diferente
Não repita o mesmo molde em todos os vídeos da pessoa. Para cada vídeo escolha (e anote no começo da conversa) uma combinação diferente da anterior:
- paleta: `cores.destaque` + `fundo` (ex.: azul-claro `#8FCFEF` em azul-marinho; laranja `#FF8A3D` em preto `#0A0A0C`; verde `#2FBF71` em grafite);
- layout: `palco` embaixo, `palco` em cima (`"lado": "cima"`, motion embaixo, `palco.legendaTop` no peito do cartão) ou mais tela cheia com `janela`;
- legenda: `pequena`, `dinamica`, `simples` ou `neon`;
- transição: `luz` com papel + clique, `flash`, ou cortes secos com whoosh;
- motion: troque quais componentes contam a história (calendário x número, etiquetas x fluxo, tela do Claude x prompt).
Os requisitos continuam os mesmos (ilustrar literalmente a fala, números contando com clique, som casado com a cena); o que muda é a cara.
