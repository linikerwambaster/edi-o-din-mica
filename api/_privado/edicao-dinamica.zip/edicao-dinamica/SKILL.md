---
name: edicao-dinamica
description: Edita vídeos verticais falados (Reels, TikTok, Shorts, anúncios) como um editor profissional, usando Remotion. Primeiro corta pausas, erros e frases repetidas; depois coloca efeitos de motion que ilustram exatamente o que a pessoa está falando (cartões de vidro, barras, contadores, texto atrás da pessoa, legendas simples ou dinâmicas, HUD "editando ao vivo", CTA). Use quando o usuário pedir para editar, cortar, legendar ou "deixar dinâmico" um vídeo gravado falando para a câmera.
---

# Edição Dinâmica

> Versão 1.1: cartão grande (`palco`), calendário, etiquetas riscadas, caixinhas de passo a passo, tela do Claude, mapa "X de 10", botão com cursor, legenda pequena, transição de luz sem arquivo e pacote de sons. Varie a cara de cada vídeo (veja o fim de `referencias/efeitos.md`).

Você vai editar um vídeo falado, vertical (1080 x 1920), como um editor de verdade faria. A regra de ouro:
**primeiro os cortes, depois os efeitos — e cada efeito mostra o que a pessoa está dizendo naquele exato momento.**

O motor é um projeto Remotion pronto (pasta `modelo/` desta skill). Você não escreve componentes do zero:
você escreve o **plano de edição** (`src/plano.json`) e o projeto monta o vídeo.

Leia também, quando precisar:
- `referencias/efeitos.md`: catálogo de efeitos, campos e quando usar cada um (LEIA antes de escrever o plano).
- `referencias/gravacao.md`: dicas de gravação para passar ao usuário.
- `referencias/problemas.md`: erros comuns e soluções.
- `referencias/exemplo-plano.json`: um plano real completo (vídeo de 1min37, 41 cortes, 32 efeitos) para usar de modelo.

Se a skill oficial `remotion-best-practices` estiver instalada, siga também as regras dela (animação só pelo quadro, sem CSS animation).

## Regras que não se negociam
1. **Não altere a imagem nem a voz da pessoa.** Nada de filtro de cor, nitidez, vinheta por cima do rosto, redução de ruído, equalização ou compressor. O áudio original é copiado. (Zoom de enquadramento nos cortes é permitido.)
2. **Os 3 primeiros segundos precisam prender**: algo acontece logo no primeiro quadro (o zoom de impacto já vem ligado e o primeiro efeito deve entrar no primeiro segundo). Nunca abra com tela preta.
3. **Efeito sem motivo na fala não entra.** Se ela fala "gestor de tráfego", aparece o cartão do gestor; se aponta e diz "olha a legenda", a legenda muda ali. Não copie efeitos de outros vídeos que não combinam com a fala.
4. **Sons, se houver, baixinhos e nunca em cima de palavra-chave** nem nos 3 primeiros segundos. Cada som precisa ter relação com o que aparece. A pasta `modelo/public/sons/` já traz clique, ding, whoosh, kaching (só com preço falado), errado, papel, relógio e máquina de escrever.
5. **Nada de inventar números ou fatos.** Contadores e textos usam o que a pessoa falou.
6. **Sempre uma amostra antes do vídeo inteiro** (até 15 s), aprovada pelo usuário.

## Passo a passo

### 0. Projeto
Se a pasta de trabalho ainda não tem o projeto, copie a pasta `modelo/` desta skill para a pasta de trabalho do usuário (por exemplo `meu-video/`) e rode `npm install` dentro dela. Precisa de Node.js 18+ e ffmpeg; se faltar algo, instale (Windows: `winget install OpenJS.NodeJS.LTS` e `winget install Gyan.FFmpeg`; Mac: `brew install node ffmpeg`).

### 1. Preparar o vídeo
```
node scripts/preparar.mjs "<caminho do vídeo gravado>"
```
Gera `public/video.mp4` (1080x1920, 30 fps). Vídeo HDR do iPhone vira cor normal sem estourar. O áudio é copiado sem mexer.
Só se o usuário PEDIR para melhorar: acrescente `--cor=leve` (um toque de contraste e cor; o melhor para quem aparece) ou `--cor=vibrante` (bem mais forte; pode deixar a pele carregada) e/ou `--audio=melhorar` (realça a voz, compressão leve e volume padrão de redes, -14 LUFS).

**Vídeo gravado na HORIZONTAL** (o preparar avisa): ele fica inteiro e o vídeo final continua vertical, com a pessoa enquadrada em cada corte, como um editor reenquadrando a câmera. Depois de preparar, rode o rastreio da cabeça:
```
python scripts/rosto.py
```
Gera `src/dados/rosto.json`. Em cada corte o enquadre fica fixo na pessoa; se ela se mexe muito dentro do corte, a câmera acompanha suave. Sem Python, use `"enquadre": { "x": 0.45 }` no plano (centro da pessoa, de 0 a 1 da largura). Como a pessoa fica mais perto, quase não sobra espaço acima da cabeça: ponha os cartões na altura do peito (`layout.topoLivre` por volta de `[1100, 1400]`) e a legenda logo abaixo.

**Antes e depois** (opcional, ótimo em VSL e anúncio): prepare só o trecho da gravação sem tratamento, `node scripts/preparar.mjs "<gravação>" public/bruto.mp4 --de=40 --ate=49` (sem `--cor` e sem `--audio`), ponha `"videoBruto": { "arquivo": "bruto.mp4", "inicio": 40 }` no plano e coloque o trecho original nos cortes com `"bruto"` no 3º campo: `[41.2, 47.9, "bruto"]`. Ele entra inteiro, com pausas e erros, com o rótulo "GRAVAÇÃO ORIGINAL / SEM EDIÇÃO", sem legenda e sem efeitos; o corte seguinte abre da caixa da gravação para o vertical editado. Use quando a pessoa falar de gravar "do jeito que sair", "com erro", "olha a diferença".

### 2. Transcrever (palavra por palavra)
```
node scripts/transcrever.mjs
```
Gera `src/dados/palavras.json` com o tempo de cada palavra NO ARQUIVO ORIGINAL. Roda localmente na placa de vídeo (WebGPU); a primeira vez baixa o modelo. Se o computador não tiver WebGPU, veja `referencias/problemas.md`.
Depois de transcrever, leia as palavras e anote erros de reconhecimento para o campo `correcoes` do plano (ex.: "Cloud Code" → "Claude Code").
Se um trecho não fizer sentido, não chute: recorte só ele (`ffmpeg -ss <início> -i public/video.mp4 -t 8 trecho.mp4`) e transcreva de novo com o modelo maior, `node scripts/transcrever.mjs trecho.mp4 trecho.json medium pt` (é maior e baixa só na primeira vez). Se os dois modelos ouvirem o mesmo, a legenda fica como está.

### 3. Analisar a fala e decidir os cortes (o trabalho de editor)
```
node scripts/analisar.mjs
```
Gera `roteiro.txt` (cada trecho falado entre pausas, com tempos e palavras), `cortes.sugeridos.json` e `src/dados/envelope.json`.
Agora decida como um editor:
- tire o começo e o fim fora do roteiro (comentários, "testando", "mas enfim, ó");
- tire **erros** e **frases repetidas**: quando a pessoa repete uma frase, fique com a melhor tomada (normalmente a última completa);
- tire hesitações e pausas dentro de frases (o `analisar` já separa nas pausas de 0,18 s; use `node scripts/analisar.mjs public/video.mp4 0.12` para cortar mais justo);
- não corte no meio de palavra: os tempos do `roteiro.txt` já têm margem de 0,06 s.
Escreva os trechos que ficam em `"cortes"` no `src/plano.json` (pares `[início, fim]` em segundos do original, em ordem).

### 4. Entender o vídeo e escrever o plano de efeitos
1. Olhe um quadro do vídeo para saber onde está o rosto e onde há espaço livre:
   `ffmpeg -ss 5 -i public/video.mp4 -frames:v 1 quadro.jpg` e abra a imagem.
   Ajuste `layout.topoLivre` (faixa vazia acima da cabeça, em pixels de 0 a 1920), `layout.legendaTop` (onde a legenda fica, abaixo do queixo e acima da área de botões do app, que ocupa ~250 px de baixo) e `origemZoom` (o centro do rosto em %, ex.: "45% 57%").
2. Leia a fala frase por frase e escreva uma tabela **"frase → efeito → por quê"** (mostre ao usuário).
   Bons gatilhos: profissões/públicos → `cartao`; "principalmente" → `foco` no cartão; números ditos → `contador`; antes/agora, "não migrou" → `barra`; dinheiro/preço → `etiqueta`; "muito mais", "vários" → `leque`; pergunta/gancho para o próximo trecho → `chip`; "eu falo/peço para a IA" → `prompt`; "cortou as pausas" → `timeline`; "legenda" → `vitrine` ou trocar o estilo da legenda; "faz tudo" → `checklist`; "para trás", "por trás" → `palavra` com `atras`; chamada final → `cta`. "Olha isso!" → `zoom` de ênfase. Dado real sobre o Brasil → `brasil` (com a fonte na tela). "Olha minha mão" → `segue` (e `aberto` se a mão sai do corte vertical). "Quer ver como eu gravei?" → trecho `bruto`. Preço que cai → `contador` de 297 para 97.
3. Se a pessoa **disser como quer a legenda** ("legenda básica", "legenda dinâmica"), troque o estilo naquele trecho com `legenda.trechos`.
4. Use os tempos do `src/dados/palavras.json` (segundos do original) nos campos de tempo. Um efeito entra junto com a palavra que o justifica (`de` = início da palavra) e sai quando o assunto muda.
5. Dê um nome curto em `"hud"` para cada efeito principal: vira o contador "EDITANDO AO VIVO 03/08 ...".
6. Texto passando ATRÁS da pessoa precisa do recorte: rode `python scripts/recorte.py public/video.mp4 <início-0,7> <duração>` (só o trecho necessário) e preencha `"recorte"` no plano. Se Python não estiver disponível, use a palavra na frente, em cima da cabeça.

### Modo SEM APARECER (narração + cenas, sem ninguém na câmera)
Para quem não quer aparecer: em vez do vídeo gravado, use só a voz. A narração pode ser a pessoa gravando só o áudio no celular, ou uma voz de IA (ElevenLabs, com a conta da própria pessoa).
1. Escreva o roteiro como HISTÓRIA: gancho forte nos 8 primeiros segundos, começo, meio, virada e chamada. O protagonista é "você" (nunca invente cliente ou depoimento).
2. Ponha o áudio em `public/narracao.mp3` e deixe o volume no padrão das redes antes de tudo (`ffmpeg -i original.mp3 -af loudnorm=I=-14:TP=-1.5 public/narracao.mp3`; voz de IA costuma vir baixa).
3. Transcreva e analise o áudio: `node scripts/transcrever.mjs public/narracao.mp3` e `node scripts/analisar.mjs public/narracao.mp3`.
4. No plano, troque `"video"` por `"narracao": "narracao.mp3"`; `"cortes"` cobre a narração (ex.: `[[0.2, 44.0]]`); `"hud": {"ativo": false}` deixa o vídeo mais cinematográfico.
5. Cada frase vira cena: efeito `imagem` (fotos em `public/imagens/`, `modo` "cheia" para foto em pé ou "quadro" para foto deitada, `desfoque` para virar fundo de cena de texto), `palavra` (frase grande; `ritmo` menor nas frases curtas; no máximo ~1000 px de largura: caracteres x tam x 0,66), `celular` (um vídeo real dentro de um celular), `rebobinar` (fita voltando, para a virada da história) e os demais efeitos.
6. Sons contam a história: relógio na tensão, notificação, impacto no golpe, rebobinar na virada, kaching só quando a fala é sobre dinheiro, sempre no espaço entre as falas.

### 5. Amostra → aprovação → vídeo inteiro
- Verifique os tipos: `npx tsc --noEmit`.
- Confira quadros parados antes de renderizar vídeo: `npx remotion render Video out/q --frames=30,90,150 --image-format=jpeg` e olhe as imagens (texto cortado? em cima do rosto? legível?).
- Amostra: `npm run amostra` (primeiros 15 s) → mostre ao usuário e pergunte o que mudar.
- Corrija pelo que ele disser ("de X s a Y s: problema → mudança"), sem refazer o que já foi aprovado.
- Vídeo final: `npm run render` → `out/video-final.mp4`.

## Formato do plano (resumo)
```json
{
  "video": "video.mp4",
  "cortes": [[6.30, 9.17], [9.47, 14.10]],
  "zoom": "auto",
  "origemZoom": "45% 57%",
  "correcoes": { "Cloud Code": "Claude Code" },
  "layout": { "topoLivre": [170, 560], "legendaTop": 1530 },
  "legenda": { "estilo": "simples", "trechos": [{ "de": 30.2, "ate": 36.0, "estilo": "dinamica" }] },
  "hud": { "ativo": true, "titulo": "EDITANDO AO VIVO" },
  "recorte": { "arquivo": "recorte.webm", "inicio": 13.6 },
  "efeitos": [
    { "tipo": "cartao", "de": 6.7, "ate": 13.9, "texto": "GESTOR DE TRÁFEGO", "icone": "grafico", "posicao": "esquerda", "sai": 9.9, "hud": "Gestor de tráfego" }
  ],
  "sons": [{ "arquivo": "sons/clique.wav", "em": 17.5, "volume": 0.1 }]
}
```
Todos os tempos do plano são **segundos do vídeo original** (o mesmo relógio do `palavras.json`). O projeto converte para o vídeo cortado sozinho.
