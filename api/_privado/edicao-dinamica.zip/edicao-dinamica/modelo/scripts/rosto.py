"""Rastreia onde está a cabeça da pessoa ao longo do vídeo, para o reenquadramento vertical de vídeo HORIZONTAL.
Com isso, cada corte da edição é enquadrado na pessoa (e acompanha quando ela se mexe), como um editor faria.

uso:  python scripts/rosto.py [public/video.mp4] [src/dados/rosto.json]

Gera uma lista {t, x, y}: t em segundos do vídeo, x = centro da cabeça (0 a 1 da largura), y = topo da cabeça (0 a 1 da altura).
Usa o mesmo modelo de recorte do scripts/recorte.py (Robust Video Matting, licença GPL-3.0, baixado do GitHub oficial
na primeira vez), rodando pequeno e 5 vezes por segundo (alguns minutos no processador).
Requer: Python 3, `pip install onnxruntime numpy`, ffmpeg.
"""
import json, os, subprocess, sys, time, urllib.request
import numpy as np
import onnxruntime as ort

src = sys.argv[1] if len(sys.argv) > 1 else 'public/video.mp4'
saida = sys.argv[2] if len(sys.argv) > 2 else 'src/dados/rosto.json'
FF = os.environ.get('FFMPEG', 'ffmpeg')
W, H, AMOSTRAS = 512, 288, 5
URL = 'https://github.com/PeterL1n/RobustVideoMatting/releases/download/v1.0.0/rvm_mobilenetv3_fp32.onnx'
MODELO = os.path.join('modelos', 'rvm_mobilenetv3_fp32.onnx')
if not os.path.exists(MODELO):
    os.makedirs('modelos', exist_ok=True)
    print('baixando o modelo de recorte (~15 MB)...')
    urllib.request.urlretrieve(URL, MODELO)

so = ort.SessionOptions(); so.intra_op_num_threads = max(2, (os.cpu_count() or 4) - 1)
sess = ort.InferenceSession(MODELO, so, providers=['CPUExecutionProvider'])
rd = subprocess.Popen([FF, '-v', 'error', '-i', src, '-vf', f'fps={AMOSTRAS},scale={W}:{H}', '-pix_fmt', 'rgb24', '-f', 'rawvideo', '-'], stdout=subprocess.PIPE)
rec = [np.zeros((1, 1, 1, 1), np.float32) for _ in range(4)]
ds = np.array([0.6], np.float32)
pontos, k, T = [], 0, time.time()
while True:
    buf = rd.stdout.read(W * H * 3)
    if len(buf) < W * H * 3: break
    img = np.frombuffer(buf, np.uint8).reshape(H, W, 3).astype(np.float32).transpose(2, 0, 1)[None] / 255.0
    fgr, pha, *rec = sess.run(None, {'src': img, 'r1i': rec[0], 'r2i': rec[1], 'r3i': rec[2], 'r4i': rec[3], 'downsample_ratio': ds})
    m = pha[0, 0] > 0.5
    linhas = np.where(m.sum(axis=1) > W * 0.03)[0]
    if len(linhas):
        topo = int(linhas[0])
        # faixa logo abaixo do topo da cabeça (cabelo/testa): mão e cadeira quase nunca sobem até ali
        faixa = m[topo: topo + int(H * 0.12)]
        cols = np.where(faixa.any(axis=0))[0]
        peso = faixa.sum(axis=0).astype(np.float64)
        if peso.sum() > 0 and len(cols):
            x = float((peso * np.arange(W)).sum() / peso.sum()) / W
            pontos.append({'t': round(k / AMOSTRAS, 3), 'x': round(x, 4), 'y': round(topo / H, 4)})
    k += 1
    if k % (AMOSTRAS * 30) == 0:
        print(f'{k / AMOSTRAS:.0f} s analisados ({k / (time.time() - T):.0f} quadros/s)', flush=True)
rd.wait()
os.makedirs(os.path.dirname(saida) or '.', exist_ok=True)
with open(saida, 'w', encoding='utf-8') as f:
    json.dump(pontos, f, separators=(',', ':'))
print(f'pronto: {saida} ({len(pontos)} pontos em {k / AMOSTRAS:.0f} s de vídeo)')
