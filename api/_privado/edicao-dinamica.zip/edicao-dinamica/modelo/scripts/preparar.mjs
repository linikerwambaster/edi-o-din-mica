// Prepara o vídeo gravado para a edição: 1080 x 1920 (ou horizontal inteiro, para reenquadrar), 30 fps, H.264.
// - Vídeo de iPhone em HDR (HLG/Dolby Vision) é convertido para cor normal (SDR) sem estourar.
// - O ÁUDIO É COPIADO SEM MEXER quando já é AAC (nada de filtro, volume ou redução de ruído).
// uso: node scripts/preparar.mjs "<arquivo gravado>" [public/video.mp4] [--cor=vibrante] [--audio=melhorar]
//   --cor=leve       SÓ se a pessoa pedir: um toque de contraste e cor (recomendado para quem aparece)
//   --cor=vibrante   SÓ se a pessoa pedir: bem mais contraste e saturação (pode deixar a pele forte demais)
//   --audio=melhorar SÓ se a pessoa pedir: corta grave de fundo, realça a voz, compressão leve e volume padrão de redes (-14 LUFS)
//   --de=41 --ate=48 só um trecho (ex.: a gravação original para o "antes", em public/bruto.mp4)
// Requer o ffmpeg instalado (o Claude instala se faltar).
import { execFileSync, spawnSync } from "node:child_process";
import { existsSync, mkdirSync, writeFileSync } from "node:fs";
import { dirname } from "node:path";

const args0 = process.argv.slice(2);
const opc = Object.fromEntries(args0.filter((a) => a.startsWith("--")).map((a) => a.slice(2).split("=")));
const [entrada, saida = "public/video.mp4"] = args0.filter((a) => !a.startsWith("--"));
if (!entrada || !existsSync(entrada)) {
  console.error('uso: node scripts/preparar.mjs "<arquivo gravado>" [public/video.mp4]');
  process.exit(1);
}
const FF = process.env.FFMPEG || "ffmpeg";
const FP = process.env.FFPROBE || "ffprobe";

const probe = JSON.parse(execFileSync(FP, ["-v", "error", "-show_streams", "-of", "json", entrada]).toString());
const v = probe.streams.find((s) => s.codec_type === "video");
const audios = probe.streams.filter((s) => s.codec_type === "audio");
const aac = audios.find((s) => s.codec_name === "aac");
const a = aac ?? audios[0];
if (!v) throw new Error("O arquivo não tem vídeo.");
const hdr = ["arib-std-b67", "smpte2084"].includes(v.color_transfer);
// celular gravando em pé às vezes salva o vídeo "deitado" com metadado de rotação: o ffmpeg já gira sozinho
const rot = Math.abs(Number((v.side_data_list ?? []).find((d) => d.rotation !== undefined)?.rotation ?? v.tags?.rotate ?? 0)) % 180;
const larg = rot === 90 ? v.height : v.width;
const alt = rot === 90 ? v.width : v.height;
const horizontal = larg > alt;
console.log(`vídeo: ${v.codec_name} ${larg}x${alt} ${v.color_transfer ?? "sdr"} | áudio: ${a ? a.codec_name : "nenhum"}${hdr ? " | HDR -> SDR" : ""}${horizontal ? " | HORIZONTAL" : ""}`);

// Enquadra PRIMEIRO (4x mais rápido) e depois, se for HDR, converte para SDR com mapeamento de tons "hable"
// (o mais próximo do que o iPhone mostra).
// Vídeo em pé: 1080x1920. Vídeo HORIZONTAL: fica inteiro (altura até 1920) e o corte vertical é feito na edição,
// acompanhando o rosto (scripts/rosto.py), como um editor reenquadrando cada corte.
const tonemap = "zscale=t=linear:npl=203,format=gbrpf32le,zscale=p=bt709,tonemap=tonemap=hable:desat=0,zscale=t=bt709:m=bt709:r=tv,format=yuv420p";
const altSaida = horizontal ? Math.min(alt, 1920) : 1920;
const largSaida = horizontal ? Math.round((larg * altSaida) / alt / 2) * 2 : 1080;
const enquadra = horizontal
  ? `scale=${largSaida}:${altSaida}:flags=lanczos`
  : "scale=1080:1920:force_original_aspect_ratio=increase:flags=lanczos,crop=1080:1920";
// "leve": só um toque (a pessoa continua com a cara dela); "vibrante": bem mais forte (para B-roll e produto)
const cor = opc.cor === "vibrante" ? ",eq=contrast=1.06:saturation=1.16:gamma=0.97,vibrance=intensity=0.10" : opc.cor === "leve" ? ",eq=contrast=1.03:saturation=1.06" : "";
const vf = (hdr ? `${enquadra},${tonemap}` : enquadra) + cor + ",fps=30";
const audioFiltro = opc.audio === "melhorar" ? "highpass=f=75,equalizer=f=220:t=q:w=1:g=-1.5,equalizer=f=3200:t=q:w=1.2:g=2,acompressor=threshold=-21dB:ratio=2:attack=8:release=160:makeup=1.5,loudnorm=I=-14:TP=-1.5:LRA=11" : "";

mkdirSync(dirname(saida), { recursive: true });
const trecho = [...(opc.de ? ["-ss", String(Number(opc.de))] : []), ...(opc.ate ? ["-to", String(Number(opc.ate))] : [])];
const args = ["-v", "error", "-stats", "-y", ...trecho, "-i", entrada, "-map", "0:v:0"];
if (a) args.push("-map", `0:${a.index}`);
args.push("-vf", vf, "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p", "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709");
if (a) args.push(...(audioFiltro ? ["-af", audioFiltro, "-ar", "48000", "-c:a", "aac", "-b:a", "256k"] : a.codec_name === "aac" ? ["-c:a", "copy"] : ["-c:a", "aac", "-b:a", "320k"]));
args.push("-movflags", "+faststart", saida);
const r = spawnSync(FF, args, { stdio: "inherit" });
if (r.status !== 0) {
  if (hdr) console.error("\nFalhou a conversão HDR. Seu ffmpeg precisa do filtro zscale (no Windows: winget install Gyan.FFmpeg; no Mac: brew install ffmpeg).");
  process.exit(r.status ?? 1);
}
// tamanho do vídeo preparado: a edição usa isso para saber se precisa reenquadrar
mkdirSync("src/dados", { recursive: true });
writeFileSync("src/dados/fonte.json", JSON.stringify({ largura: largSaida, altura: altSaida }) + "\n");
console.log(`pronto: ${saida}${audioFiltro ? " (áudio melhorado)" : a && a.codec_name === "aac" ? " (áudio original copiado)" : ""}${cor ? ` (cor ${opc.cor})` : ""}`);
if (horizontal) console.log("vídeo horizontal: rode o rastreio do rosto para o reenquadramento vertical (veja SKILL.md, passo 1).");
