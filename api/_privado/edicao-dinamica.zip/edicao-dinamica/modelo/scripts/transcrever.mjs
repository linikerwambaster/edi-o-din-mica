// Transcreve a fala do vídeo palavra por palavra, localmente, com o Whisper oficial do Remotion (@remotion/whisper-webgpu).
// Os tempos ficam relativos ao ARQUIVO ORIGINAL (antes dos cortes), como a skill do Remotion recomenda.
// uso: node scripts/transcrever.mjs [public/video.mp4] [src/dados/palavras.json] [modelo=small] [idioma=pt]
// Precisa de placa de vídeo compatível com WebGPU. O modelo (~500 MB no "small") é baixado só na primeira vez.
import { registerMediabunnyServer } from "@mediabunny/server";
import {
  WHISPER_WEBGPU_SAMPLE_RATE,
  canUseWhisperWebGpu,
  downloadWhisperModel,
  loadWhisperModel,
  toCaptions,
  transcribe,
} from "@remotion/whisper-webgpu";
import { ALL_FORMATS, Conversion, FilePathSource, Input, NullTarget, Output, WavOutputFormat } from "mediabunny";
import { writeFile } from "node:fs/promises";

const [entrada = "public/video.mp4", saida = "src/dados/palavras.json", modelo = "small", idioma = "pt"] = process.argv.slice(2);

registerMediabunnyServer();
const suporte = await canUseWhisperWebGpu();
if (!suporte.supported) {
  console.error("Este computador não roda o Whisper na placa de vídeo:", suporte.detailedReason);
  process.exit(2);
}

// 1) áudio em 16 kHz mono
const pedacos = [];
const input = new Input({ formats: ALL_FORMATS, source: new FilePathSource(entrada) });
const faixa = await input.getPrimaryAudioTrack();
if (!faixa) throw new Error("O vídeo não tem áudio.");
const conversao = await Conversion.init({
  input,
  output: new Output({ format: new WavOutputFormat(), target: new NullTarget() }),
  video: { discard: true },
  audio: (t) =>
    t.id !== faixa.id
      ? { discard: true }
      : {
          codec: "pcm-f32",
          forceTranscode: true,
          numberOfChannels: 1,
          sampleFormat: "f32",
          sampleRate: WHISPER_WEBGPU_SAMPLE_RATE,
          process: (amostra) => {
            const onda = new Float32Array(amostra.allocationSize({ format: "f32", planeIndex: 0 }) / 4);
            amostra.copyTo(onda, { format: "f32", planeIndex: 0 });
            pedacos.push({ inicio: Math.round(amostra.timestamp * WHISPER_WEBGPU_SAMPLE_RATE), onda });
            return amostra;
          },
        },
});
if (!conversao.isValid) throw new Error("Não consegui decodificar o áudio.");
await conversao.execute();
const total = pedacos.reduce((m, p) => Math.max(m, p.inicio + p.onda.length), 0);
const onda = new Float32Array(total);
for (const p of pedacos) {
  const d = Math.max(0, p.inicio), s = Math.max(0, -p.inicio);
  const n = Math.min(p.onda.length - s, onda.length - d);
  if (n > 0) onda.set(p.onda.subarray(s, s + n), d);
}
console.log(`áudio: ${(total / WHISPER_WEBGPU_SAMPLE_RATE).toFixed(1)} s`);

// 2) modelo e transcrição
let ultimo = -1;
await downloadWhisperModel({
  model: modelo,
  onProgress: (p) => {
    const pc = Math.round((p.progress ?? 0) * 100);
    if (pc !== ultimo && pc % 10 === 0) { ultimo = pc; console.log(`baixando modelo ${modelo}: ${pc}%`); }
  },
});
const handle = await loadWhisperModel({ model: modelo });
const t0 = Date.now();
const resultado = await transcribe({ channelWaveform: onda, model: modelo, language: idioma });
const { captions } = toCaptions({ whisperWebGpuOutput: resultado });
await handle?.[Symbol.asyncDispose]?.();

// 3) salva só o essencial: texto e tempos em ms (no arquivo original)
const palavras = captions.map((c) => ({ text: c.text.trim(), startMs: Math.round(c.startMs), endMs: Math.round(c.endMs) })).filter((w) => w.text);
await writeFile(saida, JSON.stringify(palavras, null, 1));
console.log(`${palavras.length} palavras em ${((Date.now() - t0) / 1000).toFixed(1)} s -> ${saida}`);
