"""Recorte da pessoa (fundo transparente) num TRECHO do vídeo, para um texto passar ATRÁS dela.
Só o trecho pedido é processado (é mais lento: ~2 quadros/s no processador). O fundo real NÃO é trocado:
o recorte só serve para desenhar a palavra entre o fundo e a pessoa.

uso:  python scripts/recorte.py public/video.mp4 <inicio_s> <duracao_s> [public/recorte.webm]
      comece ~0,7 s ANTES do trecho que vai usar (o modelo precisa de alguns quadros para "acertar" a silhueta).
      depois, no plano: "recorte": {"arquivo": "recorte.webm", "inicio": <inicio_s>}

Requer: Python 3, `pip install onnxruntime numpy`, ffmpeg. O modelo Robust Video Matting (licença GPL-3.0,
projeto de Peter Lin) é baixado do GitHub oficial na primeira vez para a pasta modelos/.
"""
import json, os, subprocess, sys, time, urllib.request
import numpy as np
import onnxruntime as ort

if len(sys.argv) < 4:
    print(__doc__); sys.exit(1)
src, t0, dur = sys.argv[1], float(sys.argv[2]), float(sys.argv[3])
saida = sys.argv[4] if len(sys.argv) > 4 else 'public/recorte.webm'
FF = os.environ.get('FFMPEG', 'ffmpeg')
W, H, FPS = 1080, 1920, 30
# vídeo horizontal: o recorte sai do tamanho do vídeo preparado (a edição posiciona igual ao vídeo)
if os.path.exists(os.path.join('src', 'dados', 'fonte.json')):
    with open(os.path.join('src', 'dados', 'fonte.json'), encoding='utf-8') as _f:
        _fonte = json.load(_f)
    W, H = int(_fonte['largura']), int(_fonte['altura'])
URL = 'https://github.com/PeterL1n/RobustVideoMatting/releases/download/v1.0.0/rvm_mobilenetv3_fp32.onnx'
MODELO = os.path.join('modelos', 'rvm_mobilenetv3_fp32.onnx')
if not os.path.exists(MODELO):
    os.makedirs('modelos', exist_ok=True)
    print('baixando o modelo de recorte (~15 MB)...')
    urllib.request.urlretrieve(URL, MODELO)

so = ort.SessionOptions(); so.intra_op_num_threads = max(2, (os.cpu_count() or 4) - 1)
sess = ort.InferenceSession(MODELO, so, providers=['CPUExecutionProvider'])
n = int(round(dur * FPS))
alfa_tmp = saida + '.alfa.mkv'
rd = subprocess.Popen([FF, '-v', 'error', '-ss', f'{t0:.3f}', '-i', src, '-frames:v', str(n), '-vf', f'scale={W}:{H}', '-pix_fmt', 'rgb24', '-f', 'rawvideo', '-'], stdout=subprocess.PIPE)
wr = subprocess.Popen([FF, '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'gray', '-s', f'{W}x{H}', '-r', str(FPS), '-i', '-', '-c:v', 'ffv1', alfa_tmp], stdin=subprocess.PIPE)
rec = [np.zeros((1, 1, 1, 1), np.float32) for _ in range(4)]
ds = np.array([0.4], np.float32)
T = time.time(); k = 0
while k < n:
    buf = rd.stdout.read(W * H * 3)
    if len(buf) < W * H * 3: break
    x = np.frombuffer(buf, np.uint8).reshape(H, W, 3).astype(np.float32).transpose(2, 0, 1)[None] / 255.0
    _, pha, *rec = sess.run(None, {'src': x, 'r1i': rec[0], 'r2i': rec[1], 'r3i': rec[2], 'r4i': rec[3], 'downsample_ratio': ds})
    wr.stdin.write((np.clip(pha[0, 0], 0, 1) * 255).astype(np.uint8).tobytes()); k += 1
    if k % 30 == 0: print(f'{k}/{n} quadros ({k / (time.time() - T):.1f}/s)', flush=True)
rd.stdout.close(); rd.wait(); wr.stdin.close(); wr.wait()

# junta imagem original + alfa num WebM transparente (VP9). O alfa é "endurecido" para mãos/rosto não ficarem translúcidos.
fc = "[0:v]format=rgb24[v];[1:v]format=gray,lut=y='clip((val-20)*2.2,0,255)'[a];[v][a]alphamerge,format=yuva420p[o]"
subprocess.run([FF, '-v', 'error', '-y', '-ss', f'{t0:.3f}', '-t', f'{dur:.3f}', '-i', src, '-i', alfa_tmp, '-filter_complex', fc, '-map', '[o]', '-an',
                '-c:v', 'libvpx-vp9', '-pix_fmt', 'yuva420p', '-deadline', 'good', '-cpu-used', '4', '-row-mt', '1', '-crf', '20', '-b:v', '0', '-auto-alt-ref', '0', saida], check=True)
os.remove(alfa_tmp)
print(f'pronto: {saida} ({k} quadros em {time.time() - T:.0f} s). No plano: "recorte": {{"arquivo": "{os.path.basename(saida)}", "inicio": {t0}}}')
