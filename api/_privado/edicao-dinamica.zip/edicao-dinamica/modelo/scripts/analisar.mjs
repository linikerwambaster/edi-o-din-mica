// Analisa a fala para o Claude decidir os cortes como um editor:
// - mede a energia da voz a cada 10 ms e acha as pausas de verdade (a transcrição costuma adiantar uns décimos depois de pausas);
// - grava src/dados/envelope.json (volume da voz por quadro, usado na onda do efeito "prompt");
// - grava roteiro.txt: cada trecho falado entre pausas, com início/fim e as palavras (para achar erros e frases repetidas);
// - grava cortes.sugeridos.json: todos os trechos falados, com margem curta. O Claude revisa (tira erros/repetições) e
//   copia o resultado para "cortes" em src/plano.json.
// uso: node scripts/analisar.mjs [public/video.mp4] [pausa_minima_s=0.18] [limiar_db=-38]
import { spawn } from "node:child_process";
import { readFileSync, writeFileSync } from "node:fs";

const [video = "public/video.mp4", pausaMin = "0.18", limiar = "-38"] = process.argv.slice(2);
const FF = process.env.FFMPEG || "ffmpeg";
const PAUSA = Number(pausaMin), LIM = Number(limiar), MARGEM = 0.06;

const pcm = await new Promise((ok, erro) => {
  const p = spawn(FF, ["-v", "error", "-i", video, "-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "-"]);
  const ch = [];
  p.stdout.on("data", (d) => ch.push(d));
  p.on("close", (c) => (c === 0 ? ok(Buffer.concat(ch)) : erro(new Error("ffmpeg falhou ao ler o áudio"))));
});
const n = pcm.length / 2;
const db = [];
for (let i = 0; i < n; i += 160) {
  let s = 0;
  const m = Math.min(n, i + 160);
  for (let j = i; j < m; j++) { const x = pcm.readInt16LE(j * 2) / 32768; s += x * x; }
  db.push(10 * Math.log10(s / (m - i) + 1e-12));
}
const dur = db.length / 100;

// envelope por quadro (30 fps), normalizado 0..1
const env = [];
for (let q = 0; q < dur * 30; q++) {
  const a = Math.floor((q / 30) * 100), b = Math.min(db.length, Math.floor(((q + 1) / 30) * 100));
  let s = 0;
  for (let k = a; k < b; k++) s += Math.pow(10, db[k] / 10);
  env.push(Math.sqrt(s / Math.max(1, b - a)));
}
const mx = Math.max(...env, 1e-9);
writeFileSync("src/dados/envelope.json", JSON.stringify(env.map((x) => +(x / mx).toFixed(3))));

// trechos falados = entre pausas >= PAUSA
const pausas = [];
let ini = null;
db.forEach((v, k) => {
  if (v < LIM) { if (ini === null) ini = k; }
  else { if (ini !== null && (k - ini) / 100 >= PAUSA) pausas.push([ini / 100, k / 100]); ini = null; }
});
if (ini !== null) pausas.push([ini / 100, dur]);
const trechos = [];
let t = 0;
for (const [a, b] of pausas) { if (a - t > 0.12) trechos.push([Math.max(0, t - MARGEM), Math.min(dur, a + MARGEM)]); t = b; }
if (dur - t > 0.12) trechos.push([Math.max(0, t - MARGEM), dur]);

let palavras = [];
try { palavras = JSON.parse(readFileSync("src/dados/palavras.json", "utf8")); } catch { /* sem transcrição ainda */ }
// cada palavra vai para o trecho com que mais se sobrepõe (assim não aparece duplicada nem some na emenda)
const dono = palavras.map((w) => {
  const s0 = w.startMs / 1000, e0 = w.endMs / 1000;
  let melhor = -1, mx = 0;
  trechos.forEach(([a, b], k) => { const o = Math.min(b, e0) - Math.max(a, s0); if (o > mx) { mx = o; melhor = k; } });
  return melhor;
});
const linhas = trechos.map(([a, b], i) => {
  const ws = palavras.filter((_, k) => dono[k] === i).map((w) => w.text).join(" ");
  return `${String(i + 1).padStart(3)}  ${a.toFixed(2).padStart(7)} - ${b.toFixed(2).padStart(7)}  (${(b - a).toFixed(2)} s)  ${ws}`;
});
writeFileSync("roteiro.txt", `Trechos falados entre pausas de ${PAUSA}s ou mais (tempos no ORIGINAL).\nUse para: tirar começo/fim fora do roteiro, erros, frases repetidas (fique com a melhor tomada) e hesitações.\n\n${linhas.join("\n")}\n`);
writeFileSync("cortes.sugeridos.json", JSON.stringify(trechos.map(([a, b]) => [+a.toFixed(2), +b.toFixed(2)])));
const falado = trechos.reduce((s, [a, b]) => s + (b - a), 0);
console.log(`${trechos.length} trechos falados | ${falado.toFixed(1)} s de fala em ${dur.toFixed(1)} s de vídeo | ${pausas.length} pausas`);
console.log("gerados: roteiro.txt, cortes.sugeridos.json, src/dados/envelope.json");
