import { Composition } from "remotion";
import { duracaoTotal, FPS } from "./lib/plano";
import { Video } from "./Video";

// Vídeo vertical 1080 x 1920, 30 fps. A duração vem dos cortes do plano (src/plano.json).
export const RemotionRoot: React.FC = () => {
  return (
    <Composition id="Video" component={Video} durationInFrames={duracaoTotal} fps={FPS} width={1080} height={1920} />
  );
};
