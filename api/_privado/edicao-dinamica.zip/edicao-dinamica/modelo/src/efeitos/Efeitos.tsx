import { createTikTokStyleCaptions } from "@remotion/captions";
import { useMemo } from "react";
import { AbsoluteFill, Img, interpolate, OffthreadVideo, Sequence, staticFile, useVideoConfig } from "remotion";
import envelope from "../dados/envelope.json";
import { DESTAQUE, ESCURO, FONTE, PESADA, ease, janela, vidro } from "../lib/estilo";
import { caixaVideo, EfeitoQ, fatorPalco, layout, palavrasSaida, paraOriginal, pecaEm, plano, segundosRemovidos } from "../lib/plano";
import { BRASIL } from "./brasil";
import { EstrelaClaude, Icone } from "./icones";

// Cada efeito recebe `e` (do plano, tempos já em quadros da saída) e `f` (quadro atual da saída).
type P = { e: EfeitoQ; f: number };
const s = (v: unknown, padrao = "") => (typeof v === "string" ? v : padrao);
const n = (v: unknown, padrao: number) => (typeof v === "number" ? v : padrao);
const lista = (v: unknown): string[] => (Array.isArray(v) ? v.map(String) : []);
const yTopo = () => layout.topoLivre[0];

// ---------- CARTÃO com ícone (ex.: "GESTOR DE TRÁFEGO"). foco = vai para o centro com selo; sai = sai de lado
export const Cartao: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 12, 8);
  if (v <= 0) return null;
  const k = typeof e.foco === "number" ? ease(f, e.foco, e.foco + 14) : 0;
  const saida = typeof e.sai === "number" ? ease(f, e.sai, e.sai + 10) : 0;
  const pos = s(e.posicao, "esquerda");
  const x0 = pos === "direita" ? 1080 - 50 - 480 : pos === "centro" ? 300 : 50;
  const x = x0 + (300 - x0) * k - saida * 320 * (pos === "direita" ? -1 : 1);
  const entra = ease(f, e.de, e.de + 12);
  return (
    <div style={{ position: "absolute", left: x, top: n(e.y, yTopo() + 20) + 30 * k, width: 480, display: "flex", alignItems: "center", gap: 20, padding: "24px 28px", borderRadius: 34, boxSizing: "border-box", opacity: v * (1 - saida), scale: String((0.6 + 0.4 * entra) * (1 + 0.25 * k)), translate: `0px ${(1 - entra) * -40}px`, ...vidro, boxShadow: `0 0 ${12 + 40 * k}px ${DESTAQUE}${k > 0.05 ? "aa" : "44"}, 0 14px 40px rgba(0,0,0,.35)` }}>
      <div style={{ width: 96, height: 96, borderRadius: 26, flex: "none", backgroundColor: DESTAQUE, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <Icone nome={s(e.icone, "check")} tam={58} cor={ESCURO} />
      </div>
      <div style={{ fontFamily: PESADA, fontSize: n(e.tam, 50), lineHeight: 1.0, color: "#fff" }}>{s(e.texto)}</div>
      {k > 0.01 && e.selo ? (
        <div style={{ position: "absolute", left: "50%", top: -34, translate: "-50% 0px", padding: "6px 18px", borderRadius: 20, backgroundColor: DESTAQUE, color: ESCURO, fontFamily: FONTE, fontWeight: 800, fontSize: 26, letterSpacing: 3, opacity: k, whiteSpace: "nowrap" }}>{s(e.selo)}</div>
      ) : null}
    </div>
  );
};

// ---------- BARRA de progresso (ex.: "EDIÇÃO MANUAL -> IA"); trava = trava e treme com textoTrava; acende = acende o rótulo da direita
export const Barra: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate);
  if (v <= 0) return null;
  const alvo = n(e.valor, 100) / 100;
  const trava = typeof e.trava === "number" ? e.trava : null;
  const enche = trava !== null
    ? interpolate(f, [e.de + 6, trava - 2, trava + 4], [0, Math.min(0.12, alvo || 0.12), alvo], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })
    : interpolate(f, [e.de + 6, e.ate - 10], [0, alvo], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const travou = trava !== null && f >= trava;
  const treme = travou && f < trava + 10 ? Math.sin(f * 2.4) * 8 * (1 - (f - trava) / 10) : 0;
  const luz = typeof e.acende === "number" ? ease(f, e.acende, e.acende + 10) : 0;
  return (
    <div style={{ position: "absolute", left: 70, right: 70, top: n(e.y, yTopo() + 280), padding: "24px 30px", borderRadius: 30, opacity: v, translate: `${treme}px ${(1 - v) * 20}px`, ...vidro }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontFamily: FONTE, fontWeight: 800, fontSize: 30, letterSpacing: 2, color: "rgba(255,255,255,.8)" }}>
        <span>{s(e.esquerda)}</span>
        <span style={{ color: travou ? "#ff6b6b" : "#fff", fontFamily: PESADA, fontSize: 40, letterSpacing: 0 }}>{travou && e.textoTrava ? s(e.textoTrava) : `${Math.round(enche * 100)}%`}</span>
        <span style={{ padding: "4px 14px", borderRadius: 16, color: luz > 0.5 ? ESCURO : DESTAQUE, backgroundColor: luz > 0.5 ? DESTAQUE : "transparent", border: `2px solid ${DESTAQUE}`, boxShadow: `0 0 ${24 * luz}px ${DESTAQUE}` }}>{s(e.direita)}</span>
      </div>
      <div style={{ position: "relative", height: 22, borderRadius: 11, marginTop: 18, backgroundColor: "rgba(255,255,255,.12)", overflow: "hidden" }}>
        <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: `${enche * 100}%`, borderRadius: 11, backgroundColor: travou ? "#ff6b6b" : DESTAQUE }} />
      </div>
    </div>
  );
};

// ---------- PALAVRA gigante. Com "atras": true o Video desenha ela ENTRE o fundo e você (precisa do recorte).
// animacao "afundar": a partir de `afunda` ela encolhe, desfoca e apaga (ex.: "ficar PARA TRÁS")
export const Palavra: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 6, 6);
  if (v <= 0) return null;
  const k = typeof e.afunda === "number" ? ease(f, e.afunda, e.ate) : 0;
  const linhas = s(e.texto).split("\n");
  return (
    <div style={{ position: "absolute", left: 0, right: 0, top: n(e.y, yTopo() + 130), textAlign: "center", fontFamily: PESADA, fontSize: n(e.tam, 230), lineHeight: 0.9, color: s(e.cor, "#fff"), whiteSpace: "nowrap", opacity: v * (1 - 0.65 * k), scale: String((1.25 - 0.25 * ease(f, e.de, e.de + 6)) * (1 - 0.42 * k)), translate: `0px ${-60 * k}px`, filter: `blur(${k * 5}px)`, textShadow: "0 12px 30px rgba(0,0,0,.55), 0 0 2px rgba(0,0,0,.4)" }}>
      {linhas.map((l, i) => (
        <div key={i}>
          {l.split("").map((c, j) => {
            // "ritmo": quadros entre uma letra e a próxima (padrão 1.5; use ~0.5 em frases que ficam pouco tempo)
            const r = n(e.ritmo, 1.5);
            const q = ease(f, e.de + (i * 4 + j) * r, e.de + (i * 4 + j) * r + 8);
            return <span key={j} style={{ display: "inline-block", opacity: q, translate: `0px ${(1 - q) * 60}px` }}>{c === " " ? " " : c}</span>;
          })}
        </div>
      ))}
    </div>
  );
};

// ---------- ETIQUETA de preço balançando (ex.: "MESMO TICKET")
export const Etiqueta: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 12, 8);
  if (v <= 0) return null;
  const bal = Math.sin((f - e.de) / 6) * 9 * Math.exp(-(f - e.de) / 25);
  const pulso = typeof e.enfase === "number" ? ease(f, e.enfase, e.enfase + 5) * (1 - ease(f, e.enfase + 5, e.enfase + 14)) : 0;
  const dir = s(e.posicao) === "direita";
  return (
    <div style={{ position: "absolute", [dir ? "right" : "left"]: 40, top: n(e.y, yTopo()), transformOrigin: "50% 0%", rotate: `${bal}deg`, opacity: v, translate: `0px ${(1 - ease(f, e.de, e.de + 12)) * -80}px` }}>
      <div style={{ width: 4, height: 50, margin: "0 auto", backgroundColor: "rgba(255,255,255,.7)" }} />
      <div style={{ display: "flex", alignItems: "center", gap: 16, padding: "20px 30px 20px 22px", borderRadius: 22, ...vidro, scale: String(1 + 0.08 * pulso) }}>
        <div style={{ width: 88, height: 88, borderRadius: 44, backgroundColor: DESTAQUE, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: PESADA, fontSize: 36, color: ESCURO }}>{s(e.simbolo, "R$")}</div>
        <div>
          <div style={{ fontFamily: PESADA, fontSize: 54, color: "#fff", lineHeight: 1 }}>{s(e.texto)}</div>
          {e.sub ? <div style={{ fontFamily: FONTE, fontWeight: 700, fontSize: 30, color: DESTAQUE, marginTop: 6 }}>{s(e.sub)}</div> : null}
        </div>
      </div>
    </div>
  );
};

// ---------- LEQUE de imagens se multiplicando (ex.: "muito mais entregas"). imagens: caminhos dentro de public/
export const Leque: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 8, 8);
  if (v <= 0) return null;
  const imgs = lista(e.imagens);
  const dir = s(e.posicao, "direita") === "direita";
  return (
    <div style={{ position: "absolute", [dir ? "right" : "left"]: 30, top: n(e.y, yTopo() + 140), width: 480, height: 470, opacity: v }}>
      {imgs.map((src, i) => {
        const q = ease(f, e.de + i * 5, e.de + i * 5 + 10);
        const ang = (i - (imgs.length - 1) / 2) * 11 * q;
        return (
          <div key={i} style={{ position: "absolute", left: 150, top: 20, width: 180, height: 320, borderRadius: 18, overflow: "hidden", border: `3px solid ${DESTAQUE}`, boxShadow: "0 10px 26px rgba(0,0,0,.4)", transformOrigin: "50% 140%", rotate: `${ang}deg`, opacity: q, scale: String(0.6 + 0.4 * q) }}>
            <Img src={staticFile(src)} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          </div>
        );
      })}
      {e.texto ? <div style={{ position: "absolute", left: 0, right: 0, top: 380, textAlign: "center", fontFamily: PESADA, fontSize: 56, color: "#fff", textShadow: "0 4px 14px rgba(0,0,0,.5)", opacity: ease(f, e.de + 18, e.de + 28) }}>{s(e.texto)}</div> : null}
    </div>
  );
};

// ---------- CHIP curto (ex.: "? O PORQUÊ ↓")
export const Chip: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 10, 6);
  if (v <= 0) return null;
  return (
    <div style={{ position: "absolute", left: 0, right: 0, top: n(e.y, yTopo() + 90), display: "flex", justifyContent: "center", opacity: v, scale: String(0.7 + 0.3 * ease(f, e.de, e.de + 10)) }}>
      <div style={{ display: "flex", alignItems: "center", gap: 18, padding: "20px 40px", borderRadius: 60, ...vidro }}>
        {e.antes ? <span style={{ fontFamily: PESADA, fontSize: 80, color: DESTAQUE, rotate: `${Math.sin(f / 5) * 8}deg` }}>{s(e.antes)}</span> : null}
        <span style={{ fontFamily: PESADA, fontSize: n(e.tam, 66), color: "#fff" }}>{s(e.texto)}</span>
        {e.depois ? <span style={{ fontSize: 56, color: DESTAQUE, translate: `0px ${Math.sin(f / 4) * 6}px` }}>{s(e.depois)}</span> : null}
      </div>
    </div>
  );
};

// ---------- PROMPT por voz: microfone, texto digitando e a onda REAL da voz
export const Prompt: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 12, 8);
  if (v <= 0) return null;
  const texto = s(e.texto);
  const k = Math.floor(interpolate(f, [e.de + 8, e.ate - 14], [0, texto.length], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }));
  const env = envelope as number[];
  const barras = Array.from({ length: 16 }, (_, i) => Math.max(0.12, Math.min(1, (env[Math.round(paraOriginal(f - (15 - i)) * 30)] ?? 0) * 1.8)));
  return (
    <div style={{ position: "absolute", left: 60, right: 60, top: n(e.y, yTopo() + 60), opacity: v, translate: `0px ${(1 - v) * 30}px` }}>
      <div style={{ fontFamily: FONTE, fontWeight: 800, fontSize: 26, letterSpacing: 4, color: DESTAQUE, marginLeft: 26, marginBottom: 10 }}>PROMPT</div>
      <div style={{ display: "flex", alignItems: "center", gap: 20, padding: "20px 26px", borderRadius: 60, ...vidro }}>
        <div style={{ width: 70, height: 70, borderRadius: 35, flex: "none", display: "flex", alignItems: "center", justifyContent: "center", backgroundColor: DESTAQUE, boxShadow: `0 0 ${10 + barras[15] * 22}px ${DESTAQUE}` }}>
          <Icone nome="mic" tam={34} cor={ESCURO} />
        </div>
        <div style={{ flex: 1, fontFamily: FONTE, fontSize: 38, fontWeight: 600, color: "#fff", lineHeight: 1.25, minHeight: 96 }}>
          {texto.slice(0, k)}
          <span style={{ display: "inline-block", width: 3, height: 38, marginLeft: 3, verticalAlign: -6, backgroundColor: DESTAQUE, opacity: Math.floor(f / 8) % 2 ? 1 : 0.2 }} />
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 4, height: 64, flex: "none" }}>
          {barras.map((b, i) => <div key={i} style={{ width: 5, height: 8 + b * 52, borderRadius: 3, backgroundColor: DESTAQUE, opacity: 0.45 + 0.55 * (i / 15) }} />)}
        </div>
      </div>
    </div>
  );
};

// ---------- TIMELINE de cortes: pausas (vermelhas) cortadas, trechos se juntam; mostra o tempo REAL removido
export const Timeline: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate);
  if (v <= 0) return null;
  const corte = n(e.corte, e.de + 15);
  const clipes = [120, 90, 140, 80, 110, 100], pausas = [70, 95, 60, 85, 75];
  const k = pausas.map((_, i) => ease(f, corte + i * 7, corte + i * 7 + 8));
  const rem = Math.round((segundosRemovidos * k.reduce((a, b) => a + b, 0)) / pausas.length);
  const cab = interpolate(f, [e.de + 4, e.ate - 6], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  let x = 0;
  const blocos: Array<{ x: number; w: number; pausa: boolean }> = [];
  clipes.forEach((w, i) => {
    blocos.push({ x, w, pausa: false });
    x += w + 6;
    if (i < pausas.length) {
      const pw = pausas[i] * (1 - k[i]);
      blocos.push({ x, w: pw, pausa: true });
      x += pw + (pw > 1 ? 6 : 0);
    }
  });
  return (
    <div style={{ position: "absolute", left: 50, right: 50, top: n(e.y, yTopo() + 20), padding: "22px 26px", borderRadius: 30, opacity: v, translate: `0px ${(1 - v) * 30}px`, ...vidro }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", fontFamily: FONTE, color: "#fff" }}>
        <span style={{ fontWeight: 800, fontSize: 30, letterSpacing: 3, color: DESTAQUE }}>{s(e.titulo, "CORTES AUTOMÁTICOS")}</span>
        <span style={{ fontFamily: PESADA, fontSize: 48, fontVariantNumeric: "tabular-nums" }}>−{Math.floor(rem / 60)}:{String(rem % 60).padStart(2, "0")}</span>
      </div>
      <div style={{ fontFamily: FONTE, fontSize: 24, color: "rgba(255,255,255,.6)", marginTop: 2 }}>{s(e.sub, "pausas e repetições removidas")}</div>
      <div style={{ position: "relative", height: 92, marginTop: 18 }}>
        {blocos.map((b, i) => (b.w > 0.5 ? <div key={i} style={{ position: "absolute", left: (b.x / x) * 928, top: 8, width: (b.w / x) * 928, height: 76, borderRadius: 10, background: b.pausa ? "repeating-linear-gradient(45deg, rgba(255,90,90,.55) 0 10px, rgba(255,90,90,.25) 10px 20px)" : DESTAQUE }} /> : null))}
        <div style={{ position: "absolute", left: cab * 928, top: 0, width: 4, height: 92, backgroundColor: "#fff", boxShadow: "0 0 12px #fff" }} />
      </div>
    </div>
  );
};

// ---------- VITRINE das legendas: palavra por palavra, com o tempo exato acima da palavra falada
export const Vitrine: React.FC<P> = ({ e, f }) => {
  const { fps } = useVideoConfig();
  const v = janela(f, e.de, e.ate, 6, 6);
  if (v <= 0) return null;
  const ms = (f / fps) * 1000;
  const ws = palavrasSaida.filter((w) => w.startMs >= (e.de / fps) * 1000 - 50 && w.startMs < (e.ate / fps) * 1000);
  const porPag = 4;
  const atual = Math.max(0, ws.findIndex((w) => ms < w.endMs + 60));
  const pag = ws.slice(Math.floor(atual / porPag) * porPag, Math.floor(atual / porPag) * porPag + porPag);
  return (
    <div style={{ position: "absolute", left: 60, right: 60, top: n(e.y, layout.legendaTop - 150), display: "flex", flexWrap: "wrap", justifyContent: "center", columnGap: 36, rowGap: 70, opacity: v }}>
      {pag.map((w, i) => {
        const ativo = ms >= w.startMs && ms < w.endMs + 60;
        return (
          <div key={i} style={{ position: "relative" }}>
            {ativo ? <div style={{ position: "absolute", left: "50%", top: -58, translate: "-50% 0px", padding: "6px 14px", borderRadius: 14, fontFamily: FONTE, fontWeight: 700, fontSize: 24, color: DESTAQUE, whiteSpace: "nowrap", ...vidro }}>{(w.startMs / 1000).toFixed(2).replace(".", ",")} s</div> : null}
            <span style={{ display: "inline-block", fontFamily: PESADA, fontSize: 84, lineHeight: 1, color: ativo ? DESTAQUE : "#fff", opacity: ms >= w.startMs ? 1 : 0.35, scale: ativo ? "1.07" : "1", WebkitTextStroke: "10px rgba(0,0,0,.9)", paintOrder: "stroke fill" }}>{w.text.replace(/[,.!?]/g, "")}</span>
          </div>
        );
      })}
    </div>
  );
};

// ---------- CONTADOR (ex.: 01 -> 06 ANOS)
export const Contador: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate);
  if (v <= 0) return null;
  const ini = n(e.inicio, 1), fim = n(e.fim, 10);
  const conta = n(e.conta, e.de + 10), chega = n(e.chega, conta + 20);
  const val = Math.round(interpolate(f, [conta, chega], [ini, fim], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }));
  const pulso = ease(f, chega, chega + 6) * (1 - ease(f, chega + 6, chega + 16));
  const dir = s(e.posicao, "direita") === "direita";
  return (
    <div style={{ position: "absolute", [dir ? "right" : "left"]: 44, top: n(e.y, yTopo()), textAlign: dir ? "right" : "left", padding: "18px 30px 20px", borderRadius: 30, opacity: v, translate: `${(1 - v) * (dir ? 40 : -40)}px 0px`, ...vidro }}>
      <div style={{ fontFamily: PESADA, fontSize: 150, lineHeight: 0.9, color: "#fff", scale: String(1 + 0.12 * pulso), textShadow: `0 0 ${20 + 30 * pulso}px ${DESTAQUE}`, fontVariantNumeric: "tabular-nums" }}>{s(e.prefixo)}{String(val).padStart(n(e.digitos, 2), "0")}{s(e.sufixo)}</div>
      <div style={{ fontFamily: FONTE, fontWeight: 800, fontSize: 30, letterSpacing: 4, color: DESTAQUE }}>{s(e.rotulo)}</div>
    </div>
  );
};

// ---------- CHECKLIST sendo marcada (ex.: "CLAUDE CODE EXECUTANDO")
export const Checklist: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate);
  if (v <= 0) return null;
  const itens = lista(e.itens);
  const passo = n(e.passo, 6);
  return (
    <div style={{ position: "absolute", left: 90, right: 90, top: n(e.y, yTopo()), padding: "22px 30px", borderRadius: 30, opacity: v, translate: `0px ${(1 - v) * 30}px`, ...vidro }}>
      <div style={{ display: "flex", alignItems: "center", gap: 14, fontFamily: FONTE, fontWeight: 800, fontSize: 28, letterSpacing: 3, color: DESTAQUE, marginBottom: 10 }}>
        <EstrelaClaude tam={30} giro={f * 4} />
        {s(e.titulo, "CLAUDE CODE EXECUTANDO")}
      </div>
      {itens.map((t, i) => {
        const ok = ease(f, e.de + 6 + i * passo, e.de + 12 + i * passo);
        return (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 18, padding: "7px 0", fontFamily: FONTE, fontSize: 36, fontWeight: 600, color: ok > 0.5 ? "#fff" : "rgba(255,255,255,.45)" }}>
            <div style={{ width: 40, height: 40, borderRadius: 20, flex: "none", border: `2.5px solid ${DESTAQUE}`, backgroundColor: ok > 0.5 ? DESTAQUE : "transparent", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width={24} height={24} viewBox="0 0 24 24" fill="none" stroke={ESCURO} strokeWidth={3.6} strokeLinecap="round" strokeLinejoin="round" style={{ opacity: ok }}><path d="M5 12l5 5 9-10" /></svg>
            </div>
            {t}
          </div>
        );
      })}
    </div>
  );
};

// ---------- TÍTULO de vidro (ex.: "EDITADO 100% COM IA"), com palavra em destaque e selo opcional
export const Titulo: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 12, 8);
  if (v <= 0) return null;
  const texto = s(e.texto), dest = s(e.destaque);
  const partes = dest && texto.includes(dest) ? texto.split(dest) : [texto];
  const linha = ease(f, e.de + 6, e.de + 22);
  return (
    <div style={{ position: "absolute", left: 0, right: 0, top: n(e.y, yTopo() + 40), display: "flex", justifyContent: "center", opacity: v }}>
      <div style={{ padding: "26px 46px 24px", borderRadius: 34, textAlign: "center", scale: String(0.9 + 0.1 * ease(f, e.de, e.de + 12)), ...vidro }}>
        <div style={{ fontFamily: PESADA, fontSize: n(e.tam, 76), lineHeight: 1, color: "#fff" }}>
          {partes.length > 1 ? <>{partes[0]}<span style={{ color: DESTAQUE }}>{dest}</span>{partes[1]}</> : texto}
        </div>
        {e.sub ? (
          <>
            <div style={{ height: 3, width: `${linha * 100}%`, margin: "18px auto 16px", background: `linear-gradient(90deg, transparent, ${DESTAQUE}, transparent)` }} />
            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 14, fontFamily: FONTE, fontWeight: 700, fontSize: 38, color: "#fff", opacity: ease(f, e.de + 14, e.de + 26) }}>
              {e.selo === "claude" ? <EstrelaClaude tam={40} giro={f * 1.5} /> : null}
              {s(e.sub)}
            </div>
          </>
        ) : null}
      </div>
    </div>
  );
};

// ---------- CTA (ex.: "Toque em Saiba mais ↓"), pulsa no momento `pulso`
export const CTA: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 14, 6);
  if (v <= 0) return null;
  const bate = typeof e.pulso === "number" ? ease(f, e.pulso, e.pulso + 5) * (1 - ease(f, e.pulso + 5, e.pulso + 16)) : 0;
  return (
    <div style={{ position: "absolute", left: 0, right: 0, top: n(e.y, yTopo() + 60), display: "flex", justifyContent: "center", opacity: v, scale: String(0.7 + 0.3 * v) }}>
      <div style={{ display: "flex", alignItems: "center", gap: 18, padding: "24px 56px", borderRadius: 80, backgroundColor: DESTAQUE, color: ESCURO, fontFamily: PESADA, fontSize: n(e.tam, 60), scale: String(1 + 0.1 * bate), boxShadow: `0 0 0 ${12 + Math.sin(f / 7) * 5 + bate * 20}px ${DESTAQUE}55, 0 14px 40px rgba(0,0,0,.45)` }}>
        {s(e.texto, "Toque em Saiba mais")}
        <span style={{ translate: `0px ${Math.sin(f / 5) * 7}px`, fontSize: 64 }}>{s(e.seta, "↓")}</span>
      </div>
    </div>
  );
};

// ---------- FLASH de câmera (transição curta), por cima de tudo
export const Flash: React.FC<P> = ({ e, f }) => {
  const k = interpolate(f, [e.de, e.de + 2, e.de + 9], [0, 0.85, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return k > 0 ? <div style={{ position: "absolute", inset: 0, backgroundColor: "#fff", opacity: k }} /> : null;
};

// ---------- LEGENDA: "simples" (frase a frase, branca com contorno) ou "dinamica" (2-3 palavras, palavra falada em destaque)
export const Legenda: React.FC<{ f: number; estiloEm: (q: number) => string; ocultar: Array<[number, number]> }> = ({ f, estiloEm, ocultar }) => {
  const { fps } = useVideoConfig();
  const estilo = estiloEm(f);
  const simples = useMemo(() => createTikTokStyleCaptions({ captions: palavrasSaida.map((w, i) => ({ text: (i ? " " : "") + w.text, startMs: w.startMs, endMs: w.endMs, timestampMs: null, confidence: null })), combineTokensWithinMilliseconds: 1100 }).pages, []);
  const dinamica = useMemo(() => createTikTokStyleCaptions({ captions: palavrasSaida.map((w, i) => ({ text: (i ? " " : "") + w.text, startMs: w.startMs, endMs: w.endMs, timestampMs: null, confidence: null })), combineTokensWithinMilliseconds: 500 }).pages, []);
  if (estilo === "nenhuma" || ocultar.some(([a, b]) => f >= a && f < b)) return null;
  const ms = (f / fps) * 1000;
  const pg = (estilo === "simples" ? simples : dinamica).find((p) => ms >= p.startMs && ms < p.startMs + p.durationMs);
  if (!pg) return null;
  // com a pessoa no cartão a legenda desce para o peito (não fica em cima da boca)
  const top = plano.palco?.legendaTop && fatorPalco(f).k > 0.5 ? plano.palco.legendaTop : layout.legendaTop;
  if (estilo === "neon") {
    // tubo de neon: a palavra "acende" (pisca e firma) quando é falada; as próximas ficam com o tubo apagado
    const cores = [plano.legenda?.corNeon ?? "#4DF3FF", plano.legenda?.corNeon2 ?? "#FF4FD8"];
    const c = cores[Math.floor(pg.startMs / 1000) % 2];
    return (
      <div style={{ position: "absolute", left: 40, right: 40, top: top - 30, display: "flex", flexWrap: "wrap", justifyContent: "center", gap: "6px 26px" }}>
        {pg.tokens.map((t, i) => {
          const q0 = Math.round((t.fromMs / 1000) * fps);
          const aceso = f >= q0;
          const brilho = aceso ? [0.25, 1, 0.45, 1, 0.8, 1][Math.min(5, f - q0)] : 0;
          return (
            <span key={i} style={{ display: "inline-block", fontFamily: PESADA, fontSize: 104, lineHeight: 1.04, textTransform: "uppercase", letterSpacing: 1, color: aceso ? "#FFFFFF" : "transparent", WebkitTextStroke: aceso ? "0px" : `3px ${c}`, opacity: aceso ? 0.35 + 0.65 * brilho : 0.55, textShadow: aceso ? `0 0 6px #fff, 0 0 16px ${c}, 0 0 34px ${c}, 0 0 64px ${c}, 0 0 110px ${c}` : `0 0 10px ${c}55`, scale: String(aceso ? 1 + 0.06 * (1 - ease(f, q0, q0 + 6)) : 0.96) }}>
              {t.text.trim()}
            </span>
          );
        })}
      </div>
    );
  }
  if (estilo === "pequena") {
    return (
      <div style={{ position: "absolute", left: 90, right: 90, top, display: "flex", flexWrap: "wrap", justifyContent: "center", gap: "4px 16px" }}>
        {pg.tokens.map((t, i) => {
          const ativo = ms >= t.fromMs && ms < t.toMs + 40;
          if (ms < t.fromMs) return null;
          const q = ease(f, Math.round((t.fromMs / 1000) * fps), Math.round((t.fromMs / 1000) * fps) + 4);
          return (
            <span key={i} style={{ display: "inline-block", fontFamily: PESADA, fontSize: 60, lineHeight: 1.1, color: ativo ? DESTAQUE : "#fff", textShadow: "0 3px 12px rgba(0,0,0,.85), 0 0 3px rgba(0,0,0,.9)", scale: String(0.85 + 0.15 * q), opacity: q }}>
              {t.text.trim()}
            </span>
          );
        })}
      </div>
    );
  }
  if (estilo === "dinamica") {
    return (
      <div style={{ position: "absolute", left: 50, right: 50, top: top - 20, display: "flex", flexWrap: "wrap", justifyContent: "center", gap: 18 }}>
        {pg.tokens.map((t, i) => {
          const ativo = ms >= t.fromMs && ms < t.toMs + 40;
          const q = ease(f, Math.round((t.fromMs / 1000) * fps), Math.round((t.fromMs / 1000) * fps) + 4);
          return (
            <span key={i} style={{ display: "inline-block", padding: "4px 16px", borderRadius: 16, fontFamily: "Impact, 'Arial Black', sans-serif", fontSize: 92, lineHeight: 1.05, textTransform: "uppercase", color: ativo ? ESCURO : "#fff", backgroundColor: ativo ? DESTAQUE : "transparent", WebkitTextStroke: ativo ? "0px" : "8px rgba(0,0,0,.92)", paintOrder: "stroke fill", rotate: ativo ? `${-3 + 6 * (i % 2)}deg` : "0deg", scale: String(ms >= t.fromMs ? 0.9 + 0.1 * q + (ativo ? 0.08 : 0) : 0.9), opacity: ms >= t.fromMs ? 1 : 0.5 }}>
              {t.text.trim()}
            </span>
          );
        })}
      </div>
    );
  }
  return (
    <div style={{ position: "absolute", left: 80, right: 80, top, display: "flex", justifyContent: "center" }}>
      <div style={{ maxWidth: 920, textAlign: "center", fontFamily: PESADA, fontWeight: 800, fontSize: 66, lineHeight: 1.12, color: "#fff", WebkitTextStroke: "9px rgba(0,0,0,.92)", paintOrder: "stroke fill", textShadow: "0 4px 18px rgba(0,0,0,.6)", textWrap: "balance" }}>{pg.text.trim()}</div>
    </div>
  );
};

// ---------- HUD "EDITANDO AO VIVO": relógio + contador de comandos (efeitos com "hud")
export const HUD: React.FC<{ f: number; titulo: string; passos: Array<{ q: number; nome: string }> }> = ({ f, titulo, passos }) => {
  const { fps } = useVideoConfig();
  const atual = passos.filter((p) => p.q <= f).length;
  const passo = passos[Math.max(0, atual - 1)];
  const troca = passo ? ease(f, passo.q, passo.q + 8) : 1;
  const seg = Math.floor(f / fps), qd = f % fps;
  const relogio = `00:${String(Math.floor(seg / 60)).padStart(2, "0")}:${String(seg % 60).padStart(2, "0")}:${String(qd).padStart(2, "0")}`;
  const total = String(passos.length).padStart(2, "0");
  return (
    <div style={{ position: "absolute", left: 44, top: plano.hud?.top ?? 96, display: "flex", alignItems: "center", gap: 18, padding: "14px 26px", borderRadius: 40, fontFamily: FONTE, fontSize: 27, color: "#fff", ...vidro }}>
      <div style={{ width: 14, height: 14, borderRadius: 7, backgroundColor: "#ff4d4d", boxShadow: "0 0 12px #ff4d4d", opacity: 0.55 + 0.45 * Math.abs(Math.sin(f / 9)) }} />
      <span style={{ fontWeight: 800, letterSpacing: 2 }}>{titulo}</span>
      <span style={{ color: "rgba(255,255,255,.55)", fontVariantNumeric: "tabular-nums" }}>{relogio}</span>
      <span style={{ width: 1.5, height: 26, backgroundColor: "rgba(255,255,255,.25)" }} />
      <span style={{ color: DESTAQUE, fontWeight: 800, fontVariantNumeric: "tabular-nums" }}>{String(Math.max(1, atual)).padStart(2, "0")}/{total}</span>
      <span style={{ fontWeight: 700, opacity: troca, whiteSpace: "nowrap" }}>{passo?.nome}</span>
    </div>
  );
};

// ---------- RÓTULO do trecho "bruto": a gravação original, para o antes/depois (entra sozinho com [a, b, "bruto"] nos cortes)
export const RotuloBruto: React.FC<{ f: number; de: number; ate: number; inicioOriginal: number; caixa: { top: number; height: number } }> = ({ f, de, ate, inicioOriginal, caixa }) => {
  const { fps } = useVideoConfig();
  const v = janela(f, de, ate, 8, 4);
  const t = inicioOriginal + (f - de) / fps;
  const tc = `${String(Math.floor(t / 60)).padStart(2, "0")}:${String(Math.floor(t % 60)).padStart(2, "0")}`;
  const sobe = 30 * (1 - ease(f, de, de + 12));
  return (
    <>
      <div style={{ position: "absolute", left: 0, right: 0, top: caixa.top - 250 + sobe, opacity: v, display: "flex", flexDirection: "column", alignItems: "center", gap: 18 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "12px 26px", borderRadius: 40, fontFamily: FONTE, fontSize: 30, fontWeight: 800, letterSpacing: 3, color: "#fff", ...vidro }}>
          <div style={{ width: 16, height: 16, borderRadius: 8, backgroundColor: "#ff4d4d", boxShadow: "0 0 12px #ff4d4d", opacity: 0.5 + 0.5 * Math.abs(Math.sin(f / 8)) }} />
          GRAVAÇÃO ORIGINAL
        </div>
        <div style={{ fontFamily: PESADA, fontSize: 92, lineHeight: 1, color: "#fff", letterSpacing: -1 }}>SEM EDIÇÃO</div>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: caixa.top + caixa.height + 36 - sobe, opacity: v, display: "flex", justifyContent: "center", gap: 22, fontFamily: FONTE, fontSize: 30, fontWeight: 700, color: "rgba(255,255,255,.7)" }}>
        <span>sem cortes</span><span style={{ color: "rgba(255,255,255,.3)" }}>·</span><span>sem cor</span><span style={{ color: "rgba(255,255,255,.3)" }}>·</span><span>sem legenda</span>
      </div>
      <div style={{ position: "absolute", right: 22, top: caixa.top + 18, opacity: v, padding: "6px 14px", borderRadius: 10, backgroundColor: "rgba(0,0,0,.55)", fontFamily: "Consolas, monospace", fontSize: 26, fontWeight: 700, color: "#fff", fontVariantNumeric: "tabular-nums" }}>{tc}</div>
    </>
  );
};

// ---------- SEGUE A MÃO: um rótulo que acompanha a mão (ou qualquer ponto) do quadro.
// "pontos": [[segundo do original, x, y], ...] com x e y de 0 a 1 do quadro ORIGINAL (o Claude marca olhando os quadros).
// "texto": o que aparece; "lado": "cima" (padrão) ou "baixo" em relação ao ponto.
export const Segue: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 8, 8);
  const pts = (Array.isArray(e.pontos) ? e.pontos : []) as Array<[number, number, number]>;
  if (v <= 0 || pts.length === 0) return null;
  const t = paraOriginal(f);
  let k = pts.findIndex((p) => p[0] > t);
  if (k < 0) k = pts.length;
  const A = pts[Math.max(0, k - 1)], B = pts[Math.min(pts.length - 1, k)];
  const u = B[0] > A[0] ? Math.max(0, Math.min(1, (t - A[0]) / (B[0] - A[0]))) : 0;
  const sua = u * u * (3 - 2 * u);
  const xo = A[1] + (B[1] - A[1]) * sua, yo = A[2] + (B[2] - A[2]) * sua;
  // do quadro original para a tela (anda junto com o reenquadre e com o plano aberto)
  const cx = caixaVideo(Math.max(0, pecaEm(f)), f);
  const x = cx.left + xo * cx.width;
  const y = cx.top + yo * cx.height;
  const baixo = e.lado === "baixo";
  const cor = s(e.cor, DESTAQUE);
  const texto = s(e.texto, "ACOMPANHA A MÃO");
  // o rótulo segue o ponto, mas nunca sai da tela
  const meia = (texto.length * 50 * 0.6 + 60) / 2;
  const xr = Math.max(meia + 24, Math.min(1080 - meia - 24, x));
  return (
    <div style={{ position: "absolute", left: 0, top: 0, width: 1080, height: 1920, opacity: v, pointerEvents: "none" }}>
      <div style={{ position: "absolute", left: x - 34, top: y - 34, width: 68, height: 68, borderRadius: 34, border: `5px solid ${cor}`, boxShadow: `0 0 24px ${cor}, inset 0 0 18px ${cor}88`, scale: String(0.9 + 0.1 * Math.sin(f / 5)) }} />
      <div style={{ position: "absolute", left: xr, top: baixo ? y + 70 : y - 70, translate: baixo ? "-50% 0" : "-50% -100%", whiteSpace: "nowrap", padding: "16px 30px", borderRadius: 999, fontFamily: PESADA, fontSize: 50, color: "#fff", ...vidro, border: `2px solid ${cor}`, boxShadow: `0 0 30px ${cor}66, 0 14px 40px rgba(0,0,0,.4)` }}>{texto}</div>
    </div>
  );
};

// ---------- BRASIL: mapa em pontos com uma porcentagem acesa (dado REAL, com a fonte na tela).
// "porcentagem": parte acesa (0 a 100); "titulo": frase grande; "texto": explicação; "fonte": de onde veio o dado.
const pontosBrasil = (() => {
  const poli = BRASIL.d.slice(1, -1).split("L").map((p) => p.split(" ").map(Number));
  const dentro = (x: number, y: number) => {
    let c = false;
    for (let i = 0, j = poli.length - 1; i < poli.length; j = i++) {
      const [xi, yi] = poli[i], [xj, yj] = poli[j];
      if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) c = !c;
    }
    return c;
  };
  const out: Array<{ x: number; y: number; r: number }> = [];
  const passo = 30;
  for (let y = passo / 2; y < BRASIL.altura; y += passo)
    for (let x = passo / 2; x < BRASIL.largura; x += passo)
      if (dentro(x, y)) {
        // sorteio fixo por ponto (mistura de bits): espalha os acesos sem formar listras
        let h = Math.imul(Math.round(x) * 73856093 ^ Math.round(y) * 19349663, 1);
        h = Math.imul(h ^ (h >>> 16), 2246822507);
        h = Math.imul(h ^ (h >>> 13), 3266489909);
        h ^= h >>> 16;
        out.push({ x, y, r: (h >>> 0) / 4294967296 });
      }
  return out;
})();
const ordemBrasil = [...pontosBrasil].sort((a, b) => a.r - b.r);
export const Brasil: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 10, 8);
  if (v <= 0) return null;
  const pct = n(e.porcentagem, 30) / 100;
  const cor = s(e.cor, DESTAQUE);
  const L = 760, esc = L / BRASIL.largura, H = BRASIL.altura * esc;
  const x0 = (1080 - L) / 2, y0 = n(e.y, 330);
  const acesos = new Set(ordemBrasil.slice(0, Math.round(ordemBrasil.length * pct)));
  const acende = ease(f, e.de + 22, e.de + 40);
  return (
    <div style={{ position: "absolute", inset: 0, opacity: v, backgroundColor: "rgba(5,10,18,.82)" }}>
      <svg width={1080} height={1920} style={{ position: "absolute", inset: 0 }}>
        <path d={BRASIL.d} transform={`translate(${x0} ${y0}) scale(${esc})`} fill="none" stroke="rgba(255,255,255,.2)" strokeWidth={3 / esc} />
        {pontosBrasil.map((p, i) => {
          const aparece = ease(f, e.de + 4 + (p.y / BRASIL.altura) * 16, e.de + 10 + (p.y / BRASIL.altura) * 16);
          const on = acesos.has(p) ? acende : 0;
          return <circle key={i} cx={x0 + p.x * esc} cy={y0 + p.y * esc} r={8.5 * aparece} fill={on > 0 ? cor : "rgba(255,255,255,.24)"} opacity={on > 0 ? 0.4 + 0.6 * on : 1} style={on > 0 ? { filter: `drop-shadow(0 0 8px ${cor})` } : undefined} />;
        })}
      </svg>
      <div style={{ position: "absolute", left: 0, right: 0, top: y0 - 100, display: "flex", justifyContent: "center", gap: 40, fontFamily: FONTE, fontSize: 30, fontWeight: 800, letterSpacing: 2, color: "#fff", opacity: ease(f, e.de + 24, e.de + 36) }}>
        <span style={{ display: "flex", alignItems: "center", gap: 12 }}><i style={{ width: 20, height: 20, borderRadius: 10, backgroundColor: cor, boxShadow: `0 0 10px ${cor}` }} />{s(e.legendaAceso, "JÁ USAM")}</span>
        <span style={{ display: "flex", alignItems: "center", gap: 12 }}><i style={{ width: 20, height: 20, borderRadius: 10, backgroundColor: "rgba(255,255,255,.3)" }} />{s(e.legendaApagado, "AINDA NÃO")}</span>
      </div>
      <div style={{ position: "absolute", left: 60, right: 60, top: y0 + H + 50, textAlign: "center", fontFamily: FONTE, color: "#fff", opacity: ease(f, e.de + 30, e.de + 42) }}>
        <div style={{ fontFamily: PESADA, fontSize: 112, lineHeight: 1, letterSpacing: -2 }}>{s(e.titulo)}</div>
        <div style={{ marginTop: 22, fontSize: 44, fontWeight: 700, lineHeight: 1.2, color: "rgba(255,255,255,.88)", textWrap: "balance" }}>{s(e.texto)}</div>
        <div style={{ marginTop: 26, fontSize: 28, fontWeight: 600, color: "rgba(255,255,255,.55)" }}>{s(e.fonte)}</div>
      </div>
    </div>
  );
};

// ---------- BRASIL compacto (para usar com "palco"): mapa com pontos à esquerda e "X DE 10" contando à direita,
// com 10 bonequinhos acendendo um a um. "porcentagem" (pontos acesos no mapa), "inicio"/"fim" (ex.: 0 -> 7), "conta"/"chega",
// "titulo", "texto", "fonte", "rotulo" (o que os bonequinhos acesos significam), "corPessoa"
export const BrasilPalco: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 10, 8);
  if (v <= 0) return null;
  const pct = n(e.porcentagem, 30) / 100;
  const cor = s(e.cor, DESTAQUE);
  const corP = s(e.corPessoa, "#FF7A59");
  const L = n(e.largura, 450), esc = L / BRASIL.largura;
  const x0 = 50, y0 = n(e.y, 190);
  const acesos = new Set(ordemBrasil.slice(0, Math.round(ordemBrasil.length * pct)));
  const acende = ease(f, e.de + 22, e.de + 40);
  const conta = n(e.conta, e.de + 30), chega = n(e.chega, conta + 20);
  const ini = n(e.inicio, 0), fim = n(e.fim, 7);
  const val = Math.round(interpolate(f, [conta, chega], [ini, fim], LIMITE));
  const bate = ease(f, chega, chega + 5) * (1 - ease(f, chega + 5, chega + 14));
  return (
    <div style={{ position: "absolute", inset: 0, opacity: v }}>
      <svg width={1080} height={1920} style={{ position: "absolute", left: 0, top: 0 }}>
        <path d={BRASIL.d} transform={`translate(${x0} ${y0}) scale(${esc})`} fill="rgba(255,255,255,.04)" stroke="rgba(255,255,255,.3)" strokeWidth={3 / esc} />
        {pontosBrasil.map((p, i) => {
          const aparece = ease(f, e.de + 4 + (p.y / BRASIL.altura) * 16, e.de + 10 + (p.y / BRASIL.altura) * 16);
          const on = acesos.has(p) ? acende : 0;
          return <circle key={i} cx={x0 + p.x * esc} cy={y0 + p.y * esc} r={5.5 * aparece} fill={on > 0 ? cor : "rgba(255,255,255,.28)"} opacity={on > 0 ? 0.4 + 0.6 * on : 1} />;
        })}
        {/* marcadores pulsando em algumas capitais (posições relativas ao mapa) */}
        {[[0.78, 0.62], [0.72, 0.7], [0.62, 0.55], [0.86, 0.3], [0.5, 0.35], [0.66, 0.82]].map(([px, py], i) => {
          const k = ease(f, e.de + 14 + i * 4, e.de + 20 + i * 4);
          const pul = ((f + i * 9) % 40) / 40;
          const cx = x0 + px * L, cy = y0 + py * BRASIL.altura * esc;
          return (
            <g key={i} opacity={k}>
              <circle cx={cx} cy={cy} r={10 + 26 * pul} fill="none" stroke={corP} strokeWidth={3} opacity={1 - pul} />
              <circle cx={cx} cy={cy} r={10} fill={corP} />
            </g>
          );
        })}
      </svg>
      <div style={{ position: "absolute", left: x0 + L + 30, right: 40, top: y0 - 10, fontFamily: FONTE, color: "#fff", opacity: ease(f, e.de + 6, e.de + 18) }}>
        <div style={{ fontSize: 30, fontWeight: 800, letterSpacing: 3, color: "rgba(255,255,255,.7)" }}>{s(e.titulo, "QUASE")}</div>
        <div style={{ fontFamily: PESADA, fontSize: 150, lineHeight: 0.95, letterSpacing: -3, scale: String(1 + 0.1 * bate), transformOrigin: "0% 50%", textShadow: `0 0 ${20 + 30 * bate}px ${corP}` }}>
          <span style={{ color: corP }}>{val}</span><span style={{ fontSize: 70 }}> DE 10</span>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 10, marginTop: 18, width: 400 }}>
          {Array.from({ length: 10 }, (_, i) => {
            const on = i < val;
            return (
              <div key={i} style={{ height: 82, display: "grid", placeItems: "center", borderRadius: 18, backgroundColor: on ? `${corP}33` : "rgba(255,255,255,.06)", border: `2px solid ${on ? corP : "rgba(255,255,255,.15)"}`, scale: on ? "1" : ".92" }}>
                <Icone nome="pessoa" tam={48} cor={on ? corP : "rgba(255,255,255,.35)"} />
              </div>
            );
          })}
        </div>
        <div style={{ marginTop: 16, fontSize: 32, fontWeight: 800, lineHeight: 1.15, color: corP, opacity: ease(f, chega, chega + 10) }}>{s(e.rotulo)}</div>
      </div>
      <div style={{ position: "absolute", left: 50, right: 50, top: y0 + BRASIL.altura * esc + 24, textAlign: "center", fontFamily: FONTE, color: "#fff", opacity: ease(f, e.de + 30, e.de + 42) }}>
        <div style={{ fontSize: 36, fontWeight: 700, lineHeight: 1.2, color: "rgba(255,255,255,.9)", textWrap: "balance" }}>{s(e.texto)}</div>
        <div style={{ marginTop: 10, fontSize: 24, fontWeight: 600, color: "rgba(255,255,255,.55)" }}>{s(e.fonte)}</div>
      </div>
    </div>
  );
};

// ---------- FUNDO do modo sem aparecer: escuro com dois brilhos que andam devagar e uma grade leve
export const Fundo: React.FC<{ f: number }> = ({ f }) => {
  const a = f / 30;
  const cor = plano.fundo?.cor ?? "#070D17";
  const b1 = plano.fundo?.brilho1 ?? DESTAQUE;
  const b2 = plano.fundo?.brilho2 ?? "#FFB547";
  return (
    <AbsoluteFill style={{ backgroundColor: cor, overflow: "hidden" }}>
      <div style={{ position: "absolute", left: -160 + 260 * Math.sin(a * 0.31), top: 180 + 200 * Math.cos(a * 0.23), width: 1400, height: 1400, borderRadius: 700, background: `radial-gradient(circle, ${b1}5c, transparent 60%)` }} />
      <div style={{ position: "absolute", left: 40 + 240 * Math.cos(a * 0.27), top: 900 + 180 * Math.sin(a * 0.19), width: 1300, height: 1300, borderRadius: 650, background: `radial-gradient(circle, ${b2}40, transparent 60%)` }} />
      <div style={{ position: "absolute", left: 140, right: 140, top: 560, height: 800, borderRadius: 400, background: "radial-gradient(ellipse, rgba(255,255,255,.07), transparent 70%)" }} />
      <AbsoluteFill style={{ backgroundImage: "linear-gradient(rgba(255,255,255,.035) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.035) 1px, transparent 1px)", backgroundSize: "90px 90px", backgroundPosition: `0px ${(f * 0.6) % 90}px` }} />
    </AbsoluteFill>
  );
};

// ---------- IMAGEM de cena (modo sem aparecer, ou B-roll em tela cheia)
// "arquivo" (em public/), "modo": "cheia" (imagem em pé, cobre a tela) ou "quadro" (imagem deitada num quadro, com o
// fundo desfocado da própria imagem); "movimento": zoom-in | zoom-out | esquerda | direita; "escurece" (0 a 1, para o texto ler bem)
export const Imagem: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, n(e.entra, 6), n(e.saida, 6));
  if (v <= 0) return null;
  const t = Math.max(0, Math.min(1, (f - e.de) / Math.max(1, e.ate - e.de)));
  const mov = s(e.movimento, "zoom-in");
  const [k0, k1] = mov === "zoom-out" ? [1.16, 1.02] : [1.02, 1.14];
  const esc = k0 + (k1 - k0) * t;
  const dx = mov === "esquerda" ? -70 * t : mov === "direita" ? 70 * t : 0;
  const soco = 1 + 0.1 * (1 - ease(f, e.de, e.de + 9));
  const arq = staticFile(s(e.arquivo));
  const escurece = n(e.escurece, 0.3);
  const desfoque = n(e.desfoque, 0);
  if (s(e.modo, "cheia") === "quadro") {
    const L = n(e.largura, 1000), H = L / n(e.proporcao, 16 / 9), top = n(e.y, 300);
    return (
      <AbsoluteFill style={{ opacity: v, overflow: "hidden" }}>
        <Img src={arq} style={{ position: "absolute", left: -80, top: -80, width: 1240, height: 2080, objectFit: "cover", filter: "blur(42px) brightness(.42) saturate(1.2)" }} />
        <div style={{ position: "absolute", left: (1080 - L) / 2, top, width: L, height: H, borderRadius: 30, overflow: "hidden", boxShadow: "0 30px 80px rgba(0,0,0,.55)", border: "2px solid rgba(255,255,255,.18)", scale: String(soco) }}>
          <Img src={arq} style={{ width: "100%", height: "100%", objectFit: "cover", scale: String(esc), translate: `${dx}px 0px` }} />
        </div>
      </AbsoluteFill>
    );
  }
  return (
    <AbsoluteFill style={{ opacity: v, overflow: "hidden" }}>
      <Img src={arq} style={{ position: "absolute", left: 0, top: 0, width: 1080, height: 1920, objectFit: "cover", scale: String(esc * soco * (desfoque ? 1.1 : 1)), translate: `${dx}px 0px`, filter: desfoque ? `blur(${desfoque}px)` : undefined }} />
      <AbsoluteFill style={{ background: `linear-gradient(180deg, rgba(5,10,18,${escurece * 0.5}) 0%, rgba(5,10,18,${escurece}) 50%, rgba(5,10,18,${Math.min(0.9, escurece + 0.4)}) 100%)` }} />
    </AbsoluteFill>
  );
};

// ---------- CELULAR mostrando um vídeo (ex.: um resultado real feito pela skill). "arquivo" = vídeo em public/
export const Celular: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 12, 8);
  if (v <= 0) return null;
  const W = n(e.largura, 470), H = (W * 16) / 9, top = n(e.y, 250);
  const sobe = 80 * (1 - ease(f, e.de, e.de + 14));
  return (
    <div style={{ position: "absolute", left: (1080 - W - 28) / 2, top: top + sobe, width: W + 28, height: H + 28, padding: 14, borderRadius: 66, backgroundColor: "#0b0f14", border: "3px solid rgba(255,255,255,.28)", boxShadow: `0 40px 100px rgba(0,0,0,.6), 0 0 60px ${DESTAQUE}33`, opacity: v, rotate: `${-5 * (1 - ease(f, e.de, e.de + 18))}deg` }}>
      <div style={{ position: "relative", width: W, height: H, borderRadius: 52, overflow: "hidden", backgroundColor: "#000" }}>
        <Sequence from={e.de} layout="none">
          <OffthreadVideo src={staticFile(s(e.arquivo))} muted style={{ width: W, height: H, objectFit: "cover" }} />
        </Sequence>
        <div style={{ position: "absolute", left: "50%", top: 14, translate: "-50% 0px", width: 120, height: 30, borderRadius: 15, backgroundColor: "#000" }} />
      </div>
    </div>
  );
};

// ---------- REBOBINAR: tela de fita voltando (VHS), passando as "imagens" de trás pra frente. Para "volta a fita", "agora imagina diferente"
export const Rebobinar: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 3, 4);
  if (v <= 0) return null;
  const imgs = lista(e.imagens);
  const t = Math.max(0, Math.min(0.999, (f - e.de) / Math.max(1, e.ate - e.de)));
  const idx = Math.floor(t * Math.max(1, imgs.length));
  const treme = Math.sin(f * 7.3) * 14;
  return (
    <AbsoluteFill style={{ opacity: v, backgroundColor: "#000", overflow: "hidden" }}>
      {imgs.length ? <Img src={staticFile(imgs[idx])} style={{ position: "absolute", left: 0, top: 0, width: 1080, height: 1920, objectFit: "cover", filter: "saturate(.55) contrast(1.25) brightness(.8)", translate: `${treme}px 0px`, scale: "1.06" }} /> : null}
      <AbsoluteFill style={{ backgroundImage: "repeating-linear-gradient(0deg, rgba(0,0,0,.38) 0px, rgba(0,0,0,.38) 3px, transparent 3px, transparent 6px)" }} />
      <div style={{ position: "absolute", left: 0, right: 0, top: (f * 61) % 1920, height: 110, backgroundColor: "rgba(255,255,255,.14)", filter: "blur(8px)" }} />
      <div style={{ position: "absolute", left: 60, top: 150, fontFamily: "Consolas, monospace", fontSize: 70, fontWeight: 700, color: "#fff", textShadow: "4px 0 #ff2d55, -4px 0 #2de2ff", opacity: 0.6 + 0.4 * Math.abs(Math.sin(f / 4)) }}>◀◀ {s(e.texto, "REBOBINANDO")}</div>
    </AbsoluteFill>
  );
};

// ---------- LUZ: transição com vídeo de luz por cima (modo "clarear"). "arquivo" (em public/), "inicio" (segundo do arquivo onde a luz começa)
export const Luz: React.FC<P> = ({ e, f }) => {
  const { fps } = useVideoConfig();
  const dur = Math.max(1, e.ate - e.de);
  if (f < e.de || f >= e.ate) return null;
  const v = Math.min(1, (f - e.de) / 3, (e.ate - f) / 4);
  if (!e.arquivo) {
    // sem arquivo de luz: um feixe quente atravessa a tela (desenhado aqui mesmo, nada para baixar)
    const k = (f - e.de) / dur;
    const x = -60 + 220 * k;
    const forca = Math.sin(Math.PI * Math.min(1, Math.max(0, k)));
    const cor = s(e.cor, "#FFC27A");
    return (
      <AbsoluteFill style={{ mixBlendMode: "screen", pointerEvents: "none", opacity: forca }}>
        <div style={{ position: "absolute", inset: "-20%", background: `linear-gradient(105deg, transparent ${x - 30}%, ${cor}55 ${x - 12}%, #FFFFFFDD ${x}%, ${cor}88 ${x + 10}%, transparent ${x + 32}%)`, filter: "blur(30px)" }} />
        <div style={{ position: "absolute", inset: 0, background: `radial-gradient(ellipse at ${x}% 40%, ${cor}66, transparent 55%)` }} />
      </AbsoluteFill>
    );
  }
  return (
    <AbsoluteFill style={{ mixBlendMode: "screen", opacity: v, pointerEvents: "none" }}>
      <Sequence from={e.de} durationInFrames={dur} layout="none">
        <OffthreadVideo src={staticFile(s(e.arquivo))} trimBefore={Math.round(n(e.inicio, 0) * fps)} muted style={{ position: "absolute", left: -1166, top: 0, width: 3413, height: 1920, objectFit: "cover" }} />
      </Sequence>
    </AbsoluteFill>
  );
};

// ---------- NÚMERO grande contando (para usar com "janela"): "inicio", "fim", "conta"/"chega" (tempos), "prefixo", "sufixo", "rotulo"
export const Numero: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 10, 8);
  if (v <= 0) return null;
  const k = ease(f, n(e.conta, e.de), n(e.chega, e.de + 20));
  const val = Math.round(n(e.inicio, 0) + (n(e.fim, 0) - n(e.inicio, 0)) * k);
  const cor = s(e.cor, DESTAQUE);
  const chegou = f >= n(e.chega, e.de + 20);
  return (
    <div style={{ position: "absolute", left: n(e.x, 40), width: n(e.largura, 600), textAlign: e.x !== undefined ? "center" : undefined, top: n(e.y, 620), opacity: v, translate: `${-40 * (1 - v)}px 0px`, fontFamily: FONTE }}>
      <div style={{ fontFamily: PESADA, fontSize: n(e.tam, 200), lineHeight: 0.95, color: "#fff", letterSpacing: -4, scale: String(chegou ? 1 + 0.06 * (1 - ease(f, n(e.chega, 0), n(e.chega, 0) + 8)) : 1), transformOrigin: "0% 50%" }}>
        <span style={{ color: cor }}>{s(e.prefixo)}</span>{val}<span style={{ fontSize: "0.42em", color: cor }}>{s(e.sufixo)}</span>
      </div>
      {e.rotulo ? <div style={{ marginTop: 18, fontSize: 44, fontWeight: 800, letterSpacing: 2, color: "rgba(255,255,255,.88)", textTransform: "uppercase", lineHeight: 1.15 }}>{s(e.rotulo)}</div> : null}
    </div>
  );
};

// ---------- GRÁFICO subindo que vira dinheiro: linha que cresce + "$" no topo. "texto" (ex.: "ESCALA"), "rotulo" final (ex.: "VIRA DINHEIRO"), "chega" (momento do dinheiro)
export const Grafico: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 10, 8);
  if (v <= 0) return null;
  const k = ease(f, e.de + 4, n(e.chega, e.de + 30));
  const pts = [[0, 300], [90, 270], [170, 285], [250, 220], [330, 235], [410, 160], [490, 120], [570, 60], [640, 10]];
  const tot = pts.length - 1, vis = k * tot;
  const usados = pts.slice(0, Math.floor(vis) + 1).map((p) => [...p]);
  const fr = vis - Math.floor(vis);
  if (Math.floor(vis) < tot) { const A = pts[Math.floor(vis)], B = pts[Math.floor(vis) + 1]; usados.push([A[0] + (B[0] - A[0]) * fr, A[1] + (B[1] - A[1]) * fr]); }
  const d = usados.map((p, i) => `${i ? "L" : "M"}${p[0]} ${p[1]}`).join(" ");
  const ponta = usados[usados.length - 1];
  const dinheiro = ease(f, n(e.chega, e.de + 30), n(e.chega, e.de + 30) + 10);
  const verde = "#2FBF71";
  return (
    <div style={{ position: "absolute", left: n(e.x, 40), top: n(e.y, 560), width: 700, opacity: v, fontFamily: FONTE }}>
      <div style={{ fontFamily: PESADA, fontSize: 72, color: "#fff", marginBottom: 20 }}>{s(e.texto, "ESCALA")}</div>
      <svg width={700} height={340} viewBox="-20 -40 700 360" style={{ overflow: "visible" }}>
        {[0, 1, 2, 3].map((i) => <line key={i} x1={0} x2={660} y1={i * 100} y2={i * 100} stroke="rgba(255,255,255,.12)" strokeWidth={2} />)}
        <path d={d + ` L${ponta[0]} 320 L0 320 Z`} fill={`${verde}33`} />
        <path d={d} fill="none" stroke={verde} strokeWidth={10} strokeLinecap="round" strokeLinejoin="round" style={{ filter: `drop-shadow(0 0 12px ${verde})` }} />
        <circle cx={ponta[0]} cy={ponta[1]} r={16} fill="#fff" stroke={verde} strokeWidth={6} />
      </svg>
      <div style={{ position: "absolute", left: 520, top: -60, opacity: dinheiro, scale: String(0.6 + 0.4 * dinheiro), width: 170, height: 170, borderRadius: 85, display: "grid", placeItems: "center", background: "radial-gradient(circle at 35% 30%, #FFE08A, #FFB547 60%, #C77F12)", color: "#4A2A00", fontFamily: PESADA, fontSize: 110, boxShadow: "0 0 50px #FFB54799" }}>$</div>
      {e.rotulo ? <div style={{ marginTop: 10, opacity: dinheiro, fontFamily: PESADA, fontSize: 64, color: "#FFB547" }}>{s(e.rotulo)}</div> : null}
    </div>
  );
};

// ---------- LOGO que aparece num canto quando a ferramenta é citada: "marca" ("claude" desenha a estrela; outro texto vira um selo), "posicao" (esquerda/direita), "y"
export const Logo: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 8, 8);
  if (v <= 0) return null;
  const dir = s(e.posicao) === "direita";
  const pop = 0.5 + 0.5 * ease(f, e.de, e.de + 8) + 0.08 * Math.sin((f - e.de) / 6) * (1 - ease(f, e.de + 8, e.de + 30));
  const flut = Math.sin(f / 12) * 10;
  const marca = s(e.marca, "claude");
  return (
    <div style={{ position: "absolute", [dir ? "right" : "left"]: 60, top: n(e.y, 160) + flut, opacity: v, scale: String(pop), display: "flex", flexDirection: "column", alignItems: "center", gap: 14 }}>
      <div style={{ width: 190, height: 190, borderRadius: 48, display: "grid", placeItems: "center", backgroundColor: marca === "claude" ? "#F5EEE6" : "#0E0E10", border: "3px solid rgba(255,255,255,.35)", boxShadow: "0 20px 50px rgba(0,0,0,.45)" }}>
        {marca === "claude" ? <EstrelaClaude tam={130} giro={f * 1.2} /> : <span style={{ fontFamily: PESADA, fontSize: 46, color: "#fff", letterSpacing: -1 }}>{marca}</span>}
      </div>
      <div style={{ padding: "8px 18px", borderRadius: 999, ...vidro, fontFamily: FONTE, fontWeight: 800, fontSize: 30, color: "#fff" }}>{s(e.texto, marca === "claude" ? "Claude Code" : marca)}</div>
    </div>
  );
};

// itens com tempo próprio: [{ "texto", "em", "risca", "icone" }]
type Item = { texto?: string; em?: number; em2?: number; risca?: number; icone?: string; marca?: string };
const itensDe = (v: unknown): Item[] => (Array.isArray(v) ? (v as Item[]).map((x) => (typeof x === "string" ? { texto: x } : x)) : []);
const LIMITE = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

// ---------- CALENDÁRIO que vira as folhas contando dias (ex.: "+1 ... +4 DIAS"): "inicio", "fim", "conta", "chega", "mes" (topo), "rotulo"
export const Calendario: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 10, 8);
  if (v <= 0) return null;
  const ini = n(e.inicio, 0), fim = n(e.fim, 4);
  const conta = n(e.conta, e.de + 8), chega = n(e.chega, conta + 20);
  const val = Math.round(interpolate(f, [conta, chega], [ini, fim], LIMITE));
  const passo = (chega - conta) / Math.max(1, fim - ini);
  const ultimo = conta + Math.max(0, val - ini - 1) * passo;
  const vira = val > ini ? ease(f, ultimo, ultimo + 6) : 1;
  return (
    <div style={{ position: "absolute", left: 0, right: 0, top: n(e.y, 200), display: "flex", alignItems: "center", justifyContent: "center", gap: 46, opacity: v, scale: String(0.8 + 0.2 * ease(f, e.de, e.de + 10)) }}>
      <div style={{ width: 320, borderRadius: 40, overflow: "hidden", backgroundColor: "#fff", boxShadow: "0 24px 60px rgba(0,0,0,.45)", perspective: 800 }}>
        <div style={{ backgroundColor: "#FF5A4E", color: "#fff", fontFamily: PESADA, fontSize: 38, textAlign: "center", padding: "16px 0", letterSpacing: 4 }}>{s(e.mes, "DIAS")}</div>
        <div style={{ fontFamily: PESADA, fontSize: 190, lineHeight: 1, color: "#14161A", textAlign: "center", padding: "26px 0 34px", transform: `rotateX(${(1 - vira) * 85}deg)`, transformOrigin: "50% 0%" }}>
          <span style={{ fontSize: 110, color: "#FF5A4E" }}>{s(e.prefixo, "+")}</span>{val}
        </div>
      </div>
      <div style={{ maxWidth: 440, fontFamily: PESADA, fontSize: n(e.tam, 70), lineHeight: 1.02, color: "#fff", whiteSpace: "pre-line" }}>
        {s(e.texto, "DIAS")}
        {e.rotulo ? <div style={{ marginTop: 16, fontFamily: FONTE, fontWeight: 800, fontSize: 36, color: DESTAQUE, lineHeight: 1.15 }}>{s(e.rotulo)}</div> : null}
      </div>
    </div>
  );
};

// ---------- ETIQUETAS de problema que vão aparecendo (cada item no seu "em"); "risca" = um X vermelho em cima do item; "titulo" opcional
export const Etiquetas: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 8, 8);
  if (v <= 0) return null;
  const itens = itensDe(e.itens);
  const vermelho = "#FF5A4E";
  return (
    <div style={{ position: "absolute", left: 60, right: 60, top: n(e.y, 200), display: "flex", flexDirection: "column", alignItems: "center", gap: 22, opacity: v }}>
      {e.titulo ? <div style={{ fontFamily: PESADA, fontSize: n(e.tam, 76), color: "#fff", textAlign: "center", lineHeight: 1, marginBottom: 8, whiteSpace: "pre-line" }}>{s(e.titulo)}</div> : null}
      <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", gap: 20 }}>
        {itens.map((it, i) => {
          const t0 = typeof it.em === "number" ? it.em : e.de + 6 + i * 8;
          const k = ease(f, t0, t0 + 8);
          if (f < t0) return null;
          const x = typeof it.risca === "number" ? ease(f, it.risca, it.risca + 6) : 0;
          return (
            <div key={i} style={{ position: "relative", display: "flex", alignItems: "center", gap: 14, padding: "16px 30px", borderRadius: 60, ...vidro, scale: String(0.6 + 0.4 * k), rotate: `${(i % 2 ? 2 : -2) * (1 - k)}deg`, opacity: k }}>
              {it.icone ? <Icone nome={it.icone} tam={42} cor={DESTAQUE} /> : null}
              <span style={{ fontFamily: PESADA, fontSize: 46, color: x > 0.5 ? "rgba(255,255,255,.5)" : "#fff" }}>{it.texto}</span>
              {x > 0 ? (
                <svg width="100%" height="100%" viewBox="0 0 100 40" preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
                  <path d="M6 6 L94 34 M94 6 L6 34" stroke={vermelho} strokeWidth={4} strokeLinecap="round" fill="none" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - x} vectorEffect="non-scaling-stroke" style={{ strokeWidth: 9 }} />
                </svg>
              ) : null}
            </div>
          );
        })}
      </div>
    </div>
  );
};

// ---------- APPS: ícones de app lado a lado (ex.: Claude e Codex), cada um no seu "em"
const OpenAI: React.FC<{ tam: number; giro: number }> = ({ tam, giro }) => (
  <svg width={tam} height={tam} viewBox="-50 -50 100 100" style={{ rotate: `${giro}deg` }}>
    {[0, 60, 120, 180, 240, 300].map((a) => (
      <rect key={a} x={-9} y={-40} width={18} height={44} rx={9} fill="none" stroke="#fff" strokeWidth={7} transform={`rotate(${a})`} />
    ))}
  </svg>
);
export const Apps: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 8, 8);
  if (v <= 0) return null;
  const itens = itensDe(e.itens);
  return (
    <div style={{ position: "absolute", left: 0, right: 0, top: n(e.y, 230), display: "flex", justifyContent: "center", gap: 60, opacity: v }}>
      {itens.map((it, i) => {
        const t0 = typeof it.em === "number" ? it.em : e.de + i * 8;
        if (f < t0) return null;
        const k = ease(f, t0, t0 + 9);
        const claude = (it.marca ?? "claude") === "claude";
        const flut = Math.sin((f + i * 20) / 12) * 10;
        return (
          <div key={i} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 18, scale: String(0.4 + 0.6 * k + 0.08 * Math.sin((f - t0) / 4) * (1 - ease(f, t0 + 6, t0 + 24))), translate: `0px ${flut}px`, opacity: k }}>
            <div style={{ width: 230, height: 230, borderRadius: 58, display: "grid", placeItems: "center", backgroundColor: claude ? "#D97757" : "#0E0E10", border: "3px solid rgba(255,255,255,.3)", boxShadow: `0 24px 60px rgba(0,0,0,.5), 0 0 40px ${claude ? "#D9775766" : "#ffffff22"}` }}>
              {claude ? <EstrelaClaude tam={150} giro={f * 1.2} cor="#fff" /> : <OpenAI tam={140} giro={f * 0.8} />}
            </div>
            <div style={{ fontFamily: PESADA, fontSize: 44, color: "#fff" }}>{it.texto ?? (claude ? "Claude Code" : "Codex")}</div>
          </div>
        );
      })}
    </div>
  );
};

// ---------- FLUXO de caixinhas encadeadas (ex.: Arquivo -> Claude -> "edita esse vídeo"), cada caixa no seu "em"
export const Fluxo: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 8, 8);
  if (v <= 0) return null;
  const itens = itensDe(e.itens);
  return (
    <div style={{ position: "absolute", left: 40, right: 40, top: n(e.y, 260), display: "flex", alignItems: "center", justifyContent: "center", gap: 14, opacity: v }}>
      {itens.map((it, i) => {
        const t0 = typeof it.em === "number" ? it.em : e.de + i * 10;
        const k = ease(f, t0, t0 + 8);
        const seta = i > 0 ? ease(f, t0 - 4, t0 + 2) : 0;
        return (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 14 }}>
            {i > 0 ? <svg width={60} height={30} viewBox="0 0 60 30" style={{ opacity: seta }}><path d={`M2 15 H${2 + 46 * seta} M44 5 L56 15 L44 25`} stroke={DESTAQUE} strokeWidth={5} fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg> : null}
            <div style={{ width: 260, minHeight: 230, boxSizing: "border-box", padding: "26px 16px", borderRadius: 34, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 16, textAlign: "center", ...vidro, opacity: k, scale: String(0.6 + 0.4 * k), boxShadow: `0 0 ${30 * k}px ${DESTAQUE}55, 0 14px 40px rgba(0,0,0,.35)` }}>
              {it.marca === "ambos" ? (
                <div style={{ display: "flex", gap: 14 }}>
                  <div style={{ width: 96, height: 96, borderRadius: 26, display: "grid", placeItems: "center", backgroundColor: "#D97757" }}><EstrelaClaude tam={62} giro={f * 1.5} cor="#fff" /></div>
                  <div style={{ width: 96, height: 96, borderRadius: 26, display: "grid", placeItems: "center", backgroundColor: "#0E0E10", border: "2px solid rgba(255,255,255,.3)", opacity: typeof it.em2 === "number" ? ease(f, it.em2, it.em2 + 6) : 1, scale: String(typeof it.em2 === "number" ? 0.5 + 0.5 * ease(f, it.em2, it.em2 + 6) : 1) }}><OpenAI tam={60} giro={f} /></div>
                </div>
              ) : (
              <div style={{ width: 100, height: 100, borderRadius: 28, display: "grid", placeItems: "center", backgroundColor: it.marca === "claude" ? "#D97757" : it.marca === "codex" ? "#0E0E10" : DESTAQUE }}>
                {it.marca === "claude" ? <EstrelaClaude tam={66} giro={f * 1.5} cor="#fff" /> : it.marca === "codex" ? <OpenAI tam={62} giro={f} /> : <Icone nome={it.icone ?? "arquivo"} tam={58} cor={ESCURO} />}
              </div>
              )}
              <div style={{ fontFamily: PESADA, fontSize: 36, lineHeight: 1.05, color: "#fff", whiteSpace: "pre-line" }}>{it.texto}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

// ---------- CLAUDE simulado: janela do Claude Code, o arquivo é solto ("solta"), o pedido é digitado ("digita") e a checklist marca
export const ClaudeTela: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 10, 8);
  if (v <= 0) return null;
  const solta = n(e.solta, e.de + 6), digita = n(e.digita, solta + 14);
  const texto = s(e.texto, "edita esse vídeo");
  const kTxt = Math.floor(interpolate(f, [digita, digita + texto.length * 1.6], [0, texto.length], LIMITE));
  const arq = ease(f, solta - 10, solta);
  const itens = itensDe(e.itens);
  const fimTexto = digita + texto.length * 1.6 + 6;
  return (
    <div style={{ position: "absolute", left: 70, right: 70, top: n(e.y, 160), opacity: v, translate: `0px ${(1 - v) * 40}px` }}>
      <div style={{ borderRadius: 34, overflow: "hidden", backgroundColor: "#F5F1EA", boxShadow: "0 30px 80px rgba(0,0,0,.5)", border: "2px solid rgba(255,255,255,.4)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "18px 26px", backgroundColor: "#ECE6DC", borderBottom: "1.5px solid #ddd3c4" }}>
          {["#FF5F57", "#FEBC2E", "#28C840"].map((c) => <div key={c} style={{ width: 18, height: 18, borderRadius: 9, backgroundColor: c }} />)}
          <div style={{ marginLeft: 14, display: "flex", alignItems: "center", gap: 12, fontFamily: FONTE, fontWeight: 800, fontSize: 30, color: "#3D3929" }}>
            <EstrelaClaude tam={34} giro={f * 2} cor="#D97757" /> {s(e.titulo, "Claude Code")}
          </div>
        </div>
        <div style={{ padding: "24px 28px 28px", display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={{ alignSelf: "flex-start", display: "flex", alignItems: "center", gap: 14, padding: "14px 22px", borderRadius: 20, backgroundColor: "#fff", border: "1.5px solid #e2d9cb", opacity: arq, translate: `${(1 - arq) * 260}px ${(1 - arq) * -120}px`, rotate: `${(1 - arq) * 12}deg` }}>
            <div style={{ width: 54, height: 54, borderRadius: 14, display: "grid", placeItems: "center", backgroundColor: "#D97757" }}><Icone nome="arquivo" tam={32} cor="#fff" /></div>
            <span style={{ fontFamily: FONTE, fontWeight: 700, fontSize: 30, color: "#3D3929" }}>{s(e.arquivo, "edicao-dinamica.zip")}</span>
          </div>
          <div style={{ padding: "18px 22px", borderRadius: 22, backgroundColor: "#fff", border: "2px solid #D97757", fontFamily: FONTE, fontSize: 36, fontWeight: 600, color: "#3D3929", minHeight: 50 }}>
            {f >= digita ? texto.slice(0, kTxt) : <span style={{ color: "#a59e91" }}>Responder ao Claude...</span>}
            {f >= digita ? <span style={{ display: "inline-block", width: 3, height: 36, marginLeft: 3, verticalAlign: -5, backgroundColor: "#D97757", opacity: Math.floor(f / 8) % 2 ? 1 : 0.2 }} /> : null}
          </div>
          {itens.map((it, i) => {
            const t0 = typeof it.em === "number" ? it.em : fimTexto + i * 7;
            const ok = ease(f, t0, t0 + 5);
            if (f < t0 - 4) return null;
            return (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 16, fontFamily: FONTE, fontSize: 32, fontWeight: 600, color: "#3D3929", opacity: ease(f, t0 - 4, t0) }}>
                <div style={{ width: 36, height: 36, borderRadius: 18, border: "2.5px solid #2FA36B", backgroundColor: ok > 0.5 ? "#2FA36B" : "transparent", display: "grid", placeItems: "center" }}>
                  <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={3.6} strokeLinecap="round" strokeLinejoin="round" style={{ opacity: ok }}><path d="M5 12l5 5 9-10" /></svg>
                </div>
                {it.texto}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

// ---------- BOTÃO com cursor clicando (ex.: "Saiba mais", "Adquirir agora"); "clique" = momento do clique
export const Botao: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 10, 6);
  if (v <= 0) return null;
  const clique = n(e.clique, e.de + 18);
  const chega = ease(f, e.de + 2, clique - 1);
  const aperta = ease(f, clique, clique + 3) * (1 - ease(f, clique + 3, clique + 9));
  const onda = ease(f, clique, clique + 14);
  const y = n(e.y, 300);
  return (
    <div style={{ position: "absolute", left: 0, right: 0, top: y, display: "flex", justifyContent: "center", opacity: v }}>
      <div style={{ position: "relative" }}>
        {f >= clique ? <div style={{ position: "absolute", left: "50%", top: "50%", width: 120 + 600 * onda, height: 120 + 600 * onda, translate: "-50% -50%", borderRadius: "50%", border: `4px solid ${DESTAQUE}`, opacity: 1 - onda }} /> : null}
        <div style={{ display: "flex", alignItems: "center", gap: 18, padding: "30px 70px", borderRadius: 26, backgroundColor: s(e.cor, "#1877F2"), color: "#fff", fontFamily: FONTE, fontWeight: 800, fontSize: n(e.tam, 58), scale: String((0.85 + 0.15 * v) * (1 - 0.07 * aperta)), boxShadow: "0 18px 50px rgba(0,0,0,.45)" }}>
          {s(e.texto, "Saiba mais")}
          {e.seta ? <span style={{ fontSize: 56 }}>{s(e.seta)}</span> : null}
        </div>
        <svg width={86} height={86} viewBox="0 0 24 24" style={{ position: "absolute", left: `${50 + 70 * (1 - chega)}%`, top: `${60 + 160 * (1 - chega)}%`, scale: String(1 - 0.15 * aperta), filter: "drop-shadow(0 6px 10px rgba(0,0,0,.5))" }}>
          <path d="M5 2l13 11-6 1 3.5 7-2.6 1.2-3.4-7.2L5 19z" fill="#fff" stroke="#111" strokeWidth={1.4} strokeLinejoin="round" />
        </svg>
      </div>
    </div>
  );
};

// ---------- GANCHO: título enorme que entra palavra por palavra no 1º segundo; "destaque" pinta uma palavra; "sub" embaixo
export const Gancho: React.FC<P> = ({ e, f }) => {
  const v = janela(f, e.de, e.ate, 4, 8);
  if (v <= 0) return null;
  const linhas = s(e.texto).split("\n");
  const dest = s(e.destaque);
  let idx = 0;
  return (
    <div style={{ position: "absolute", left: 40, right: 40, top: n(e.y, 220), textAlign: "center", opacity: v }}>
      {linhas.map((l, li) => (
        <div key={li} style={{ display: "flex", justifyContent: "center", flexWrap: "wrap", gap: "0 22px" }}>
          {l.split(" ").map((w, wi) => {
            const k = ease(f, e.de + idx * n(e.ritmo, 3), e.de + idx * n(e.ritmo, 3) + 6);
            idx++;
            return <span key={wi} style={{ display: "inline-block", fontFamily: PESADA, fontSize: n(e.tam, 120), lineHeight: 1.02, color: dest && w.includes(dest) ? DESTAQUE : "#fff", opacity: k, scale: String(1.6 - 0.6 * k), textShadow: "0 8px 30px rgba(0,0,0,.5)" }}>{w}</span>;
          })}
        </div>
      ))}
      {e.sub ? <div style={{ marginTop: 22, fontFamily: FONTE, fontWeight: 800, fontSize: 40, letterSpacing: 3, color: DESTAQUE, opacity: ease(f, e.de + idx * n(e.ritmo, 3), e.de + idx * n(e.ritmo, 3) + 10) }}>{s(e.sub)}</div> : null}
    </div>
  );
};

// tabela tipo -> componente (efeitos na frente de você)
export const EFEITOS: Record<string, React.FC<P>> = {
  cartao: Cartao,
  barra: Barra,
  palavra: Palavra,
  etiqueta: Etiqueta,
  leque: Leque,
  chip: Chip,
  prompt: Prompt,
  timeline: Timeline,
  vitrine: Vitrine,
  contador: Contador,
  checklist: Checklist,
  titulo: Titulo,
  cta: CTA,
  flash: Flash,
  segue: Segue,
  brasil: Brasil,
  aberto: () => null, // tratado no Video.tsx (abre a câmera)
  imagem: Imagem,
  celular: Celular,
  rebobinar: Rebobinar,
  luz: Luz,
  numero: Numero,
  grafico: Grafico,
  logo: Logo,
  janela: () => null, // tratado no Video.tsx (a pessoa vira janelinha)
  palco: () => null, // tratado no Video.tsx (a pessoa vira um cartão grande)
  calendario: Calendario,
  brasil2: BrasilPalco,
  etiquetas: Etiquetas,
  apps: Apps,
  fluxo: Fluxo,
  claude: ClaudeTela,
  botao: Botao,
  gancho: Gancho,
};
