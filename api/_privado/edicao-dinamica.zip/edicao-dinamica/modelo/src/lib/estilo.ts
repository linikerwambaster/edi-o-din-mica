import { Easing, interpolate } from "remotion";
import { plano } from "./plano";

// Identidade visual dos efeitos. A cor de destaque pode ser trocada no plano (cores.destaque).
export const DESTAQUE = plano.cores?.destaque ?? "#8FCFEF";
export const ESCURO = plano.cores?.escuro ?? "#0B2239";
export const FONTE = "'Segoe UI', 'Helvetica Neue', Arial, sans-serif";
export const PESADA = "'Segoe UI Black', 'Arial Black', 'Helvetica Neue', Arial, sans-serif";

// entrada suave (0 -> 1) entre os quadros a e b
export const ease = (f: number, a: number, b: number) =>
  interpolate(f, [a, b], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.2, 0.9, 0.3, 1) });

// visibilidade de um elemento que entra em `de` e sai em `ate`
export const janela = (f: number, de: number, ate: number, entra = 10, sai = 8) =>
  Math.min(ease(f, de, de + entra), interpolate(f, [ate - sai, ate], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }));

// cartão de vidro escuro (legível sobre qualquer fundo)
export const vidro: React.CSSProperties = {
  backgroundColor: "rgba(8,14,24,.66)",
  backdropFilter: "blur(14px)",
  border: "1.5px solid rgba(255,255,255,.22)",
  boxShadow: "0 14px 40px rgba(0,0,0,.35), inset 0 1px 0 rgba(255,255,255,.1)",
};

// posições prontas (faixa livre acima da cabeça por padrão; ajuste com "y")
export const POSICOES: Record<string, { left?: number; right?: number; centro?: boolean }> = {
  esquerda: { left: 50 },
  direita: { right: 50 },
  centro: { centro: true },
};
