import planoJson from "../plano.json";
import palavrasJson from "../dados/palavras.json";
import fonteJson from "../dados/fonte.json";
import rostoJson from "../dados/rosto.json";

// ---------------------------------------------------------------------------
// O plano de edição (src/plano.json) é escrito pelo Claude a partir da fala.
// TODOS os tempos do plano estão em SEGUNDOS DO VÍDEO ORIGINAL (o mesmo relógio
// da transcrição em src/dados/palavras.json). Este arquivo converte esses tempos
// para quadros do vídeo JÁ CORTADO.
// ---------------------------------------------------------------------------

export const FPS = 30;

export type Efeito = { tipo: string; de: number; ate?: number; hud?: string; [k: string]: unknown };
export type Plano = {
  // vídeo gravado (em public/). No modo SEM APARECER fica vazio e entra a "narracao"
  video?: string;
  // modo SEM APARECER: áudio da narração (voz de IA ou a pessoa gravando só a voz), em public/
  narracao?: string;
  fundo?: { cor?: string; brilho1?: string; brilho2?: string };
  // [início, fim] em segundos do original. Com "bruto" no 3º campo, o trecho entra como a GRAVAÇÃO ORIGINAL
  // (sem cortes, sem cor, sem legenda) para mostrar o antes; use "videoBruto" com o arquivo sem tratamento.
  cortes: Array<[number, number] | [number, number, "bruto"]>;
  videoBruto?: string | { arquivo: string; inicio: number }; // "inicio" = de onde o arquivo foi cortado (preparar --de)
  // vídeo HORIZONTAL: centro da pessoa (0 a 1 da largura) quando não há rastreio do rosto; "seguir": false trava o enquadre
  enquadre?: { x?: number; seguir?: boolean };
  zoom?: number[] | "auto";
  origemZoom?: string;
  ganchoZoom?: boolean;
  cores?: { destaque?: string; escuro?: string };
  correcoes?: Record<string, string>;
  legenda?: {
    estilo?: "simples" | "dinamica" | "neon" | "pequena" | "nenhuma";
    top?: number;
    corNeon?: string;
    corNeon2?: string;
    trechos?: Array<{ de: number; ate: number; estilo: "simples" | "dinamica" | "neon" | "pequena" | "nenhuma" }>;
  };
  hud?: { ativo?: boolean; titulo?: string; top?: number };
  // "palco": a pessoa vira um cartão grande. largura do cartão e faixa [y0, y1] do quadro que aparece nele (a do rosto)
  // legendaTop: altura da legenda enquanto a pessoa está no cartão; alturaDeitado: altura do cartão quando o vídeo é horizontal
  palco?: { largura?: number; foco?: [number, number]; legendaTop?: number; alturaDeitado?: number };
  // onde há espaço livre no quadro (depende de onde está o rosto): faixa de cima e altura da legenda
  layout?: { topoLivre?: [number, number]; legendaTop?: number };
  recorte?: { arquivo: string; inicio: number };
  efeitos: Efeito[];
  sons?: Array<{ arquivo: string; em: number; volume?: number }>;
};

export const plano = planoJson as unknown as Plano;
// sem ninguém na câmera: só a narração + cenas (imagens, cartões, legenda)
export const semRosto = !plano.video && !!plano.narracao;

export const layout = {
  topoLivre: (plano.layout?.topoLivre ?? [170, 560]) as [number, number],
  legendaTop: plano.layout?.legendaTop ?? plano.legenda?.top ?? 1500,
};

export type Peca = { a: number; b: number; F: number; N: number; bruto: boolean };

// peças do vídeo cortado: a..b no original, começa no quadro F da saída e dura N quadros
export const pecas: Peca[] = (() => {
  let F = 0;
  return plano.cortes.map(([a, b, tipo]) => {
    const N = Math.max(1, Math.round((b - a) * FPS));
    const p = { a, b, F, N, bruto: tipo === "bruto" };
    F += N;
    return p;
  });
})();
// peças editadas (os trechos "bruto" são só demonstração: efeitos, legenda e sons usam as editadas)
const editadas = pecas.filter((p) => !p.bruto);
export const pecaEm = (q: number) => pecas.findIndex((p) => q >= p.F && q < p.F + p.N);

export const duracaoTotal = pecas.reduce((s, p) => s + p.N, 0) || 30;

// segundos do original -> quadro da saída. Se cair numa parte cortada, vai para o início da próxima peça
// (ou para o fim da anterior, quando `fim` = true).
export const paraSaida = (t: number, fim = false): number => {
  for (let i = 0; i < editadas.length; i++) {
    const p = editadas[i];
    if (t >= p.a && t <= p.b) return Math.round(p.F + (t - p.a) * FPS);
    if (t < p.a) {
      if (fim && i > 0) return editadas[i - 1].F + editadas[i - 1].N;
      return p.F;
    }
  }
  return duracaoTotal;
};

// tempo total removido (pausas, erros, repetições) entre o 1º e o último corte, em segundos
export const segundosRemovidos = (() => {
  if (!editadas.length) return 0;
  const bruto = editadas[editadas.length - 1].b - editadas[0].a;
  return Math.max(0, bruto - editadas.reduce((s, p) => s + p.N, 0) / FPS);
})();

// campos de tempo que os efeitos podem usar (todos em segundos do original)
const CAMPOS_TEMPO = ["de", "ate", "foco", "sai", "trava", "acende", "afunda", "enfase", "conta", "chega", "pulso", "corte", "troca", "clique", "digita", "solta"];

export type EfeitoQ = { tipo: string; de: number; ate: number; i: number; hud?: string; [k: string]: unknown };
// efeitos com os tempos já em quadros da saída
export const efeitos: EfeitoQ[] = plano.efeitos.map((e, i) => {
  const c: Record<string, unknown> = { ...e, i };
  for (const k of CAMPOS_TEMPO) {
    if (typeof e[k] === "number") c[k] = paraSaida(e[k] as number, k === "ate");
  }
  if (typeof e.ate !== "number") c.ate = duracaoTotal;
  // itens com tempo próprio ({ "texto": ..., "em": 12.3, "risca": 13.1 })
  if (Array.isArray(e.itens)) {
    c.itens = (e.itens as unknown[]).map((it) => {
      if (!it || typeof it !== "object") return it;
      const o: Record<string, unknown> = { ...(it as Record<string, unknown>) };
      for (const k of ["em", "em2", "risca"]) if (typeof o[k] === "number") o[k] = paraSaida(o[k] as number);
      return o;
    });
  }
  return c as EfeitoQ;
});

// palavras da fala no relógio da saída (só as que ficaram no corte), com correções de grafia
export type Palavra = { text: string; startMs: number; endMs: number };
const norm = (t: string) => t.toLowerCase().replace(/[^a-zà-ú0-9]/g, "");
// correções de grafia: a chave pode ter várias palavras ("de sonhos de vídeo": "edições de vídeo");
// a pontuação do fim da última palavra é mantida. Correção vazia ("") apaga a palavra.
const corrigidas: Palavra[] = (() => {
  const ws = palavrasJson as Palavra[];
  const regras = Object.entries(plano.correcoes ?? {}).map(([de, para]) => ({ de: de.split(/\s+/).map(norm).filter(Boolean), para }));
  regras.sort((a, b) => b.de.length - a.de.length);
  const out: Palavra[] = [];
  for (let i = 0; i < ws.length; ) {
    const r = regras.find((r) => r.de.length && r.de.every((p, k) => ws[i + k] && norm(ws[i + k].text) === p));
    if (r) {
      const ult = ws[i + r.de.length - 1];
      const pont = (ult.text.match(/[,.!?]+$/) ?? [""])[0];
      if (r.para.trim()) out.push({ text: r.para + pont, startMs: ws[i].startMs, endMs: ult.endMs });
      i += r.de.length;
    } else {
      out.push(ws[i]);
      i++;
    }
  }
  return out;
})();
export const palavrasSaida: Palavra[] = (() => {
  const out: Palavra[] = [];
  // cada palavra fica na peça onde ela COMEÇA (o início vindo da transcrição é preciso; o fim costuma "esticar" para dentro da pausa).
  // Assim, palavra que atravessa um corte não sai duplicada e pedaço de tomada descartada não aparece.
  const dona = corrigidas.map((w) => {
    const s = w.startMs / 1000;
    let k = pecas.findIndex((p) => !p.bruto && s >= p.a - 0.12 && s < p.b - 0.04);
    if (k < 0) k = pecas.findIndex((p) => !p.bruto && s >= p.a - 0.35 && s < p.a && w.endMs / 1000 > p.a + 0.15);
    return k;
  });
  for (const [k, p] of pecas.entries()) {
    for (const [j, w] of corrigidas.entries()) {
      if (dona[j] !== k) continue;
      const s = w.startMs / 1000, e = w.endMs / 1000;
      const ss = Math.max(s, p.a), ee = Math.min(e, p.b);
      out.push({ text: w.text, startMs: Math.round((p.F / FPS + (ss - p.a)) * 1000), endMs: Math.round((p.F / FPS + (ee - p.a)) * 1000) });
    }
  }
  // palavra repetida colada no corte ("para para") aparece uma vez só
  return out.filter((w) => norm(w.text) !== "").filter((w, i, arr) => !(arr[i + 1] && norm(arr[i + 1].text) === norm(w.text) && arr[i + 1].startMs - w.startMs < 700));
})();

// quadro da saída -> segundo do original (para ler o envelope da voz)
export const paraOriginal = (q: number): number => {
  for (const p of pecas) if (q >= p.F && q < p.F + p.N) return p.a + (q - p.F) / FPS;
  return pecas.length ? pecas[pecas.length - 1].b : 0;
};

// ---------------------------------------------------------------------------
// Vídeo HORIZONTAL na tela vertical: o vídeo ocupa a altura toda (1920) e cada peça é enquadrada na pessoa,
// usando o rastreio do rosto (src/dados/rosto.json, gerado por scripts/rosto.py).
// Peça em que a pessoa fica parada: enquadre fixo. Peça em que ela se mexe bastante: a câmera acompanha, suave.
// ---------------------------------------------------------------------------
export const fonte = fonteJson as { largura: number; altura: number };
export const horizontal = fonte.largura > fonte.altura;
export const LARG_TELA = horizontal ? Math.round((1920 * fonte.largura) / fonte.altura) : 1080;
type Ponto = { t: number; x: number; y: number };
const rosto = rostoJson as Ponto[];
// centro da cabeça (0 a 1) no segundo t do original, média com peso que cai devagar (sem tremer)
const xSuave = (t: number): number => {
  let soma = 0, peso = 0;
  for (const r of rosto) {
    const d = r.t - t;
    if (d < -1.6 || d > 1.6) continue;
    const w = Math.exp(-(d * d) / (2 * 0.55 * 0.55));
    soma += w * r.x;
    peso += w;
  }
  return peso > 0 ? soma / peso : NaN;
};
export const enquadres = pecas.map((p) => {
  const xs = rosto.filter((r) => r.t >= p.a && r.t <= p.b).map((r) => r.x).sort((a, b) => a - b);
  const fixo = xs.length ? xs[Math.floor(xs.length / 2)] : (plano.enquadre?.x ?? 0.5);
  const espalho = xs.length > 4 ? xs[Math.floor(xs.length * 0.9)] - xs[Math.floor(xs.length * 0.1)] : 0;
  return { fixo, segue: plano.enquadre?.seguir !== false && espalho > 0.07 };
});
// quanto o vídeo anda para a esquerda (px) para a pessoa ficar no centro da tela, no quadro q da peça i
export const deslocamento = (i: number, q: number): number => {
  if (!horizontal) return 0;
  const p = pecas[i], e = enquadres[i];
  let x = e.fixo;
  if (e.segue) {
    const s = xSuave(p.a + (q - p.F) / FPS);
    if (!Number.isNaN(s)) x = s;
  }
  return Math.max(0, Math.min(LARG_TELA - 1080, x * LARG_TELA - 540));
};

// arquivo da gravação original para os trechos "bruto" e o segundo do original em que ele começa
export const bruto = typeof plano.videoBruto === "object" ? plano.videoBruto : { arquivo: plano.videoBruto ?? plano.video ?? "", inicio: 0 };

// ---------------------------------------------------------------------------
// Onde o vídeo fica na tela em cada quadro (caixa em px da tela 1080x1920):
//  - normal: ocupa a tela (horizontal: altura toda, andando para a pessoa ficar no centro);
//  - logo depois de um trecho "bruto": sai da caixa da gravação original e abre para o vertical;
//  - efeito "aberto": a câmera abre para o quadro horizontal inteiro (ex.: para mostrar as mãos) e depois volta.
// ---------------------------------------------------------------------------
export type Caixa = { left: number; top: number; width: number; height: number };
const ALT_BRUTO = (1080 * fonte.altura) / fonte.largura;
export const CAIXA_BRUTO: Caixa = { left: 0, top: (1920 - ALT_BRUTO) / 2, width: 1080, height: ALT_BRUTO };
const LARG_ABERTA = 1200, ALT_ABERTA = (LARG_ABERTA * fonte.altura) / fonte.largura;
export const CAIXA_ABERTA: Caixa = { left: (1080 - LARG_ABERTA) / 2, top: 960 - ALT_ABERTA / 2 - 120, width: LARG_ABERTA, height: ALT_ABERTA };
const suave = (q: number, a: number, b: number) => {
  const u = Math.max(0, Math.min(1, (q - a) / (b - a)));
  return u * u * (3 - 2 * u);
};
const abertos = efeitos.filter((e) => e.tipo === "aberto");
// "janela": a pessoa vira uma janelinha no canto enquanto um número/gráfico ocupa a tela
const janelas = efeitos.filter((e) => e.tipo === "janela");
export const CAIXA_JANELA: Caixa = { left: 1080 - 40 - 380, top: 150, width: 380, height: (380 * 16) / 9 };
export const fatorJanela = (q: number): number =>
  janelas.reduce((m, e) => Math.max(m, Math.min(suave(q, e.de, e.de + 10), 1 - suave(q, e.ate - 10, e.ate))), 0);
// "palco": a pessoa vira um CARTÃO grande (o quadro inteiro encolhe; só sai a parte de baixo, o rosto fica inteiro)
// e o motion ocupa a outra metade da tela. "lado": "baixo" (padrão) ou "cima"
const palcos = efeitos.filter((e) => e.tipo === "palco");
export const palcoDeitado = horizontal;
export const PALCO = { largura: plano.palco?.largura ?? 860, foco: (plano.palco?.foco ?? [60, 1260]) as [number, number] };
export const fatorPalco = (q: number): { k: number; lado: string } => {
  let k = 0, lado = "baixo";
  for (const e of palcos) {
    const v = Math.min(suave(q, e.de, e.de + 10), 1 - suave(q, e.ate - 10, e.ate));
    if (v > k) { k = v; lado = e.lado === "cima" ? "cima" : "baixo"; }
  }
  return { k, lado };
};
export const caixaPalco = (lado: string) => {
  if (horizontal) {
    // vídeo deitado: o cartão mostra o quadro horizontal INTEIRO (nada cortado)
    // (altura maior que 16:9 = corta só as laterais, centrado na pessoa; o rosto nunca sai)
    const height = plano.palco?.alturaDeitado ?? (1000 * fonte.altura) / fonte.largura;
    return { left: 40, top: lado === "cima" ? 150 : 1920 - 70 - height, width: 1000, height, K: 1 };
  }
  const K = PALCO.largura / 1080;
  const height = (PALCO.foco[1] - PALCO.foco[0]) * K;
  return { left: (1080 - PALCO.largura) / 2, top: lado === "cima" ? 150 : 1920 - 50 - height, width: PALCO.largura, height, K };
};
// 0 = enquadre normal, 1 = quadro inteiro
export const fatorAberto = (q: number): number =>
  horizontal ? abertos.reduce((m, e) => Math.max(m, Math.min(suave(q, e.de, e.de + 14), 1 - suave(q, e.ate - 14, e.ate))), 0) : 0;
const mistura = (A: Caixa, B: Caixa, k: number): Caixa => ({
  left: A.left + (B.left - A.left) * k,
  top: A.top + (B.top - A.top) * k,
  width: A.width + (B.width - A.width) * k,
  height: A.height + (B.height - A.height) * k,
});
export const caixaVideo = (i: number, q: number): Caixa => {
  const p = pecas[i];
  if (!p) return { left: 0, top: 0, width: 1080, height: 1920 };
  if (p.bruto) return CAIXA_BRUTO;
  const normal: Caixa = horizontal ? { left: -deslocamento(i, q), top: 0, width: LARG_TELA, height: 1920 } : { left: 0, top: 0, width: 1080, height: 1920 };
  let c = mistura(normal, CAIXA_ABERTA, fatorAberto(q));
  const pl = fatorPalco(q);
  if (horizontal && pl.k > 0) {
    const cp = caixaPalco(pl.lado);
    const W2 = (cp.height * fonte.largura) / fonte.altura;
    const frac = (540 + deslocamento(i, q)) / LARG_TELA; // onde a pessoa está no quadro horizontal (0 a 1)
    const left = Math.min(cp.left, Math.max(cp.left + cp.width - W2, cp.left + cp.width / 2 - frac * W2));
    c = mistura(c, { left, top: cp.top, width: W2, height: cp.height }, pl.k);
  }
  const jn = fatorJanela(q);
  if (jn > 0) {
    // vídeo em pé: a janela mostra o rosto (corta o meio de cima do quadro)
    const alvo: Caixa = CAIXA_JANELA; // o quadro inteiro encolhe (não corta o rosto)
    c = mistura(c, alvo, jn);
  }
  if (i > 0 && pecas[i - 1].bruto) c = mistura(CAIXA_BRUTO, c, suave(q, p.F, p.F + 16));
  return c;
};
