import { AbsoluteFill, Html5Audio, OffthreadVideo, Sequence, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { EFEITOS, Fundo, HUD, Legenda, RotuloBruto } from "./efeitos/Efeitos";
import { ease } from "./lib/estilo";
import { bruto, CAIXA_BRUTO, CAIXA_JANELA, caixaPalco, caixaVideo, efeitos, fatorAberto, fatorJanela, fatorPalco, LARG_TELA, PALCO, palcoDeitado, paraSaida, pecaEm, pecas, plano, semRosto } from "./lib/plano";

// O vídeo editado. Tudo vem de src/plano.json:
//  1. cortes (peças do original, sem pausas/erros), com zoom alternado em cada corte;
//  2. efeitos guiados pela fala (na frente; ou atrás de você quando "atras": true e houver recorte);
//  3. HUD, legenda e sons.
// Sua imagem e sua voz são usadas como estão: nada de filtro de cor nem tratamento de áudio
// (cor e áudio só mudam se a pessoa pedir, no preparar.mjs). Trechos "bruto" mostram a gravação original, para o antes/depois.
export const Video: React.FC = () => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const zooms = plano.zoom === "auto" || !plano.zoom ? pecas.map((_, i) => (i % 2 ? 1.06 : 1)) : plano.zoom;
  const origem = plano.origemZoom ?? "50% 45%";

  // "zoom" de ênfase pedido no plano (ex.: "olha isso!")
  const enfase = efeitos
    .filter((e) => e.tipo === "zoom")
    .reduce((acc, e) => acc * (1 + (Number(e.intensidade ?? 0.1)) * ease(f, e.de, e.de + 4) * (1 - ease(f, e.ate - 6, e.ate))), 1);
  const gancho = plano.ganchoZoom === false ? 1 : 1 + 0.14 * (1 - ease(f, 0, 10));

  const atras = efeitos.filter((e) => e.atras === true && EFEITOS[e.tipo]);
  // imagens de cena ficam embaixo de tudo (são o "cenário"); o resto vem por cima, na ordem do plano
  const cenas = efeitos.filter((e) => e.tipo === "imagem");
  const frente = efeitos.filter((e) => e.atras !== true && e.tipo !== "imagem" && EFEITOS[e.tipo]);
  const passos = efeitos.filter((e) => typeof e.hud === "string").map((e) => ({ q: e.de, nome: e.hud as string })).sort((a, b) => a.q - b.q);

  // estilo da legenda em cada momento
  const base = plano.legenda?.estilo ?? "simples";
  const trechos = (plano.legenda?.trechos ?? []).map((t) => ({ de: paraSaida(t.de), ate: paraSaida(t.ate, true), estilo: t.estilo }));
  const estiloEm = (q: number) => trechos.find((t) => q >= t.de && q < t.ate)?.estilo ?? base;
  // sem legenda na vitrine, onde o plano pedir e nos trechos "bruto" (a gravação original aparece sem legenda)
  const ocultar: Array<[number, number]> = [
    ...efeitos.filter((e) => e.tipo === "vitrine" || e.ocultaLegenda === true).map((e): [number, number] => [e.de, e.ate]),
    ...pecas.filter((p) => p.bruto).map((p): [number, number] => [p.F, p.F + p.N]),
  ];

  const rec = plano.recorte;
  const brutoAgora = pecas[pecaEm(f)]?.bruto === true;
  const caixaBruto = CAIXA_BRUTO;
  const aberto = fatorAberto(f);
  const jn = fatorJanela(f);
  // palco: o quadro inteiro encolhe para o cartão (translate + scale) e só a faixa do rosto fica visível
  const pl = fatorPalco(f);
  const cp = caixaPalco(pl.lado);
  const kp = pl.k;
  const escPalco = 1 + (cp.K - 1) * kp;
  const palcoEstilo: React.CSSProperties | undefined = kp > 0 && palcoDeitado
    ? { clipPath: `inset(${cp.top * kp}px ${(1080 - cp.left - cp.width) * kp}px ${(1920 - cp.top - cp.height) * kp}px ${cp.left * kp}px round ${40 * kp}px)` }
    : kp > 0
    ? {
        transform: `translate(${cp.left * kp}px, ${(cp.top - PALCO.foco[0] * cp.K) * kp}px) scale(${escPalco})`,
        transformOrigin: "0 0",
        clipPath: `inset(${PALCO.foco[0] * kp}px 0px ${(1920 - PALCO.foco[1]) * kp}px 0px round ${(40 / escPalco) * kp}px)`,
      }
    : undefined;
  return (
    <AbsoluteFill style={{ backgroundColor: "#000" }}>
      {semRosto || jn > 0 || kp > 0 ? <Fundo f={f} /> : null}
      {cenas.map((e) => {
        const C = EFEITOS[e.tipo];
        return <C key={e.i} e={e} f={f} />;
      })}
      {pecas.map((p, i) => {
        if (semRosto) {
          // modo sem aparecer: cada peça é só o trecho da narração
          return (
            <Sequence key={i} name={`Narração ${i + 1} (${p.a.toFixed(2)}–${p.b.toFixed(2)} s)`} from={p.F} durationInFrames={p.N} layout="none">
              <Html5Audio src={staticFile(plano.narracao!)} trimBefore={Math.round(p.a * fps)} />
            </Sequence>
          );
        }
        if (p.bruto) {
          const arq = staticFile(bruto.arquivo);
          const ini = Math.max(0, Math.round((p.a - bruto.inicio) * fps));
          return (
            <Sequence key={i} name={`Bruto ${i + 1} (${p.a.toFixed(2)}–${p.b.toFixed(2)} s)`} from={p.F} durationInFrames={p.N} premountFor={fps}>
              <AbsoluteFill style={{ backgroundColor: "#0B0F14" }}>
                <OffthreadVideo src={arq} trimBefore={ini} muted style={{ position: "absolute", ...caixaBruto }} />
                <RotuloBruto f={f} de={p.F} ate={p.F + p.N} inicioOriginal={p.a} caixa={caixaBruto} />
              </AbsoluteFill>
              <Html5Audio src={arq} trimBefore={ini} />
            </Sequence>
          );
        }
        const t = Math.max(0, Math.min(1, (f - p.F) / p.N));
        const z = (zooms[i] ?? 1) * (1 + 0.025 * t) * (i === 0 ? gancho : 1) * enfase;
        const atrasAqui = atras.filter((e) => e.de < p.F + p.N && e.ate > p.F);
        const usaRecorte = rec && atrasAqui.length > 0 && p.a >= rec.inicio - 0.01;
        // onde o vídeo fica (reenquadre na pessoa, saída do "bruto" e plano aberto): src/lib/plano.ts
        const caixa = caixaVideo(i, f);
        const abre = i > 0 && pecas[i - 1].bruto ? ease(f, p.F, p.F + 16) : 1;
        const zoomAqui = 1 + (z - 1) * abre * (1 - aberto) * (1 - jn) * (1 - kp);
        return (
          <Sequence key={i} name={`Peça ${i + 1} (${p.a.toFixed(2)}–${p.b.toFixed(2)} s)`} from={p.F} durationInFrames={p.N} premountFor={fps}>
            {aberto > 0 ? (
              <AbsoluteFill style={{ opacity: aberto, overflow: "hidden" }}>
                <OffthreadVideo src={staticFile(plano.video!)} trimBefore={Math.round(p.a * fps)} muted style={{ position: "absolute", left: (1080 - LARG_TELA * 1.05) / 2, top: -48, width: LARG_TELA * 1.05, height: 2016, filter: "blur(38px) brightness(.45) saturate(1.1)" }} />
              </AbsoluteFill>
            ) : null}
            <AbsoluteFill style={palcoEstilo}>
            <AbsoluteFill style={{ scale: String(zoomAqui), transformOrigin: origem, clipPath: jn > 0 ? `inset(${CAIXA_JANELA.top * jn}px ${(1080 - CAIXA_JANELA.left - CAIXA_JANELA.width) * jn}px ${(1920 - CAIXA_JANELA.top - CAIXA_JANELA.height) * jn}px ${CAIXA_JANELA.left * jn}px round ${34 * jn}px)` : undefined }}>
              <OffthreadVideo src={staticFile(plano.video!)} trimBefore={Math.round(p.a * fps)} muted style={{ position: "absolute", ...caixa, borderRadius: 34 * aberto, boxShadow: aberto > 0 ? `0 30px 90px rgba(0,0,0,${0.6 * aberto})` : undefined }} />
              {usaRecorte
                ? atrasAqui.map((e) => {
                    const C = EFEITOS[e.tipo];
                    return <C key={e.i} e={e} f={f} />;
                  })
                : null}
              {usaRecorte ? (
                <OffthreadVideo src={staticFile(rec!.arquivo)} trimBefore={Math.round((p.a - rec!.inicio) * fps)} transparent muted style={{ position: "absolute", ...caixa }} />
              ) : null}
            </AbsoluteFill>
            </AbsoluteFill>
            <Html5Audio src={staticFile(plano.video!)} trimBefore={Math.round(p.a * fps)} />
          </Sequence>
        );
      })}

      {kp > 0 ? (
        // moldura do cartão (borda clara + sombra), por fora do vídeo
        <div style={{ position: "absolute", left: cp.left * kp, top: cp.top * kp, width: 1080 + (cp.width - 1080) * kp, height: 1920 + (cp.height - 1920) * kp, borderRadius: 40 * kp, border: `${3 * kp}px solid rgba(255,255,255,.55)`, boxShadow: `0 30px 90px rgba(0,0,0,${0.55 * kp})`, opacity: kp, pointerEvents: "none" }} />
      ) : null}
      {brutoAgora
        ? null
        : frente.map((e) => {
            const C = EFEITOS[e.tipo];
            // "escala" no plano aumenta (ou diminui) o efeito em volta da altura dele, útil no modo sem aparecer
            if (typeof e.escala === "number") {
              return (
                <AbsoluteFill key={e.i} style={{ scale: String(e.escala), transformOrigin: `50% ${(typeof e.y === "number" ? e.y : 1000) + 120}px` }}>
                  <C e={e} f={f} />
                </AbsoluteFill>
              );
            }
            return <C key={e.i} e={e} f={f} />;
          })}

      {brutoAgora || plano.hud?.ativo === false || passos.length === 0 ? null : <HUD f={f} titulo={plano.hud?.titulo ?? "EDITANDO AO VIVO"} passos={passos} />}
      <Legenda f={f} estiloEm={estiloEm} ocultar={ocultar} />

      {(plano.sons ?? []).map((s, i) => (
        <Sequence key={i} from={paraSaida(s.em)} durationInFrames={fps * 3} layout="none">
          <Html5Audio src={staticFile(s.arquivo)} volume={s.volume ?? 0.12} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
