# Catálogo de efeitos

Todos os campos de tempo (`de`, `ate`, `foco`, `sai`, `trava`, `acende`, `afunda`, `enfase`, `conta`, `chega`, `pulso`, `corte`) são **segundos do vídeo original**.
Campos comuns a todos: `de` (entra), `ate` (sai), `hud` (nome no contador "EDITANDO AO VIVO"), `y` (altura em px, 0 = topo), `atras` (true = desenha atrás da pessoa; precisa de `recorte`), `ocultaLegenda` (true = esconde a legenda enquanto aparece).
Padrão de altura: a faixa `layout.topoLivre` (acima da cabeça). Use `y` para mover.

| tipo | quando a pessoa fala... | campos próprios |
|---|---|---|
| `cartao` | um público, profissão, ferramenta, papel ("você que é gestor") | `texto`, `icone`, `posicao` (esquerda/direita/centro), `foco` (vai pro centro), `selo` (texto do selo no foco, ex.: "PRINCIPALMENTE"), `sai` (sai de lado), `tam` |
| `barra` | progresso, migração, "ainda não fez", antes → depois | `esquerda`, `direita`, `valor` (0–100), `trava` (momento em que trava), `textoTrava` (ex.: "0% MIGRADO"), `acende` (acende o rótulo da direita) |
| `palavra` | uma palavra forte para ficar gigante (com `atras: true` passa atrás da cabeça) | `texto` (use `\n` para 2 linhas), `tam` (padrão 230), `cor`, `afunda` (encolhe e apaga, ex.: "ficar PARA TRÁS"), `ritmo` (quadros entre letras, padrão 1.5; use ~0.5 em frases curtas) |
| `etiqueta` | preço, valor, ticket, custo | `texto`, `sub`, `simbolo` (padrão "R$"), `enfase`, `posicao` |
| `leque` | "muito mais", "vários", "vários vídeos/clientes" | `imagens` (caminhos em `public/`), `texto`, `posicao` |
| `chip` | gancho para o próximo trecho, pergunta, "vou te explicar" | `texto`, `antes` (ex.: "?"), `depois` (ex.: "↓"), `tam` |
| `prompt` | "eu falo/peço/digito para a IA" | `texto` (o pedido, que vai sendo digitado); a onda é a voz real |
| `timeline` | "cortou as pausas", "tirou os erros" | `corte` (momento das tesouradas), `titulo`, `sub`; o tempo removido é calculado dos cortes |
| `vitrine` | "coloca a legenda", "no tempo certo" | mostra as palavras com o tempo exato de cada uma (esconde a legenda normal) |
| `contador` | números ditos ("6 anos", "10 mil") | `inicio`, `fim`, `conta`, `chega`, `rotulo`, `prefixo`, `sufixo`, `digitos`, `posicao` |
| `checklist` | "faz tudo", lista de entregas | `titulo`, `itens` (lista), `passo` (quadros entre itens) |
| `titulo` | frase-tese, promessa do vídeo | `texto`, `destaque` (trecho colorido), `sub`, `selo` ("claude" mostra a estrela) |
| `cta` | chamada final ("toque em saiba mais", "clica no link") | `texto`, `seta`, `pulso` (momento em que pulsa) |
| `zoom` | "olha isso!", ênfase forte | `intensidade` (padrão 0.1 = +10%) |
| `flash` | virada de assunto, "agora...", transição | (só `de`) |
| `brasil` | um dado REAL sobre o Brasil ("7 em cada 10...") | `porcentagem` (parte acesa do mapa), `titulo`, `texto`, `fonte` (obrigatório: de onde veio o dado), `legendaAceso`, `legendaApagado`, `y`. Escurece a tela e desenha o mapa em pontos |
| `segue` | "olha minha mão", "acompanha o movimento" | `pontos`: `[[segundo, x, y], ...]` com x e y de 0 a 1 do quadro ORIGINAL, um a cada 0,25 s; `texto`; `lado` ("cima"/"baixo"). Para achar os pontos: tire quadros com grade (`ffmpeg -ss <início> -i public/video.mp4 -t 7 -vf "fps=4,drawgrid=w=iw/10:h=ih/10:t=1:c=yellow@0.4,tile=7x4" folha.jpg`), olhe e anote o centro da palma |
| `imagem` | cena com foto (modo sem aparecer ou B-roll) | `arquivo`, `modo` ("cheia" ou "quadro"), `movimento` (zoom-in, zoom-out, esquerda, direita), `escurece` (0 a 1), `desfoque` (px), `y` e `largura` no modo quadro. Fica embaixo dos outros efeitos |
| `celular` | "pronto pra postar", mostrar um resultado | `arquivo` (vídeo em public/), `y`, `largura` |
| `rebobinar` | "volta a fita", "agora imagina diferente" | `imagens` (as cenas anteriores, de trás pra frente), `texto` |
| `aberto` | algo sai do enquadre vertical (mãos abertas, objeto ao lado) | só `de`/`ate`. Vídeo HORIZONTAL: a câmera abre para o quadro inteiro (fundo desfocado) e depois volta. Use junto com `segue` quando a mão sai do corte |

Ícones disponíveis (`icone`): grafico, filme, mic, terminal, check, relogio, dinheiro, ia, pessoa, tesoura, legenda, raio, alvo, foguete, cadeado, play, usuarios, arquivo, pasta, carrinho.

## Legenda
- `legenda.estilo`: `"simples"` (frase a frase, branca com contorno; padrão), `"dinamica"` (2–3 palavras grandes, palavra falada em destaque colorido), `"neon"` (palavras em tubo de neon que acendem quando são faladas; cores em `legenda.corNeon` e `legenda.corNeon2`), `"nenhuma"`.
- Demonstração boa: `"nenhuma"` enquanto a pessoa PEDE a legenda e o estilo pedido a partir da resposta ("ela coloca uma legenda").
- `legenda.trechos`: troca o estilo num intervalo (ex.: quando a pessoa diz "agora uma legenda dinâmica").
- Correções de grafia: `correcoes` no plano.

## Ritmo
- Um elemento novo a cada 1–3 s quando a fala justifica. Silêncio visual também é ok por 1–2 s.
- No máximo 2 elementos ao mesmo tempo na faixa de cima, sem cobrir o rosto.
- Elementos saem quando o assunto muda (use `ate` / `sai`).

## Antes e depois (trecho "bruto")
Nos `cortes`, `[início, fim, "bruto"]` mostra a gravação original daquele trecho (inteira, com pausas e erros), com o rótulo "GRAVAÇÃO ORIGINAL / SEM EDIÇÃO", sem legenda, sem efeitos e sem o HUD. O corte seguinte abre da caixa da gravação para o vertical editado. Prepare o arquivo sem tratamento só do trecho (`preparar.mjs ... public/bruto.mp4 --de=.. --ate=..`) e informe `"videoBruto": { "arquivo": "bruto.mp4", "inicio": .. }`. Bom gatilho: "quer ver como eu gravei?", "olha a diferença".

## HUD
`hud.top` muda a altura do contador "EDITANDO AO VIVO" (padrão 96, abaixo da barra dos apps; em vídeo para página/VSL pode subir para 44).

## Escala
Qualquer efeito aceita `"escala"` (ex.: 1.3) para ficar maior em volta da altura `y`. Cuidado com a largura: o que passar de 1080 px é cortado.
