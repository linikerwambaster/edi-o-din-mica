// Gera o site inteiro a partir do site.json: página inicial com a rede 3D, uma página por serviço,
// página de privacidade, Pixel + API de Conversões e os arquivos que a Vercel precisa.
// Uso: node scripts/gerar.mjs [site.json] [pasta-de-saída]   (padrão: ./site.json -> ./site)
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const AQUI = path.dirname(fileURLToPath(import.meta.url));
const MODELO = path.resolve(AQUI, "..");
const ARQ = path.resolve(process.argv[2] || "site.json");
const SAIDA = path.resolve(process.argv[3] || "site");
const PASTA_CONFIG = path.dirname(ARQ);
const C = JSON.parse(fs.readFileSync(ARQ, "utf8"));
const avisos = [];

// ---------------------------------------------------------------- utilidades
const esc = (s) => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
// texto com destaque: <grifo>palavra</grifo> vira itálico com degradê; <b>...</b> vira negrito
const rico = (s) => esc(s).replace(/&lt;grifo&gt;/g, '<span class="grifo">').replace(/&lt;\/grifo&gt;/g, "</span>")
  .replace(/&lt;b&gt;/g, "<b>").replace(/&lt;\/b&gt;/g, "</b>");
const semTags = (s) => String(s ?? "").replace(/<\/?(grifo|b)>/g, "");
const hexOk = (c) => /^#[0-9a-fA-F]{6}$/.test(String(c || ""));
const mistura = (hex, alvo, t) => {
  const a = parseInt(hex.slice(1), 16), b = parseInt(alvo.slice(1), 16);
  const ca = [a >> 16, (a >> 8) & 255, a & 255], cb = [b >> 16, (b >> 8) & 255, b & 255];
  return "#" + ca.map((v, i) => Math.round(v + (cb[i] - v) * t).toString(16).padStart(2, "0")).join("").toUpperCase();
};
const acentoVars = (cor) => {
  const c = hexOk(cor) ? cor : PRINCIPAL;
  const claro = mistura(c, "#FFFFFF", 0.62);
  return `--acento:${c};--acento-2:${claro};--degrade:linear-gradient(100deg, ${claro}, ${c} 50%, ${mistura(c, "#A9C8FF", 0.5)})`;
};
const midia = (arq) => (!arq ? "" : /^https?:\/\//.test(arq) ? arq : "/assets/" + String(arq).replace(/^\.?\//, "").replace(/^assets\//, ""));
const ehVideo = (arq) => /\.(mp4|webm|mov)$/i.test(String(arq || ""));

const marca = C.marca || {};
const contato = C.contato || {};
const PRINCIPAL = hexOk(C.cores?.principal) ? C.cores.principal : "#5B8CFF";
const FUNDO = hexOk(C.cores?.fundo) ? C.cores.fundo : "#08090C";
const PIXEL = String(C.rastreamento?.pixelId || "").replace(/\D/g, "");
const paginas = (C.paginas || []).filter((p) => p && p.slug);
if (!marca.nome) avisos.push("marca.nome está vazio");
if (!paginas.length) avisos.push("nenhuma página em paginas[]: o site terá só a página inicial");
if (!PIXEL) avisos.push("sem rastreamento.pixelId: o site funciona, mas sem Pixel e sem API de Conversões");

// link de conversa: WhatsApp, direct do Instagram ou um link qualquer (agenda, checkout...)
function linkConversa(msgExtra) {
  const tipo = contato.principal || (contato.whatsapp ? "whatsapp" : contato.instagram ? "instagram" : "link");
  if (tipo === "whatsapp" && contato.whatsapp) {
    const num = String(contato.whatsapp).replace(/\D/g, "");
    const msg = msgExtra || contato.mensagemWhatsapp || "Oi! Vim pelo site.";
    return `https://wa.me/${num}?text=${encodeURIComponent(msg)}`;
  }
  if (tipo === "instagram" && contato.instagram) return `https://ig.me/m/${String(contato.instagram).replace(/^@/, "")}`;
  if (contato.link) return contato.link;
  avisos.push("contato sem WhatsApp, Instagram ou link: os botões de conversa apontam para #contato");
  return "#contato";
}
const CONVERSA = linkConversa();
const INSTA = contato.instagram ? `https://www.instagram.com/${String(contato.instagram).replace(/^@/, "")}/` : "";

function botao(texto, { href = CONVERSA, classe = "cheio", evento, origem = "" } = {}) {
  const externo = /^https?:\/\//.test(href);
  const ev = evento || (/checkout|pay\.|hotmart|kiwify|cakto|eduzz|monetizze/i.test(href) ? "InitiateCheckout" : href === CONVERSA ? "Contact" : "");
  return `<a class="botao ${classe}" href="${esc(href)}"${externo ? ' target="_blank" rel="noopener"' : ""}${ev ? ` data-evento="${ev}" data-origem="${esc(origem)}"` : ""}>${esc(texto)} <span class="seta">→</span></a>`;
}

// ---------------------------------------------------------------- ícones (traço simples, cor pelo CSS)
const P = (d) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
const ICONE = {
  anuncio: P('<path d="M3 11v2a1 1 0 0 0 1 1h2l5 4V6L6 10H4a1 1 0 0 0-1 1z"/><path d="M15 9a4 4 0 0 1 0 6M18 6a8 8 0 0 1 0 12"/>'),
  pagina: P('<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M8 14h8M8 17h5"/>'),
  whatsapp: P('<path d="M4 20l1.3-3.9A8 8 0 1 1 8 19.1L4 20z"/><path d="M9 10c.5 2 2 3.5 4 4l1.2-1.2 2 .8-.4 1.6c-3.6.4-7.6-3.6-7.2-7.2L10.2 7.6l.8 2L9.8 10.8"/>'),
  ia: P('<rect x="5" y="7" width="14" height="11" rx="3"/><path d="M12 7V4M9 12h.01M15 12h.01M9.5 15.5h5M2 12h3M19 12h3"/>'),
  pessoa: P('<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'),
  check: P('<path d="M5 12l4 4 10-10"/>'),
  lupa: P('<circle cx="11" cy="11" r="6"/><path d="M20 20l-4.5-4.5"/>'),
  casa: P('<path d="M3 21h18M5 21V10l7-5 7 5v11M9 21v-6h6v6"/>'),
  tela: P('<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>'),
  chat: P('<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/>'),
  camera: P('<rect x="2" y="7" width="14" height="11" rx="2"/><path d="M16 11l6-3v9l-6-3"/>'),
  grafico: P('<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>'),
  relogio: P('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
  seta: P('<path d="M4 12h14M13 6l6 6-6 6"/>'),
  sino: P('<path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 21h4"/>'),
  loja: P('<path d="M4 9l1-5h14l1 5M4 9v11h16V9M4 9h16M9 20v-6h6v6"/>'),
  estrela: P('<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>'),
  coracao: P('<path d="M12 20s-7-4.4-9-9a4.8 4.8 0 0 1 9-3 4.8 4.8 0 0 1 9 3c-2 4.6-9 9-9 9z"/>'),
  calendario: P('<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4M8 14h3"/>'),
  local: P('<path d="M12 21s7-6.2 7-12a7 7 0 0 0-14 0c0 5.8 7 12 7 12z"/><circle cx="12" cy="9" r="2.5"/>'),
  escudo: P('<path d="M12 3l8 3v6c0 4.5-3.4 8.2-8 9-4.6-.8-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/>'),
  presente: P('<rect x="3" y="9" width="18" height="12" rx="1"/><path d="M3 13h18M12 9v12M12 9c-1.5-3-5-3.5-5-1.2C7 9 12 9 12 9zM12 9c1.5-3 5-3.5 5-1.2C17 9 12 9 12 9z"/>'),
  livro: P('<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 19V5M8 7h7"/>'),
  ferramenta: P('<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.4-.6-.6-2.4z"/>'),
  raio: P('<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>'),
  carrinho: P('<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.6 12.4a2 2 0 0 0 2 1.6h8.2a2 2 0 0 0 2-1.5L21 8H6"/>'),
  telefone: P('<path d="M5 3h4l2 5-2.5 1.5a11 11 0 0 0 6 6L16 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 5a2 2 0 0 1 2-2z"/>'),
  folha: P('<path d="M5 19c0-8 5-14 15-15-1 10-7 15-15 15z"/><path d="M5 19l7-7"/>'),
  dente: P('<path d="M7 3c-2.5 0-4 2-4 4.5 0 3 1.5 4.5 2 7 .5 2.7 1 6.5 3 6.5s1.6-5 4-5 2 5 4 5 2.5-3.8 3-6.5c.5-2.5 2-4 2-7C21 5 19.5 3 17 3c-2 0-3 1-5 1S9 3 7 3z"/>'),
  tesoura: P('<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M8.6 7.6L20 18M8.6 16.4L20 6"/>'),
  peso: P('<path d="M6 8h12l2 12H4z"/><circle cx="12" cy="5" r="2"/>'),
};
const icone = (n) => {
  if (ICONE[n]) return ICONE[n];
  if (n) avisos.push(`ícone "${n}" não existe; usei "check". Opções: ${Object.keys(ICONE).join(", ")}`);
  return ICONE.check;
};

// ---------------------------------------------------------------- partes comuns
const MENU = paginas.map((p) => [`/${p.slug}`, p.menu || p.slug]);
const nomeMarca = esc(marca.nome || "Meu negócio");
const logo = marca.logo ? `<img src="${esc(midia(marca.logo))}" alt="" height="30">` : `<span class="letra">${esc((marca.nome || "M").trim()[0].toUpperCase())}</span>`;
const favicon = marca.logo ? midia(marca.logo)
  : "data:image/svg+xml," + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="${PRINCIPAL}"/><text x="32" y="44" font-family="Arial" font-weight="800" font-size="34" text-anchor="middle" fill="#06070A">${(marca.nome || "M").trim()[0].toUpperCase()}</text></svg>`);
const imagemCompartilhar = midia(marca.imagemCompartilhar || C.sobre?.foto || "");
const dominio = String(marca.dominio || "").replace(/^https?:\/\//, "").replace(/\/$/, "");

function cabeca(titulo, descricao, estilo, caminho) {
  return `<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(titulo)}</title>
<meta name="description" content="${esc(descricao)}">
<meta property="og:title" content="${esc(titulo)}">
<meta property="og:description" content="${esc(descricao)}">
${imagemCompartilhar ? `<meta property="og:image" content="${esc(dominio ? "https://" + dominio + imagemCompartilhar : imagemCompartilhar)}">\n` : ""}<meta property="og:type" content="website">
${dominio ? `<link rel="canonical" href="https://${esc(dominio)}${caminho === "/" ? "" : esc(caminho)}">\n` : ""}<meta name="theme-color" content="${FUNDO}">
<link rel="icon" href="${esc(favicon)}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@400;500;600;700;800&family=Instrument+Serif:ital@0;1&family=JetBrains+Mono:wght@500;600;700&display=swap">
<link rel="stylesheet" href="/assets/css/site.css?v=${VERSAO}">
<style>:root{--tinta:${FUNDO}}</style>
</head>
<body style="${estilo}">
<div class="grao" aria-hidden="true"></div>`;
}

function topo(ativo) {
  const links = MENU.map(([h, t]) => `<a href="${h}"${h === ativo ? ' class="ativo"' : ""}>${esc(t)}</a>`).join("");
  return `
<header class="topo">
  <div class="miolo">
    <a class="marca" href="/">${logo}${nomeMarca}</a>
    <nav class="menu" aria-label="Páginas">${links}</nav>
    <a class="cta-topo" href="${esc(CONVERSA)}"${/^https?:/.test(CONVERSA) ? ' target="_blank" rel="noopener"' : ""} data-evento="Contact" data-origem="topo">${esc(contato.botaoTopo || "Fale com a gente")}</a>
    <button class="burger" type="button" aria-label="Abrir menu" aria-expanded="false">☰</button>
  </div>
</header>`;
}

function rodape(pagina) {
  const links = MENU.map(([h, t]) => `<a href="${h}">${esc(t)}</a>`).join("");
  const ano = new Date().getFullYear();
  return `
<footer class="rodape" id="contato">
  <div class="miolo">
    <a class="marca" href="/">${logo}${nomeMarca}</a>
    <nav>${links}<a href="/privacidade">Privacidade</a></nav>
    <span>© ${ano} ${nomeMarca}${INSTA ? ` · <a href="${esc(INSTA)}" target="_blank" rel="noopener">@${esc(String(contato.instagram).replace(/^@/, ""))}</a>` : ""}${contato.endereco ? ` · ${esc(contato.endereco)}` : ""}</span>
  </div>
</footer>
<script>window.SITE = { pixelId: "${PIXEL}", capi: "${PIXEL ? "/api/capi" : ""}", pagina: "${esc(pagina)}" };</script>
<script src="/assets/js/site.js?v=${VERSAO}" defer></script>`;
}

function faixa(f, origem) {
  if (!f || !f.titulo) return "";
  return `
<section class="faixa">
  <div class="miolo sobe">
    <h2>${rico(f.titulo)}</h2>
    ${f.texto ? `<p>${rico(f.texto)}</p>` : ""}
    ${botao(f.botao || "Fale com a gente", { href: f.link || CONVERSA, classe: "", origem })}
  </div>
</section>`;
}

// ---------------------------------------------------------------- visuais do topo de cada página
function visual(v = {}, cor) {
  const tipo = v.tipo || "grafico";
  if (tipo === "chat") {
    const msgs = (v.mensagens || []).map((m) => `<div class="msg ${m.de === "cliente" ? "cli" : "ia"}">${esc(m.texto)}${m.hora ? `<small>${esc(m.hora)}</small>` : ""}</div>`).join("\n    ");
    return `<div class="painel sobe d2" data-anima>
  <div class="painel-topo"><i></i><i></i><i></i><span>${esc(v.rotulo || "WhatsApp · atendimento")}</span></div>
  <div class="chat" id="chat">
    ${msgs}
    <div class="digitando"><i></i><i></i><i></i></div>
  </div>
</div>`;
  }
  if (tipo === "video" || tipo === "imagem") {
    if (!v.arquivo) avisos.push(`visual "${tipo}" sem arquivo`);
    const m = tipo === "video" || ehVideo(v.arquivo)
      ? `<video src="${esc(midia(v.arquivo))}"${v.capa ? ` poster="${esc(midia(v.capa))}"` : ""} muted autoplay loop playsinline preload="metadata"></video>`
      : `<img src="${esc(midia(v.arquivo))}" alt="${esc(v.legenda || "")}">`;
    const tags = (v.tags || []).map((t, i) => `<span class="tag" style="top:${i === 0 ? "14px" : `calc(${(100 / (v.tags.length)) * i}% + 12px)`}">${esc(t)}</span>`).join("");
    return `<div class="espelho sobe d2">
  ${m}
  ${tags}${v.varredura === false ? "" : '<span class="scan"></span>'}
</div>`;
  }
  const selos = (v.selos || []).map((s) => `<span>${esc(s)}</span>`).join("");
  if (tipo === "barras") {
    return `<div class="painel sobe d2" data-anima>
  <div class="painel-topo"><i></i><i></i><i></i><span>${esc(v.rotulo || "Painel")}</span></div>
  <div class="barras"><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
  ${selos ? `<div class="selos">${selos}</div>` : ""}
</div>`;
  }
  // gráfico que se desenha
  const id = "g" + Math.random().toString(36).slice(2, 7);
  return `<div class="painel sobe d2" data-anima>
  <div class="painel-topo"><i></i><i></i><i></i><span>${esc(v.rotulo || "Painel")}</span></div>
  <svg viewBox="0 0 420 170" style="width:100%;margin-top:16px" aria-hidden="true">
    <defs><linearGradient id="${id}" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="${cor}" stop-opacity=".35"/><stop offset="1" stop-color="${cor}" stop-opacity="0"/></linearGradient></defs>
    <path d="M0 150 L0 130 C 60 128, 80 118, 120 112 S 190 100, 230 80 S 320 52, 420 30 L420 150 Z" fill="url(#${id})"/>
    <path d="M0 130 C 60 128, 80 118, 120 112 S 190 100, 230 80 S 320 52, 420 30" fill="none" stroke="${cor}" stroke-width="3" stroke-dasharray="600" stroke-dashoffset="600">
      <animate attributeName="stroke-dashoffset" from="600" to="0" dur="2.4s" fill="freeze" begin="0.4s"/></path>
    <g stroke="rgba(255,255,255,.07)"><path d="M0 40H420M0 80H420M0 120H420"/></g>
  </svg>
  ${selos ? `<div class="selos">${selos}</div>` : ""}
</div>`;
}

// mini visual do cartão da página inicial (lembra o visual da página)
function miniVisual(p) {
  const v = p.visual || {};
  if ((v.tipo === "video" || v.tipo === "imagem") && v.arquivo) {
    return ehVideo(v.arquivo) ? `<div class="mini-midia"><video src="${esc(midia(v.arquivo))}" muted autoplay loop playsinline preload="metadata"></video></div>`
      : `<div class="mini-midia"><img src="${esc(midia(v.arquivo))}" alt="" loading="lazy"></div>`;
  }
  if (v.tipo === "chat") {
    return `<svg class="fluxo-mini" viewBox="0 0 320 86" aria-hidden="true">
          <path id="m-${esc(p.slug)}" class="lig" d="M38 43 C 80 43, 90 20, 130 20 S 180 43, 220 43 S 260 66, 290 66"/>
          <circle class="no" cx="38" cy="43" r="14"/><circle class="no" cx="130" cy="20" r="14"/><circle class="no" cx="220" cy="43" r="14"/><circle class="no" cx="290" cy="66" r="14"/>
          <circle class="pacote" r="5"><animateMotion dur="2.6s" repeatCount="indefinite"><mpath href="#m-${esc(p.slug)}"/></animateMotion></circle>
        </svg>`;
  }
  return `<div class="barras"><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>`;
}

// ---------------------------------------------------------------- seções (as mesmas peças servem para qualquer página)
function cabecalhoSecao(s) {
  return `${s.etiqueta ? `<span class="etiqueta sobe">${esc(s.etiqueta)}</span>` : ""}
    ${s.titulo ? `<h2 class="sobe d1" style="margin-top:16px;max-width:900px">${rico(s.titulo)}</h2>` : ""}
    ${s.texto ? `<p class="lead sobe d2" style="margin-top:18px">${rico(s.texto)}</p>` : ""}`;
}
const atrasos = ["", "d1", "d2"];
const SECOES = {
  itens: (s) => `<div class="grade">${(s.itens || []).map((it, i) => `<div class="item sobe ${atrasos[i % 3]}"><div class="ic">${icone(it.icone)}</div><h3>${rico(it.titulo)}</h3><p>${rico(it.texto)}</p></div>`).join("\n      ")}</div>`,
  passos: (s) => `<div class="fases">${(s.passos || []).map((f) => `<div class="fase sobe"><span class="quando">${esc(f.quando || "")}</span><div><h3>${rico(f.titulo)}</h3><p>${rico(f.texto)}</p></div></div>`).join("\n      ")}</div>`,
  "pra-quem": (s) => `<div class="duas">
      <div class="lista sobe"><h3>${esc(s.tituloSim || "É pra você se")}</h3><ul>${(s.sim || []).map((x) => `<li>${rico(x)}</li>`).join("")}</ul></div>
      <div class="lista sobe nao"><h3>${esc(s.tituloNao || "Não é pra você se")}</h3><ul>${(s.nao || []).map((x) => `<li>${rico(x)}</li>`).join("")}</ul></div>
    </div>`,
  fluxo: (s) => `<div class="fluxo-html sobe" id="fluxo" style="--n:${Math.max(2, (s.passos || []).length)}">${(s.passos || []).map((n) => `<div class="no"><div class="ic">${icone(n.icone)}</div><b>${esc(n.titulo)}</b><small>${esc(n.texto || "")}</small></div>`).join("\n      ")}</div>`,
  caminho: (s) => `<div class="caminho" style="--n:${Math.max(2, (s.etapas || []).length)}"><i class="fio"></i>${(s.etapas || []).map((e) => `<div class="etapa"><div class="bola" style="color:var(--acento-2)">${icone(e.icone)}</div><div><b>${esc(e.titulo)}</b><small>${esc(e.texto || "")}</small></div></div>`).join("\n      ")}</div>`,
  nota: (s) => `<div class="honesto sobe">${s.destaque ? `<b>${rico(s.destaque)}</b> ` : ""}${rico(s.texto)}</div>`,
  perguntas: (s) => `<div class="perguntas">${(s.itens || []).map((q) => `<details class="sobe"><summary>${esc(q.p)}</summary><p>${rico(q.r)}</p></details>`).join("\n      ")}</div>`,
  galeria: (s) => `<div class="galeria">${(s.midias || []).map((m, i) => `<figure class="sobe ${atrasos[i % 3]}">${ehVideo(m.arquivo) ? `<video src="${esc(midia(m.arquivo))}" muted autoplay loop playsinline preload="metadata"></video>` : `<img src="${esc(midia(m.arquivo))}" alt="${esc(m.legenda || "")}" loading="lazy">`}${m.legenda ? `<figcaption>${esc(m.legenda)}</figcaption>` : ""}</figure>`).join("\n      ")}</div>`,
  texto: (s) => `<div class="texto-livre sobe">${(s.paragrafos || []).map((t) => `<p>${rico(t)}</p>`).join("")}</div>`,
  // escape: HTML próprio para algo que o modelo não tem (mapa, formulário, vídeo do YouTube...)
  html: (s) => String(s.html || ""),
};
function secao(s, i) {
  const fn = SECOES[s.tipo];
  if (!fn) { avisos.push(`seção de tipo "${s.tipo}" não existe (use: ${Object.keys(SECOES).join(", ")})`); return ""; }
  // a nota não tem cabeçalho próprio: entra colada na seção anterior
  if (s.tipo === "nota") return `<section class="bloco" style="padding-top:0"><div class="miolo">${fn(s)}</div></section>`;
  return `
<section class="bloco"${s.id ? ` id="${esc(s.id)}"` : ""} style="padding-top:${i === 0 ? "20px" : "0"}">
  <div class="miolo">
    ${cabecalhoSecao(s)}
    ${fn(s)}
  </div>
</section>`;
}

function sobre(s) {
  if (!s || !s.titulo) return "";
  return `
<section class="bloco" style="padding-top:0">
  <div class="miolo quem${s.foto ? "" : " sem-foto"}">
    ${s.foto ? `<div class="foto sobe"><img src="${esc(midia(s.foto))}" alt="${nomeMarca}" loading="lazy"></div>` : ""}
    <div>
      <span class="etiqueta sobe">${esc(s.etiqueta || "Quem está por trás")}</span>
      <h2 class="sobe d1" style="margin-top:16px">${rico(s.titulo)}</h2>
      ${(s.textos || []).map((t) => `<p class="sobe d2">${rico(t)}</p>`).join("\n      ")}
      <div class="assin sobe d3">
        ${botao(s.botao || "Fale com a gente", { origem: "sobre" })}
        ${INSTA ? `<a class="botao vazado" href="${esc(INSTA)}" target="_blank" rel="noopener" data-evento="Contact" data-origem="sobre-instagram">Ver o Instagram</a>` : ""}
      </div>
    </div>
  </div>
</section>`;
}

// ---------------------------------------------------------------- páginas
const VERSAO = Date.now().toString(36);
const arquivos = {};
const ini = C.inicio || {};

const portas = paginas.map((p, i) => {
  const cor = hexOk(p.cor) ? p.cor : PRINCIPAL;
  return `<a class="porta" href="/${esc(p.slug)}" style="--cor:${cor}"><span class="n">${String(i + 1).padStart(2, "0")} · ${esc((p.menu || p.slug).toUpperCase())}</span><b>${esc(p.porta?.titulo || p.menu || p.slug)}</b><span class="sub">${esc(p.porta?.botao || "Ver mais")}</span></a>`;
}).join("\n      ");
const frentes = paginas.map((p) => {
  const cor = hexOk(p.cor) ? p.cor : PRINCIPAL;
  return `<article class="frente" style="--cor:${cor}">
        <span class="etiqueta">${esc(p.menu || p.slug)}</span>
        <h3>${rico(p.cartao?.titulo || p.porta?.titulo || p.menu)}</h3>
        <p>${rico(p.cartao?.texto || p.resumo || "")}</p>
        <div class="viz">${miniVisual(p)}</div>
        <a class="botao vazado" href="/${esc(p.slug)}">${esc(p.porta?.botao || "Ver mais")} <span class="seta">→</span></a>
      </article>`;
}).join("\n      ");
const rede = (ini.rede && ini.rede.length ? ini.rede : paginas.map((p) => ({ nome: p.menu || p.slug, cor: p.cor })))
  .map((n) => ({ nome: String(n.nome || ""), cor: hexOk(n.cor) ? n.cor : PRINCIPAL }));

arquivos["index.html"] = cabeca(semTags(ini.tituloAba || `${marca.nome || ""} · ${semTags(ini.titulo || "")}`), ini.descricao || semTags(ini.texto || ""), acentoVars(PRINCIPAL), "/") + topo("/") + `
<main>
<section class="hero">
  <canvas id="rede" aria-hidden="true"></canvas>
  <div class="rotulos" aria-hidden="true"></div>
  <div class="miolo">
    ${ini.etiqueta ? `<span class="etiqueta">${esc(ini.etiqueta)}</span>` : ""}
    <h1>${rico(ini.titulo || marca.nome || "")}</h1>
    ${ini.texto ? `<p class="lead">${rico(ini.texto)}</p>` : ""}
    ${portas ? `<div class="portas">\n      ${portas}\n    </div>` : `<div class="acoes" style="margin-top:28px">${botao(contato.botaoTopo || "Fale com a gente", { origem: "hero" })}</div>`}
  </div>
</section>
${ini.caminho ? secao({ tipo: "caminho", ...ini.caminho }, 1) : ""}
${frentes ? `
<section class="bloco" style="padding-top:0">
  <div class="miolo">
    ${cabecalhoSecao({ etiqueta: ini.frentes?.etiqueta || "O que fazemos", titulo: ini.frentes?.titulo || "Escolha por onde <grifo>começar.</grifo>", texto: ini.frentes?.texto })}
    <div class="frentes" style="--cols:${paginas.length === 3 ? 3 : 2}">
      ${frentes}
    </div>
  </div>
</section>` : ""}
${(ini.secoes || []).map((s) => secao(s, 1)).join("\n")}
${sobre(C.sobre)}
${faixa(C.chamadaFinal, "faixa-inicio")}
</main>` + rodape("inicio") + `
<script>window.REDE = ${JSON.stringify({ nos: rede, linha: mistura(PRINCIPAL, "#000000", 0.25), pontos: mistura(PRINCIPAL, "#FFFFFF", 0.62), fundo: FUNDO })};</script>
<script type="module" src="/assets/js/rede3d.js?v=${VERSAO}"></script>
</body>
</html>
`;

for (const p of paginas) {
  const cor = hexOk(p.cor) ? p.cor : PRINCIPAL;
  const h = p.hero || {};
  const b2 = h.botao2 ? (typeof h.botao2 === "string" ? { texto: h.botao2, link: "#" + ((p.secoes || [])[0]?.id || "") } : h.botao2) : null;
  arquivos[`${p.slug}.html`] = cabeca(semTags(p.tituloAba || `${p.menu || p.slug} · ${marca.nome || ""}`), p.descricao || semTags(h.texto || p.resumo || ""), acentoVars(cor), `/${p.slug}`) + topo(`/${p.slug}`) + `
<main>
<section class="hero-frente">
  <div class="aura"></div>
  <div class="miolo">
    <div>
      ${h.etiqueta ? `<span class="etiqueta sobe">${esc(h.etiqueta)}</span>` : ""}
      <h1 class="sobe d1">${rico(h.titulo || p.menu || p.slug)}</h1>
      ${h.texto ? `<p class="lead sobe d2">${rico(h.texto)}</p>` : ""}
      <div class="acoes sobe d3">
        ${botao(h.botao || "Fale com a gente", { href: h.link || CONVERSA, origem: `${p.slug}-topo` })}
        ${b2 ? `<a class="botao vazado" href="${esc(b2.link || "#")}">${esc(b2.texto)}</a>` : ""}
      </div>
    </div>
    ${visual(p.visual, cor)}
  </div>
</section>
${(p.secoes || []).map((s, i) => secao(s, i)).join("\n")}
${faixa(p.chamada || C.chamadaFinal, `faixa-${p.slug}`)}
</main>` + rodape(p.slug) + "\n</body>\n</html>\n";
}

// privacidade (LGPD): explica o Pixel e a API de Conversões
const contatoPriv = contato.email ? `pelo e-mail <a href="mailto:${esc(contato.email)}">${esc(contato.email)}</a>` : contato.whatsapp ? `pelo WhatsApp <a href="${esc(linkConversa("Quero saber sobre os meus dados"))}">${esc(contato.whatsapp)}</a>` : "pelos nossos canais de contato";
if (!contato.email) avisos.push("sem contato.email: a página de privacidade usa o WhatsApp como canal");
arquivos["privacidade.html"] = cabeca(`Política de privacidade · ${marca.nome || ""}`, `Como ${marca.nome || "este site"} trata os dados de quem visita.`, acentoVars(PRINCIPAL), "/privacidade") + topo("") + `
<main>
<section class="bloco" style="padding-top:140px">
  <div class="miolo" style="max-width:780px">
    <span class="etiqueta">Privacidade</span>
    <h2 style="margin-top:16px">Política de <span class="grifo">privacidade</span></h2>
    <div class="texto-livre">
      <p>Este site é de ${nomeMarca}. Aqui explicamos que dados são coletados quando você navega e para que eles servem.</p>
      <p><b>O que coletamos.</b> Páginas vistas, cliques nos botões, parâmetros do anúncio que trouxe você até aqui (como utm_source e fbclid), endereço IP e tipo de navegador. Não pedimos nome, e-mail ou telefone nesta navegação; se você nos chamar no WhatsApp ou no Instagram, a conversa segue as regras desses aplicativos.</p>
      ${PIXEL ? "<p><b>Para que usamos.</b> Para medir o resultado dos nossos anúncios e mostrar anúncios para quem já demonstrou interesse, usando o Pixel da Meta e a API de Conversões da Meta.</p>" : "<p><b>Para que usamos.</b> Para entender como o site é usado e melhorar a experiência.</p>"}
      <p><b>Seus direitos.</b> Você pode bloquear cookies no navegador e pedir informações ou a exclusão dos seus dados ${contatoPriv}.</p>
    </div>
  </div>
</section>
</main>` + rodape("privacidade") + "\n</body>\n</html>\n";

arquivos["vercel.json"] = JSON.stringify({
  cleanUrls: true,
  headers: [
    { source: "/assets/(css|js)/(.*)", headers: [{ key: "Cache-Control", value: "public, max-age=3600" }] },
    { source: "/assets/midia/(.*)", headers: [{ key: "Cache-Control", value: "public, max-age=86400" }] },
  ],
}, null, 2) + "\n";
arquivos["robots.txt"] = `User-agent: *\nAllow: /\n${dominio ? `Sitemap: https://${dominio}/sitemap.xml\n` : ""}`;
if (dominio) arquivos["sitemap.xml"] = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${["", ...paginas.map((p) => "/" + p.slug)].map((u) => `  <url><loc>https://${dominio}${u}</loc></url>`).join("\n")}\n</urlset>\n`;

// ---------------------------------------------------------------- gravar
fs.mkdirSync(SAIDA, { recursive: true });
fs.cpSync(path.join(MODELO, "base"), SAIDA, { recursive: true });
const pastaMidia = path.join(PASTA_CONFIG, "midia");
if (fs.existsSync(pastaMidia)) fs.cpSync(pastaMidia, path.join(SAIDA, "assets", "midia"), { recursive: true, filter: (f) => !/LEIA-ME/i.test(path.basename(f)) });
for (const [nome, html] of Object.entries(arquivos)) fs.writeFileSync(path.join(SAIDA, nome), html, "utf8");

// confere se toda mídia citada existe
const citadas = new Set();
JSON.stringify(C).replace(/"(midia\/[^"]+)"/g, (_, m) => citadas.add(m));
for (const m of citadas) if (!fs.existsSync(path.join(PASTA_CONFIG, m))) avisos.push(`arquivo não encontrado: ${m} (coloque na pasta midia/ ao lado do site.json)`);

console.log(`Site gerado em ${SAIDA}`);
console.log("Páginas: /" + (paginas.length ? ", " + paginas.map((p) => "/" + p.slug).join(", ") : "") + ", /privacidade");
console.log(PIXEL ? `Pixel ${PIXEL} + API de Conversões (/api/capi) ligados.` : "Sem Pixel.");
if (avisos.length) { console.log("\nAVISOS:"); avisos.forEach((a) => console.log(" - " + a)); }
