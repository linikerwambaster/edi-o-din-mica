// Testa o site como um cliente veria: no CELULAR (390 x 844) e no COMPUTADOR (1440 x 900).
// Para cada página: abre, rola até o fim (para as animações aparecerem), tira um print da página inteira,
// e confere rolagem para o lado, erros no console e arquivos que não carregaram.
// Uso: node scripts/testar.mjs [pasta-do-site]   (padrão: ./site)  -> prints e relatorio.txt em ./testes
import fs from "node:fs";
import path from "node:path";
import http from "node:http";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";

let puppeteer;
try { puppeteer = (await import("puppeteer-core")).default; }
catch (e) { console.error("Falta o puppeteer-core. Rode: npm install"); process.exit(1); }

const AQUI = path.dirname(fileURLToPath(import.meta.url));
const RAIZ = path.resolve(process.argv[2] || "site");
const SAIDA = path.resolve("testes");
const PORTA = 4399;

// procura um Chrome ou Edge já instalado no computador
const CANDIDATOS = process.env.CHROME ? [process.env.CHROME] : [
  "C:/Program Files/Google/Chrome/Application/chrome.exe",
  "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe",
  (process.env.LOCALAPPDATA || "") + "/Google/Chrome/Application/chrome.exe",
  "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe",
  "C:/Program Files/Microsoft/Edge/Application/msedge.exe",
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
  "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
  "/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser",
];
const chrome = CANDIDATOS.find((c) => c && fs.existsSync(c));
if (!chrome) { console.error("Não achei Chrome nem Edge. Instale o Google Chrome ou passe o caminho em CHROME=..."); process.exit(1); }

const paginas = ["/", ...fs.readdirSync(RAIZ).filter((f) => f.endsWith(".html") && f !== "index.html").map((f) => "/" + f.replace(/\.html$/, ""))];
fs.rmSync(SAIDA, { recursive: true, force: true }); fs.mkdirSync(SAIDA, { recursive: true });

const srv = spawn(process.execPath, [path.join(AQUI, "servir.mjs"), RAIZ, String(PORTA)], { stdio: "ignore" });
await new Promise((ok) => { const t = () => http.get(`http://127.0.0.1:${PORTA}/`, () => ok()).on("error", () => setTimeout(t, 150)); t(); });

const nav = await puppeteer.launch({ executablePath: chrome, headless: true, args: ["--hide-scrollbars", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"] });
const TELAS = { celular: { width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true }, computador: { width: 1440, height: 900, deviceScaleFactor: 1 } };
const linhas = [];
let problemas = 0;

for (const [nomeTela, vp] of Object.entries(TELAS)) {
  for (const pg of paginas) {
    const p = await nav.newPage();
    await p.setViewport(vp);
    const erros = [], faltando = [];
    p.on("console", (m) => { if (m.type() === "error") erros.push(m.text()); });
    p.on("pageerror", (e) => erros.push(String(e.message || e)));
    p.on("response", (r) => { if (r.status() >= 400 && r.url().includes("127.0.0.1")) faltando.push(`${r.status()} ${r.url().replace(`http://127.0.0.1:${PORTA}`, "")}`); });
    await p.goto(`http://127.0.0.1:${PORTA}${pg}`, { waitUntil: "networkidle2", timeout: 60000 });
    await p.addStyleTag({ content: "html{scroll-behavior:auto!important}" });
    // rola devagar até o fim para disparar as animações de entrada
    await p.evaluate(async () => {
      const passo = innerHeight * 0.7;
      for (let y = 0; y < document.body.scrollHeight; y += passo) { scrollTo(0, y); await new Promise((r) => setTimeout(r, 160)); }
      scrollTo(0, 0); await new Promise((r) => setTimeout(r, 400));
    });
    await new Promise((r) => setTimeout(r, 900));
    // para o print da página inteira: tudo já "entrado" e a altura do topo travada (senão o 100svh estica no print)
    await p.evaluate(() => {
      document.querySelectorAll(".sobe, .caminho, .fase, .frente, [data-anima]").forEach((el) => el.classList.add("dentro"));
      const h = innerHeight, st = document.createElement("style");
      st.textContent = `.hero{min-height:${h}px!important}.hero-frente{min-height:${Math.round(h * 0.92)}px!important}`;
      document.head.appendChild(st);
    });
    await new Promise((r) => setTimeout(r, 1600));
    const largura = await p.evaluate(() => ({ doc: document.documentElement.scrollWidth, tela: innerWidth, culpados: [...document.querySelectorAll("body *")].filter((el) => { const r = el.getBoundingClientRect(); return r.right > innerWidth + 1 && getComputedStyle(el).position !== "fixed"; }).slice(0, 5).map((el) => el.tagName.toLowerCase() + (el.className && typeof el.className === "string" ? "." + el.className.split(" ").join(".") : "")) }));
    const nome = `${nomeTela}${pg === "/" ? "-inicio" : pg.replace(/\//g, "-")}.png`;
    // print da página inteira: a "tela" vira a página toda. Acima de ~8000 px a placa de vídeo repete pedaços,
    // então página muito comprida sai em partes (nome-1.png, nome-2.png...)
    const altura = await p.evaluate(() => document.documentElement.scrollHeight);
    const dpr = vp.deviceScaleFactor || 1;
    if (altura <= 8000) {
      await p.setViewport({ ...vp, height: altura, deviceScaleFactor: altura * dpr > 8000 ? 1 : dpr });
      await new Promise((r) => setTimeout(r, 700));
      await p.screenshot({ path: path.join(SAIDA, nome) });
    } else {
      for (let y = 0, n = 1; y < altura; y += vp.height, n++) {
        await p.evaluate((yy) => scrollTo(0, yy), y);
        await new Promise((r) => setTimeout(r, 300));
        await p.screenshot({ path: path.join(SAIDA, nome.replace(".png", `-${n}.png`)) });
      }
    }
    const ok = largura.doc <= largura.tela + 1 && !erros.length && !faltando.length;
    if (!ok) problemas++;
    linhas.push(`${ok ? "OK " : "ERRO"} ${nomeTela.padEnd(10)} ${pg.padEnd(22)} ${nome}`);
    if (largura.doc > largura.tela + 1) linhas.push(`     rolagem para o lado: página com ${largura.doc}px numa tela de ${largura.tela}px. Saindo da tela: ${largura.culpados.join(", ")}`);
    erros.forEach((e) => linhas.push(`     erro no console: ${e.slice(0, 200)}`));
    faltando.forEach((f) => linhas.push(`     não carregou: ${f}`));
    await p.close();
  }
}
await nav.close();
srv.kill();
const rel = linhas.join("\n") + `\n\n${problemas ? problemas + " página(s) com problema." : "Tudo certo no celular e no computador."}\nPrints em ${SAIDA}\n`;
fs.writeFileSync(path.join(SAIDA, "relatorio.txt"), rel);
console.log(rel);
process.exit(problemas ? 2 : 0);
