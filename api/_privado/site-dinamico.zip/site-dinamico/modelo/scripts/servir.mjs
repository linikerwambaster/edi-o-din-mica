// Prévia local do site, igual à Vercel: /servico abre servico.html (cleanUrls).
// O Pixel fica DESLIGADO na prévia, para não mandar visitas de teste para a conta de anúncios.
// Uso: node scripts/servir.mjs [pasta-do-site] [porta]   (padrão: ./site 4321)
import http from "node:http";
import fs from "node:fs";
import path from "node:path";

const RAIZ = path.resolve(process.argv[2] || "site");
const PORTA = Number(process.argv[3] || 4321);
const TIPOS = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".json": "application/json",
  ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".svg": "image/svg+xml", ".gif": "image/gif",
  ".mp4": "video/mp4", ".webm": "video/webm", ".ico": "image/x-icon", ".txt": "text/plain; charset=utf-8", ".xml": "application/xml", ".woff2": "font/woff2" };

const servidor = http.createServer((req, res) => {
  let url = decodeURIComponent(req.url.split("?")[0].split("#")[0]);
  if (url.startsWith("/api/")) { res.writeHead(204); return res.end(); }
  let arq = path.join(RAIZ, url);
  if (!arq.startsWith(RAIZ)) { res.writeHead(403); return res.end(); }
  if (url === "/") arq = path.join(RAIZ, "index.html");
  else if (!path.extname(url) && fs.existsSync(arq + ".html")) arq += ".html";
  if (!fs.existsSync(arq) || fs.statSync(arq).isDirectory()) { res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" }); return res.end("404: " + url); }
  const ext = path.extname(arq).toLowerCase();
  let dados = fs.readFileSync(arq);
  if (ext === ".html") dados = Buffer.from(dados.toString("utf8").replace(/pixelId: "\d*"/, 'pixelId: ""').replace(/capi: "[^"]*"/, 'capi: ""'));
  // vídeos com Range (o navegador pede pedaços)
  const range = req.headers.range;
  if (range && ext.match(/\.(mp4|webm)$/)) {
    const [ini, fim] = range.replace("bytes=", "").split("-").map((n) => (n ? Number(n) : undefined));
    const a = ini || 0, b = fim ?? dados.length - 1;
    res.writeHead(206, { "Content-Type": TIPOS[ext], "Content-Range": `bytes ${a}-${b}/${dados.length}`, "Accept-Ranges": "bytes", "Content-Length": b - a + 1 });
    return res.end(dados.subarray(a, b + 1));
  }
  res.writeHead(200, { "Content-Type": TIPOS[ext] || "application/octet-stream", "Cache-Control": "no-store" });
  res.end(dados);
});
servidor.listen(PORTA, "127.0.0.1", () => console.log(`Prévia em http://127.0.0.1:${PORTA} (Pixel desligado). Ctrl+C para parar.`));
