# Manual do `site.json`

Todos os textos aceitam `<grifo>palavra</grifo>` (itálico com degradê na cor da página) e `<b>negrito</b>`. Caminhos de mídia são relativos à pasta do `site.json` e começam com `midia/` (ex.: `"midia/foto.jpg"`); o gerador copia tudo para `site/assets/midia/`.

## Topo do arquivo
| Campo | O que é |
|---|---|
| `marca.nome` | Nome que aparece no topo, no rodapé e nas abas. |
| `marca.logo` | Opcional. `midia/logo.png` (de preferência PNG sem fundo, horizontal). Sem logo, vira um quadradinho com a inicial. |
| `marca.dominio` | Opcional. `meunegocio.com.br` (gera canonical e sitemap). |
| `marca.imagemCompartilhar` | Opcional. Imagem que aparece quando o link é compartilhado (1200 x 630). Padrão: `sobre.foto`. |
| `cores.fundo` | Cor de fundo (padrão `#08090C`, quase preto). O visual foi feito para fundo escuro. |
| `cores.principal` | Cor da página inicial, do botão do topo e da rede 3D. |
| `contato.principal` | `whatsapp`, `instagram` ou `link`: para onde vão TODOS os botões de conversa. |
| `contato.whatsapp` | Número com país e DDD, só dígitos: `5511999999999`. |
| `contato.mensagemWhatsapp` | Mensagem que já chega escrita no WhatsApp. |
| `contato.instagram` | Usuário sem @. Vira link no rodapé e no "Sobre". |
| `contato.link` | Usado quando `principal` é `link` (agenda, checkout, formulário). Link de checkout (Hotmart, Kiwify, Cakto...) dispara o evento InitiateCheckout. |
| `contato.email` | Vai na página de privacidade. |
| `contato.endereco` | Opcional. Aparece no rodapé. |
| `contato.botaoTopo` | Texto do botão branco do topo (padrão "Fale com a gente"). |
| `rastreamento.pixelId` | ID do Pixel da Meta (só números). Vazio = sem Pixel e sem API de Conversões. |

## `inicio` (página inicial)
| Campo | O que é |
|---|---|
| `tituloAba`, `descricao` | Título da aba do navegador e descrição para o Google. |
| `etiqueta` | Linha pequena em caixa alta acima do título. |
| `titulo` | Título grande (use `<grifo>`). |
| `texto` | 1 ou 2 frases. Termine convidando a escolher um serviço. |
| `rede` | De 3 a 6 itens `{ "nome": "WhatsApp", "cor": "#3DDC97" }`: os pilares da rede 3D. Vazio = usa os serviços. |
| `caminho` | Opcional. Linha que acende com as etapas do cliente: `{ etiqueta, titulo, texto, etapas: [{ icone, titulo, texto }] }` (3 a 6 etapas). |
| `frentes` | Opcional. Cabeçalho da seção de cartões dos serviços: `{ etiqueta, titulo, texto }`. |
| `secoes` | Opcional. Mais seções na página inicial (mesmos tipos das páginas, abaixo). |

## `paginas` (uma por serviço)
| Campo | O que é |
|---|---|
| `slug` | Endereço da página, sem acento e sem espaço: `trafego-pago` vira `/trafego-pago`. |
| `menu` | Nome curto no menu (1 ou 2 palavras). |
| `cor` | Cor da página (botões, destaques, brilho). |
| `porta.titulo`, `porta.botao` | O botão grande no topo da página inicial (título curto + "Ver como funciona"). |
| `cartao.titulo`, `cartao.texto` | O cartão do serviço na página inicial. |
| `hero.etiqueta`, `hero.titulo`, `hero.texto` | Topo da página do serviço. |
| `hero.botao` | Texto do botão principal (vai para o contato). `hero.link` troca o destino (ex.: checkout). |
| `hero.botao2` | Opcional. `{ "texto": "Como funciona", "link": "#metodo" }` (o `#metodo` é o `id` de uma seção). |
| `visual` | O painel animado ao lado do título (abaixo). |
| `secoes` | A lista de seções da página, na ordem. |
| `chamada` | Faixa colorida no fim: `{ titulo, texto, botao, link }`. Sem ela, usa a `chamadaFinal`. |
| `tituloAba`, `descricao` | Opcionais (aba e Google). |

## Visuais do topo de cada serviço (`visual.tipo`)
| Tipo | Campos | Quando usar |
|---|---|---|
| `grafico` | `rotulo` (ex.: "Gerenciador · estrutura"), `selos` (lista curta, ex.: "Pixel ✓") | Gestão, resultado, finanças, crescimento. A linha se desenha sozinha. |
| `chat` | `rotulo`, `mensagens: [{ "de": "cliente" ou "empresa", "texto", "hora" }]` (3 a 6) | Atendimento, agendamento, WhatsApp, suporte. As mensagens aparecem uma por uma, com "digitando". |
| `barras` | `rotulo`, `selos` | Rotina, plano, calendário, evolução de um processo. |
| `imagem` | `arquivo` (`midia/...jpg`), `legenda`, `tags` (ex.: ["ANTES", "DEPOIS"]), `varredura` (false para tirar a linha) | Estética, antes e depois, produto, espaço físico. |
| `video` | `arquivo` (`midia/...mp4`, curto e leve, sem som), `capa`, `tags`, `varredura` | Bastidor, demonstração, antes e depois em movimento. |

## Tipos de seção (`secoes[].tipo`)
Todas aceitam `etiqueta`, `titulo`, `texto` (cabeçalho) e `id` (para links do tipo `#metodo`).
| Tipo | Campos próprios | Para quê |
|---|---|---|
| `itens` | `itens: [{ icone, titulo, texto }]` (3 ou 6 ficam melhores) | O que está incluso, benefícios, diferenciais. |
| `passos` | `passos: [{ quando, titulo, texto }]` | Método, fases, como funciona. `quando` = "Passo 1", "Semana 1"... |
| `fluxo` | `passos: [{ icone, titulo, texto }]` (3 a 6) | Um processo em caixinhas que acendem uma por uma (vira coluna no celular). |
| `caminho` | `etapas: [{ icone, titulo, texto }]` | Linha que acende com a jornada do cliente. |
| `pra-quem` | `sim: []`, `nao: []`, `tituloSim`, `tituloNao` | "É pra você se / Não é pra você se". |
| `nota` | `destaque`, `texto` | Um aviso honesto com borda tracejada (não tem cabeçalho). |
| `perguntas` | `itens: [{ p, r }]` | Dúvidas frequentes, abre e fecha. |
| `galeria` | `midias: [{ arquivo, legenda }]` | Fotos ou vídeos do trabalho (3 por linha). |
| `texto` | `paragrafos: []` | Texto corrido (história, explicação). |
| `html` | `html` | Escape para algo que o modelo não tem (mapa do Google, vídeo do YouTube, formulário). Use pouco e teste no celular. |

## Outros blocos
- `sobre`: `{ etiqueta, titulo, foto, textos: [], botao }`. Foto vertical (4:5) fica melhor. Sem foto, vira só texto.
- `chamadaFinal`: `{ titulo, texto, botao, link }`. Faixa colorida no fim da página inicial (e das páginas sem `chamada`).

## Ícones (`icone`)
anuncio, pagina, whatsapp, ia, pessoa, check, lupa, casa, tela, chat, camera, grafico, relogio, seta, sino, loja, estrela, coracao, calendario, local, escudo, presente, livro, ferramenta, raio, carrinho, telefone, folha, dente, tesoura, peso

## Eventos que o site já manda (Pixel + API de Conversões)
- `PageView` em toda página e `ViewContent` com o nome da página.
- `Contact` em todo botão de conversa (WhatsApp, direct).
- `InitiateCheckout` em botão que leva para link de checkout (Hotmart, Kiwify, Cakto, Eduzz, Monetizze...).
- Botão com outro evento: na seção `html`, use `data-evento="Lead"` (ou `Schedule`) e `data-origem="nome"` no link.
