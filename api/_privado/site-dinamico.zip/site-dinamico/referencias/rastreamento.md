# Pixel da Meta + API de Conversões

O site manda cada evento por dois caminhos com o MESMO `event_id`:
1. **Pixel** (navegador da pessoa), e
2. **API de Conversões** (servidor da Vercel, `api/capi.js`), que continua funcionando quando o navegador bloqueia o Pixel.
A Meta junta os dois e não conta em dobro. O site também guarda o `fbclid` do anúncio (cookie `_fbc`) e as UTMs.

## Onde pegar cada coisa
- **ID do Pixel:** business.facebook.com → Gerenciador de Eventos → Fontes de dados → o Pixel → o número embaixo do nome. Vai no `site.json` (`rastreamento.pixelId`) e na variável `META_PIXEL_ID` da Vercel.
- **Token da API de Conversões:** Gerenciador de Eventos → o Pixel → **Configurações** → "API de Conversões" → **Gerar token de acesso**. O usuário copia e cola direto na Vercel (`META_ACCESS_TOKEN`). Não peça para ele colar no chat.

## Conferir se está chegando
1. Gerenciador de Eventos → o Pixel → **Testar eventos**. Copie o código de teste (ex.: `TEST12345`).
2. Na Vercel, crie a variável `META_TEST_EVENT_CODE` com esse código e faça o Redeploy.
3. Abra o site e clique num botão de WhatsApp. Na aba de teste devem aparecer `PageView`, `ViewContent` e `Contact`, cada um com "Navegador" e "Servidor" (desduplicados).
4. Funcionou? **Apague** a variável `META_TEST_EVENT_CODE` e faça o Redeploy de novo (senão os eventos ficam só no modo teste).

## Sem token ainda?
O site funciona só com o Pixel. A função `api/capi.js` responde "Pixel ou token não configurados" e não quebra nada. Quando o token entrar na Vercel, a API passa a funcionar sozinha.

## Domínio verificado
Para anunciar com o site, verifique o domínio no Gerenciador de Negócios (Configurações → Segurança da marca → Domínios). A Meta dá um registro TXT para colocar no DNS (no mesmo lugar do passo 4 de `publicar.md`).

## Públicos que valem a pena criar (Gerenciador de Anúncios → Públicos)
- Visitou qualquer página nos últimos 30 dias.
- Visitou a página de um serviço específico (URL contém `/nome-do-servico`).
- Clicou para conversar (evento `Contact`) e não comprou.
