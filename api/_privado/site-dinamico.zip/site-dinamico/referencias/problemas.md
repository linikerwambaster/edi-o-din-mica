# Problemas comuns

**"Falta o puppeteer-core"** ao testar → rode `npm install` dentro da pasta do projeto.

**"Não achei Chrome nem Edge"** → instale o Google Chrome, ou informe o caminho: `CHROME="C:/caminho/chrome.exe" node scripts/testar.mjs site` (no PowerShell: `$env:CHROME="C:/caminho/chrome.exe"; node scripts/testar.mjs site`).

**A rede 3D não aparece** → o navegador está sem WebGL (máquina virtual, aceleração desligada). O site continua funcionando: o fundo fica liso. No celular comum e no computador comum ela aparece.

**Rolagem para o lado no celular** → o relatório diz qual elemento sai da tela. Quase sempre é palavra muito comprida num título (ex.: um @ ou link inteiro) ou uma seção `html` com largura fixa. Encurte o texto ou use `max-width:100%` no HTML próprio.

**Título quebrando feio** → encurte. Título bom tem até ~8 palavras. Mova o resto para o `texto`.

**Botão do WhatsApp abre sem mensagem** → confira `contato.whatsapp` só com dígitos e com o 55 do Brasil na frente.

**Vídeo pesado / site lento** → vídeo de visual ou galeria deve ser curto (até 10 s), sem som e leve (até ~4 MB). Para comprimir: `ffmpeg -i entrada.mp4 -vf "scale=720:-2" -an -c:v libx264 -crf 28 -preset slow -movflags +faststart midia/saida.mp4`.

**Foto aparece cortando a cabeça no "Sobre"** → use foto vertical (4:5) com a pessoa no centro e espaço acima da cabeça.

**Mudei o site.json e nada mudou** → gere de novo (`node scripts/gerar.mjs site.json site`). Na prévia, recarregue a página. Depois de publicado, faça o `git push`.

**A Vercel mostra 404 em /servico** → o `vercel.json` precisa estar na raiz do repositório (ele é gerado dentro de `site/`). Confira se o repositório foi criado a partir da pasta `site/` e não da pasta do projeto inteiro.

**Eventos não aparecem na API de Conversões** → veja `rastreamento.md`: variáveis com o nome exato, Redeploy depois de criar, token gerado no Pixel certo.
