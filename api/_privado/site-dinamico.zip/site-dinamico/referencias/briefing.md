# Briefing: o que perguntar antes de montar o site

Faça as perguntas em 1 ou 2 mensagens, numeradas, em linguagem simples. Se o usuário já tem site, Instagram, LP ou um PDF de apresentação, peça o link e leia primeiro: muitas respostas já estão lá.

## Perguntas
1. **Nome** do negócio (ou o seu nome, se o site é de profissional) e o **domínio**, se já tiver (ex.: meunegocio.com.br).
2. **O que você vende?** Liste os serviços ou produtos principais (o ideal é de 3 a 4; cada um vira uma página).
3. Para **cada serviço**: para quem é, como funciona (passo a passo, se tiver), o que está incluso e o que NÃO está.
4. **Como o cliente fala com você?** WhatsApp (número com DDD), direct do Instagram, link de agenda ou de pagamento. Qual mensagem pronta você quer que chegue no WhatsApp?
5. **Instagram** e **e-mail** de contato (o e-mail vai na página de privacidade).
6. **Cores**: tem logo ou cor da marca? Se não tiver, eu escolho.
7. **Fotos e vídeos**: foto sua ou do espaço, fotos do trabalho (antes e depois, produtos), logo. Mande os arquivos aqui (eu coloco na pasta `midia/`).
8. **Pixel da Meta**: você anuncia? Se sim, qual o ID do Pixel (Gerenciador de Eventos > Fontes de dados)? Ainda não tem? Dá para colocar depois.
9. **Perguntas que todo cliente faz** (vira a seção de dúvidas).
10. Tem algo que você **não quer** no site (preço, prazo, alguma promessa)?

## O que fazer com as respostas
- Faltou informação de um serviço? Escreva o mínimo honesto ou pergunte de novo. Nunca invente número, depoimento ou cliente.
- Sem foto: use os visuais animados (`grafico`, `chat`, `barras`) e deixe `sobre.foto` vazio (o bloco "Sobre" vira só texto).
- Sem Pixel: gere sem `pixelId`. O site funciona e o Pixel entra depois (é só preencher e gerar de novo).
- Sem domínio: publique primeiro no endereço grátis da Vercel (nome.vercel.app) e ligue o domínio depois.

## Tom dos textos (copie a voz do usuário)
- Leia como ele escreve no Instagram e mantenha o mesmo jeito (você ou tu, formal ou leve).
- Título curto com uma ideia só e o destaque em `<grifo>` (ex.: `Responder <grifo>na hora</grifo> muda tudo.`).
- Texto de apoio com 1 ou 2 frases. Bullets curtos.
- Nada de promessa de resultado, "o melhor do Brasil", "garantido", contagem regressiva falsa ou travessão longo.
