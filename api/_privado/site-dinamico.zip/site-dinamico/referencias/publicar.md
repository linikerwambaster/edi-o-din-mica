# Publicar: GitHub + Vercel + domínio

O que vai para o ar é só o conteúdo da pasta `site/`. A Vercel é grátis para site pessoal e de pequeno negócio, publica sozinha a cada `git push` e já roda a função da API de Conversões (`api/capi.js`).

## 1. GitHub (guardar o site)
Dentro da pasta `site/`:
```
git init
git add .
git commit -m "Site no ar"
```
- Se o usuário tem o GitHub CLI (`gh --version`) e está logado (`gh auth status`): `gh repo create NOME-DO-SITE --private --source=. --push`.
- Sem o `gh`: peça para ele criar um repositório **privado** e vazio em https://github.com/new (sem README) e te passar o endereço. Depois:
```
git branch -M main
git remote add origin https://github.com/USUARIO/NOME-DO-SITE.git
git push -u origin main
```
Se o Git pedir login, quem faz é o usuário (janela do navegador). Nunca peça a senha dele.

## 2. Vercel (colocar no ar)
Guie o usuário (ele clica, você explica):
1. https://vercel.com, **entrar com o GitHub**.
2. **Add New → Project**, escolher o repositório do site, **Import**.
3. Framework Preset: **Other**. Não precisa mudar mais nada. **Deploy**.
4. Em 1 minuto o site está em `nome-do-projeto.vercel.app`. Abra e confira as páginas.

Alternativa sem painel: `npx vercel` dentro de `site/` (ele faz login pelo navegador) e depois `npx vercel --prod`.

## 3. Pixel + API de Conversões (variáveis)
Na Vercel: **Settings → Environment Variables**, adicionar:
- `META_PIXEL_ID` = o mesmo ID do `site.json`
- `META_ACCESS_TOKEN` = o token da API de Conversões (veja `rastreamento.md`). **O usuário cola o token ele mesmo.** Não peça o token no chat e não coloque em arquivo nenhum.
- (opcional, só para testar) `META_TEST_EVENT_CODE` = código da aba "Testar eventos"

Depois de salvar: **Deployments → os três pontinhos do último → Redeploy** (a variável só vale depois de publicar de novo).

## 4. Domínio próprio
Na Vercel: **Settings → Domains → Add**, digitar `meunegocio.com.br` e também `www.meunegocio.com.br`.
A Vercel mostra os registros de DNS. No registro.br (ou onde o domínio foi comprado), em **DNS → Editar zona**:
- registro **A** do domínio sem www apontando para o IP que a Vercel mostrar (normalmente `76.76.21.21`);
- registro **CNAME** `www` apontando para o endereço que a Vercel mostrar (normalmente `cname.vercel-dns.com`).

Pode levar de alguns minutos a algumas horas. O cadeado (HTTPS) a Vercel coloca sozinha. Se o domínio já aponta para outro site (Netlify, Wix, Hostinger), avise o usuário que o site antigo sai do ar quando o DNS mudar.

## 5. Atualizar depois
Mudou o `site.json`? Gere de novo, teste, e dentro de `site/`:
```
git add . && git commit -m "Atualiza textos" && git push
```
A Vercel publica sozinha em 1 minuto.
