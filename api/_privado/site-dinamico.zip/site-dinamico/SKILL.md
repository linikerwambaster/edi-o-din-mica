---
name: site-dinamico
description: Cria um site profissional completo para um negócio ou profissional (página inicial com uma rede 3D animada no topo, uma página própria para cada serviço com cor e animação próprias, Pixel da Meta + API de Conversões, página de privacidade), testa no celular e no computador e publica pelo GitHub + Vercel. Use quando o usuário pedir para criar, refazer ou melhorar um site, uma landing page ou uma página de serviço, transformar uma LP em site, ou fazer "um site nesse padrão".
---

# Site Dinâmico

Você vai criar um site no padrão do site do Liniker Wambaster (linikerwambasterr.com.br):
- **Página inicial** com uma rede 3D no topo (os pilares do negócio ligados, com pontinhos correndo como clientes no caminho) e um botão grande para cada serviço.
- **Uma página por serviço**, cada uma com a sua cor e um visual animado (gráfico que se desenha, chat de WhatsApp que se escreve sozinho, barras subindo, vídeo com varredura ou foto).
- **Pixel da Meta + API de Conversões** em todas as páginas (o mesmo evento pelos dois caminhos, sem contar em dobro).
- **Privacidade**, sitemap, robots, cache e endereços limpos (/servico em vez de /servico.html).

A regra de ouro: **você escreve o `site.json`; o gerador monta o site.** Não escreva HTML na mão: as peças prontas já têm o visual, as animações, o rastreamento e o celular resolvidos.

Leia, quando precisar:
- `referencias/briefing.md`: as perguntas para fazer ao usuário antes de escrever qualquer coisa.
- `referencias/secoes.md`: TODOS os campos do `site.json`, os tipos de seção, os visuais e os ícones. Leia antes de escrever o `site.json`.
- `referencias/exemplo-site.json`: um site completo de exemplo (3 serviços) para usar de modelo.
- `referencias/rastreamento.md`: Pixel, API de Conversões e como conferir os eventos.
- `referencias/publicar.md`: GitHub, Vercel e domínio próprio.
- `referencias/problemas.md`: erros comuns e soluções.

## Regras que não se negociam
1. **Nada inventado.** Números, resultados, depoimentos, clientes atendidos, prêmios, anos de experiência e prazos só entram se o usuário disse. Se faltar, pergunte ou deixe de fora. Nada de "+500 clientes" de enfeite.
2. **Texto de gente, não de agência.** Frases curtas, jeito de conversa, uma ideia por título. Em cada título, destaque de 1 a 3 palavras com `<grifo>...</grifo>`. Sem promessa de resultado ("triplique suas vendas"), sem travessão longo, sem jargão.
3. **Fotos e vídeos do jeito que vieram.** Não aplique filtro, P&B nem cor por cima da pessoa. Imagem ou pessoa criada com IA leva aviso na legenda.
4. **Celular primeiro.** Todo site é testado no celular e no computador (`scripts/testar.mjs`) e você OLHA os prints antes de mostrar ao usuário. Rolagem para o lado = erro, corrija.
5. **Segredo não vai no código nem na conversa.** O token da API de Conversões é colado pelo próprio usuário nas variáveis da Vercel. O `site.json` guarda só o ID do Pixel (que é público).
6. **Aprovação antes de publicar.** Mostre a prévia, ajuste o que ele pedir e só publique com o "pode subir".

## Passo a passo

### 0. Projeto
Copie a pasta `modelo/` desta skill para a pasta de trabalho do usuário (por exemplo `meu-site/`) e rode `npm install` dentro dela (instala só o `puppeteer-core`, usado no teste). Precisa de Node.js 18+ (Windows: `winget install OpenJS.NodeJS.LTS`; Mac: `brew install node`) e de Google Chrome ou Microsoft Edge instalado (o teste usa o navegador do computador).

### 1. Briefing
Faça as perguntas de `referencias/briefing.md`, em uma ou duas mensagens, de forma simples. Se o usuário já tem site, Instagram ou uma LP, leia antes e aproveite o que existe (textos, serviços, cores). Peça as fotos e a logo, e coloque os arquivos na pasta `midia/` do projeto.

### 2. Escrever o `site.json`
Use `referencias/exemplo-site.json` como molde e `referencias/secoes.md` como manual. Dicas:
- **3 ou 4 serviços** ficam melhores (o menu cabe no computador e a página inicial fica equilibrada). Mais que 5, junte serviços.
- Uma **cor por serviço**, bem diferentes entre si e da cor principal. Boas combinações em fundo escuro: `#3DDC97` verde, `#FF6D5A` coral, `#C084FC` roxo, `#FFB547` âmbar, `#5B8CFF` azul, `#2DD4BF` turquesa.
- Escolha o **visual** de cada serviço pelo que ele faz: atendimento/agendamento → `chat`; resultado, gestão, finanças → `grafico`; rotina, plano, calendário → `barras`; estética, antes e depois, produto, espaço → `imagem` ou `video` (com o arquivo real do usuário).
- A **rede 3D** (`inicio.rede`) mostra de 3 a 6 pilares do negócio: ferramentas, canais ou etapas (ex.: "Instagram", "WhatsApp", "Agenda", "Você"). Se não definir, ela usa os serviços.
- Botões de conversa vão para o WhatsApp com mensagem pronta (ou para o direct, ou para um link de agenda/checkout, em `contato`).

### 3. Gerar
```
node scripts/gerar.mjs site.json site
```
Monta tudo na pasta `site/`. Leia os **AVISOS** que ele imprime (ícone que não existe, arquivo de mídia faltando, contato vazio) e corrija no `site.json`. Para qualquer ajuste depois, mude o `site.json` e gere de novo; não edite os HTML gerados (eles são sobrescritos).

### 4. Testar no celular e no computador
```
node scripts/testar.mjs site
```
Abre cada página num celular (390 x 844) e num computador (1440 x 900), rola até o fim, tira o print da página inteira e confere rolagem para o lado, erros no console e arquivos que não carregaram. Leia `testes/relatorio.txt` e **abra os prints** (`testes/celular-*.png` e `testes/computador-*.png`). Procure: título quebrando feio, texto longo demais num botão, cartão vazio, foto cortando a cabeça. Corrija e teste de novo até sair "Tudo certo".

### 5. Mostrar ao usuário
```
node scripts/servir.mjs site 4321
```
Deixe rodando (em segundo plano) e mande o usuário abrir http://127.0.0.1:4321 no navegador (no celular dele também funciona se estiver na mesma rede, trocando 127.0.0.1 pelo IP do computador). O Pixel fica DESLIGADO na prévia. Mande também 2 ou 3 prints. Peça a aprovação.

### 6. Publicar
Siga `referencias/publicar.md`: repositório no GitHub com o conteúdo da pasta `site/`, projeto na Vercel ligado ao repositório, variáveis do Pixel/API de Conversões e domínio próprio. Depois de no ar, rode o teste também no endereço publicado (abra as páginas e confira) e siga `referencias/rastreamento.md` para ver os eventos chegando no Gerenciador de Eventos.

### 7. Entregar
Diga ao usuário, em linguagem simples: o endereço do site, onde mudar cada texto (`site.json`), como atualizar (gerar + `git push`, a Vercel publica sozinha) e o que ainda depende dele (token da API de Conversões, domínio, fotos que faltaram).
