# Skill: Troca de Avatar com IA

Você grava um vídeo seu e o Claude devolve o mesmo vídeo com uma modelo (ou modelo masculino) de IA no seu lugar. Fica no mesmo cenário, com os mesmos movimentos, no mesmo tempo e com o som original. Se você quiser, ele também monta a tela dividida, com você em cima e a IA embaixo, sincronizados.

Tudo é feito conversando com o Claude Code. Quem gera o vídeo da IA é o Google Flow, e o Claude cuida do resto: corta o vídeo, opera o Flow no navegador, baixa, junta, acerta a sincronia e monta a tela dividida.

## O que tem aqui

```
troca-de-avatar-ia/
├── SKILL.md                 o passo a passo que o Claude segue
├── scripts/
│   ├── preparar.py          corta o vídeo em trechos de até 9 s e tira o som
│   ├── montar.py            junta os vídeos do Flow com o som original
│   ├── sincronizar.py       deixa a IA no tempo exato do seu vídeo
│   └── tela_dividida.py     você em cima, IA embaixo (deitado ou 9:16)
└── references/
    ├── google_flow.md       como usar o Flow (pelo Claude ou na mão)
    ├── prompts.md           o comando que funciona + prompt para criar a personagem
    └── requisitos.md        o que instalar e quais contas precisa
```

## Do que você precisa

- **Claude Code**, no app do Claude (aba Code) ou no terminal.
- **Conta Google com acesso ao Google Flow** (flow.google.com). Cada trecho de ~9 s gasta créditos do Flow: no nosso teste foram 20 créditos por trecho.
- **ffmpeg e Python 3** instalados. Os comandos estão em `references/requisitos.md`.
- **Opcional: a extensão Claude in Chrome.** Com ela, o Claude mexe no Flow sozinho. Sem ela, você arrasta os arquivos para o Flow e ele faz o resto.
- **Uma imagem da sua personagem de IA.** Se você não tiver, o prompt para criar uma está em `references/prompts.md`.

## Como instalar

1. Copie a pasta **`troca-de-avatar-ia`** para:
   - **Windows:** `C:\Users\<seu usuário>\.claude\skills\`
   - **Mac:** `~/.claude/skills/`

   Se a pasta `skills` não existir, é só criar.
2. Abra uma conversa nova no Claude Code.
3. Mande algo como:

> Quero fazer a trend de troca de avatar. Meu vídeo está em Downloads/meu_video.mp4 e a imagem da personagem em Downloads/modelo.jpg. Quero o vídeo dela e a tela dividida comigo em cima.

O Claude vai te mostrar quantos trechos são e quantos créditos isso deve gastar, e só gera depois do seu OK.

## Regras importantes

- Use **o seu próprio vídeo**.
- Use uma **personagem criada por IA**, nunca o rosto de uma pessoa real ou famosa. O Google bloqueia e isso é uso indevido de imagem.
- Se for usar em **anúncio**, marque como conteúdo feito com IA.
