# Google Flow: passo a passo (Claude in Chrome ou manual)

Testado em outubro de 2026 em flow.google.com, com o agente do Flow e o modelo Omni 1.1 Flash. A interface do Flow muda com frequência. Por isso, antes de clicar, localize os elementos com `find`/`read_page` ou com um screenshot, em vez de confiar em posições fixas.

## 0. Carregar as ferramentas do Chrome

Se as ferramentas `mcp__claude-in-chrome__*` estiverem adiadas, carregue todas de uma vez:

```
ToolSearch: select:mcp__claude-in-chrome__tabs_context_mcp,mcp__claude-in-chrome__tabs_create_mcp,mcp__claude-in-chrome__navigate,mcp__claude-in-chrome__computer,mcp__claude-in-chrome__find,mcp__claude-in-chrome__read_page,mcp__claude-in-chrome__javascript_tool,mcp__claude-in-chrome__file_upload,mcp__claude-in-chrome__browser_batch
```

Se não existirem, siga o **caminho manual** no fim deste arquivo.

## 1. Abrir o Flow

- Abra uma aba nova em `https://flow.google.com`. A conta Google da pessoa já tem que estar logada no Chrome. Se aparecer tela de login, peça para ela entrar. Você nunca digita senha.
- Crie um projeto novo, ou use um que ela indicar.
- **Ajustes** (ícone de ajustes perto do campo do chat):
  - "Confirmar antes de gerar" = **Sempre**. Assim o Flow pergunta antes de gastar crédito e você repassa a pergunta para a pessoa.
  - Modelo de vídeo: **Omni** (no teste: Omni 1.1 Flash).
  - Proporção igual à do vídeo: 16:9 se for deitado, 9:16 se for em pé. O teste foi feito em 16:9.
  - Quantidade: **x1**.

## 2. Subir os arquivos

Suba a imagem do personagem e os trechos `parteNN_sem_som.mp4`, um arquivo por envio (limite de 10 MB).

O botão de envio do Flow abre o seletor de arquivos do sistema, que o Claude não consegue operar. A solução é criar um campo de arquivo na página, carregar o arquivo nele e "soltá-lo" no Flow como se fosse arrastado.

**a) Criar o campo** (`javascript_tool`):

```js
document.getElementById('upload-skill')?.remove();
const i = document.createElement('input');
i.type = 'file'; i.id = 'upload-skill'; i.accept = 'video/*,image/*';
i.style.cssText = 'position:fixed;left:10px;bottom:10px;z-index:99999;width:200px;height:30px;';
document.body.appendChild(i); 'ok'
```

**b) Carregar o arquivo**:
- Localize o campo com `find` ("file input"), que devolve um `ref`.
- Use `file_upload` com esse `ref` e o caminho completo do arquivo.

**c) Soltar no Flow** (`javascript_tool`):

```js
const inp = document.getElementById('upload-skill');
const dt = new DataTransfer(); Array.from(inp.files).forEach(f => dt.items.add(f));
const alvo = document.querySelector('main') || document.body;
const r = alvo.getBoundingClientRect();
const el = document.elementFromPoint(r.left + 300, r.top + 300) || alvo;
const opts = { bubbles: true, cancelable: true, dataTransfer: dt, clientX: r.left + 300, clientY: r.top + 300 };
['dragenter','dragover','drop'].forEach(t => el.dispatchEvent(new DragEvent(t, opts)));
inp.remove(); dt.files.length
```

**d) Caixa "Direitos de uso deste vídeo":** aparece a cada vídeo enviado. Confirme com a pessoa que o vídeo é dela e que ela concorda, e só então clique em **Concordo**.

Repita a–d para cada arquivo. Espere o arquivo aparecer na grade com o nome dele (passe o mouse para ver o nome). O processamento leva de 10 a 30 s.

## 3. Montar o comando de cada trecho

Para cada trecho, na ordem:

1. Clique com o botão direito no trecho (`parteNN_sem_som`) e escolha **Incluir no comando**.
2. Clique com o botão direito na imagem do personagem e escolha **Incluir no comando**.
3. Confira se as duas miniaturas aparecem acima do campo do chat ("O que você quer criar?").
4. Clique no campo e digite o comando de `references/prompts.md`, com o nome exato do arquivo do trecho.
5. Envie (seta).
6. O agente pergunta algo como "Quer que eu inicie essa 1 geração de vídeo, que custa 20 créditos?". Clique em **Aprovar** somente se a pessoa já autorizou esse gasto. "Sempre aprovar" tira o controle dela, então não use.
7. Um novo bloco aparece na grade com a porcentagem. Cada geração leva de 2 a 6 minutos. Você pode já montar o comando do próximo trecho enquanto isso: o agente coloca na fila.

## 4. Baixar

Quando o bloco mostrar o vídeo pronto:

1. Clique com o botão direito no bloco e escolha **Fazer o download** e depois **720p (Tamanho original)**. 1080p e 4K pedem upgrade de plano.
2. O arquivo vai para a pasta Downloads com o nome `<nome_do_envio>_<data>.mp4` (ex.: `parte02_sem_som_20261021111719.mp4`).
3. Mova cada um para `troca_avatar/resultado01.mp4`, `resultado02.mp4`… seguindo o número do trecho, não a ordem em que ficaram prontos.

Na grade, o mais novo fica no canto superior esquerdo. Para ter certeza de qual é qual, use o nome do arquivo baixado.

## Caminho manual (sem Claude in Chrome)

Peça para a pessoa:

1. Abrir flow.google.com, criar um projeto e ajustar como no item 1.
2. Arrastar a imagem do personagem e os arquivos `parteNN_sem_som.mp4` da pasta `troca_avatar` para a tela do Flow, e aceitar a caixa de direitos de uso.
3. Para cada trecho: botão direito no trecho e em **Incluir no comando**, depois o mesmo na imagem, colar o comando que você escreveu (entregue um por trecho, já com o nome do arquivo) e aprovar.
4. Baixar cada resultado em 720p e salvar (ou deixar na pasta Downloads, que você encontra e renomeia).

Depois disso, siga a partir do passo 4 do SKILL.md (`montar.py`).
