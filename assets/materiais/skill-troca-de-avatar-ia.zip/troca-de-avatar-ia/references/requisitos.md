# O que precisa (acessos e instalação)

## Contas

| O quê | Para quê | Observação |
|---|---|---|
| **Claude Code** (app do Claude na aba Code, ou terminal) | Rodar a skill | Qualquer plano que tenha o Claude Code |
| **Conta Google com acesso ao Google Flow** (flow.google.com) | Gerar o vídeo com o personagem | Cada geração gasta créditos. No teste (out/2026, plano Google AI Pro), cada trecho de ~9 s custou 20 créditos. Confira o seu saldo no Flow |
| **Gerador de imagem** (ChatGPT, Gemini…) | Criar o personagem de IA | Só se a pessoa ainda não tiver a imagem |

A skill é gratuita. O que pode ter custo é o plano do Google que dá créditos no Flow.

## Programas

### ffmpeg e ffprobe (edição de vídeo)

**Windows** (PowerShell):

```
winget install Gyan.FFmpeg
```

**Mac** (Homebrew):

```
brew install ffmpeg
```

Feche e abra o terminal e teste com `ffmpeg -version`.

### Python 3.8 ou mais novo

**Windows:**

```
winget install Python.Python.3.12
```

**Mac:**

```
brew install python
```

Teste com `python --version` (no Mac pode ser `python3`). Não precisa instalar nenhuma biblioteca.

### Claude in Chrome (opcional, recomendado)

Extensão do Claude para o Google Chrome. Com ela, o Claude abre o Flow, sobe os arquivos, escreve os comandos e baixa os vídeos sozinho. Instale pela Chrome Web Store ("Claude", da Anthropic), entre com a mesma conta do Claude (veja se o seu plano tem acesso à extensão) e deixe o Chrome aberto e logado na conta Google que tem o Flow.

Sem a extensão funciona do mesmo jeito: a pessoa faz a parte do Flow com a mão (arrastar arquivos, colar o comando, baixar) e o Claude faz todo o resto.

## Como instalar a skill

1. Copie a pasta `troca-de-avatar-ia` (a que tem o `SKILL.md` dentro) para:
   - **Windows:** `C:\Users\<seu usuário>\.claude\skills\`
   - **Mac:** `~/.claude/skills/`

   Se a pasta `skills` não existir, crie.
2. Abra uma conversa nova no Claude Code.
3. Mande algo como: "Quero fazer a trend de troca de avatar com o vídeo X e a imagem Y."
