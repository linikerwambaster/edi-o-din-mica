# Comandos (prompts)

## Comando do Flow (um por trecho)

Troque o que está entre chaves. Mantenha o mesmo texto em todos os trechos e mude só o nome do arquivo, para o personagem sair igual em todos.

```
Edite o vídeo {NOME_DO_TRECHO}: substitua {o homem / a mulher / a pessoa} pela {mulher / homem / pessoa} da imagem {NOME_DA_IMAGEM}, mantendo o mesmo cenário do vídeo ({OBJETOS DO CENÁRIO}, a mesma luz e o mesmo enquadramento). {Ela/Ele} faz exatamente os mesmos movimentos {do homem / da mulher}, no mesmo tempo: as mesmas viradas e inclinações de cabeça, os mesmos olhares para a câmera, as mesmas expressões, os mesmos sorrisos e os mesmos gestos com as mãos. Aparência {dela/dele} igual à da imagem: {CABELO, OLHOS, ROUPA, ACESSÓRIOS}. Visual fotorrealista, como gravado no celular. Sem fala, sem som.
```

- `{NOME_DO_TRECHO}` é o nome do arquivo sem `.mp4`, como aparece no Flow (ex.: `parte02_sem_som`).
- `{NOME_DA_IMAGEM}` é o nome da imagem no Flow, sem extensão (ex.: `modelo_ia`).
- `{OBJETOS DO CENÁRIO}` sai do `quadro_referencia.jpg`. Cite de 3 a 5 coisas visíveis: móveis, quadros, cor da parede, porta, planta.
- `{CABELO, OLHOS, ROUPA, ACESSÓRIOS}` sai da imagem do personagem.
- Se o trecho tiver um gesto marcante (aceno, mão no rosto, piscada), pode citar no fim: "inclusive o aceno com a mão e a mão no rosto".

### Exemplo real (o teste que deu certo)

```
Edite o vídeo referencia_sem_som_parte2: substitua o homem pela mulher da imagem modelo_ia, mantendo o mesmo cenário do vídeo (a mesma sala, o sofá bege, o quadro na parede, a cadeira, a mesma luz e o mesmo enquadramento). A mulher faz exatamente os mesmos movimentos do homem, no mesmo tempo: as mesmas viradas e inclinações de cabeça, os mesmos olhares para a câmera, as mesmas expressões e os mesmos gestos com as mãos no rosto. Aparência dela igual à da imagem: cabelo loiro longo e ondulado, olhos verdes, vestido verde-oliva, colar delicado. Visual fotorrealista, como gravado no celular. Sem fala, sem som.
```

### O que não fazer

- **Não pedir para "manter a pessoa e só mudar o rosto"** de alguém real ou famoso. O Google bloqueia, e não é para contornar.
- **Não esquecer o cenário.** Sem ele, o Flow inventa um lugar. No primeiro teste, a personagem foi parar num jardim.
- **Não mandar o vídeo com som.** O Flow recusa com "Não é possível editar a fala".

## Criar o personagem (se a pessoa ainda não tiver)

Para gerar no ChatGPT, no Gemini ou em outro gerador de imagem. A pessoa ajusta idade, estilo e roupa:

```
Foto ultrarrealista no estilo selfie de celular de uma mulher brasileira de uns 30 anos, cabelo {cor e corte}, olhando para a câmera com expressão natural, enquadrada do peito para cima, luz natural suave de dentro de casa, fundo neutro e desfocado, roupa {descrição}, pele com textura real, sem maquiagem pesada, sem texto, sem marca d'água. Pessoa fictícia, não parecida com nenhuma pessoa real.
```

O personagem funciona melhor quando:

- tem o mesmo enquadramento do vídeo (do peito para cima) e o rosto de frente, bem iluminado;
- tem roupa simples, sem estampa complicada;
- é uma pessoa fictícia. Nada de foto de alguém real.
