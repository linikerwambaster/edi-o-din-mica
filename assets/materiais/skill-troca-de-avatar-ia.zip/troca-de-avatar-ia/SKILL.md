---
name: troca-de-avatar-ia
description: Troca a pessoa de um vídeo por um personagem de IA (modelo, UGC, avatar) que faz exatamente os mesmos movimentos, no mesmo cenário e no mesmo tempo, usando o Google Flow (Omni) pelo navegador com o Claude in Chrome e o ffmpeg, e ainda monta a tela dividida original x IA sincronizada. Use esta skill sempre que a pessoa falar em trend de troca de avatar, "virar outra pessoa com IA", trocar o rosto ou o corpo do vídeo por uma modelo de IA, criar UGC com IA a partir do próprio vídeo, motion transfer, "fazer igual o Higgsfield ou o Kling, só que pelo Google", ou vídeo comparando o real com a IA (lado a lado, em cima e embaixo), mesmo que ela não diga "skill" nem "Flow".
---

# Troca de avatar com IA (Google Flow + Claude)

A pessoa grava um vídeo dela (caras, gestos, olhares) e recebe o MESMO vídeo com um personagem de IA no lugar dela: mesmo cenário, mesmos movimentos, mesmo tempo, som original. Opcionalmente, a tela dividida com o original em cima e a IA embaixo, sincronizados.

Quem gera a imagem em movimento é o Google Flow (modelo Omni, modo "editar vídeo"). O Claude faz todo o resto: prepara os arquivos, opera o Flow no navegador, baixa, monta, sincroniza e entrega.

## Combinados antes de começar

Isso protege a pessoa e é o motivo de algumas pausas no fluxo:

- **O vídeo tem que ser dela** (ou ter autorização de quem aparece).
- **O personagem tem que ser criado por IA** ou ser de uso liberado. Nunca use o rosto de uma pessoa real ou famosa. O Google bloqueia por política, e seria uso indevido da imagem de alguém. Se o Flow bloquear, explique o motivo e não tente reescrever o pedido para driblar.
- **Créditos:** cada trecho gerado gasta créditos do Google Flow. No teste original foram 20 créditos por trecho de ~9 s, e o valor pode mudar. Mostre o total estimado (número de trechos x créditos) e só aprove gerações depois de um "pode gerar" claro da pessoa. Para regerar um trecho, peça de novo.
- **Termos:** quando aparecer a caixa "Direitos de uso deste vídeo", confirme com a pessoa que o vídeo é dela e que ela concorda, e só então clique em "Concordo".
- **Anúncio:** se o vídeo for virar anúncio, lembre a pessoa de marcar como conteúdo feito com IA (a Meta exige).

## O que precisa estar instalado

Detalhes e comandos de instalação estão em `references/requisitos.md`. Verificação rápida:

```bash
ffmpeg -version
python --version
```

E, para o Claude operar o Flow sozinho, as ferramentas do **Claude in Chrome** (`mcp__claude-in-chrome__*`). Sem elas, a pessoa arrasta os arquivos para o Flow com a mão e o Claude faz todo o resto. Funciona igual, e o caminho manual está em `references/google_flow.md`.

Os scripts ficam em `scripts/` dentro desta skill. Use o caminho completo deles, pois a pasta da skill aparece quando ela é carregada. Todos usam só Python 3 e ffmpeg, sem bibliotecas extras.

## Fluxo

Trabalhe numa pasta `troca_avatar/` dentro da pasta atual. Todos os scripts usam `--pasta troca_avatar` por padrão.

### 1. Entender o pedido

Pegue três coisas:

1. **O vídeo da pessoa.** Funciona melhor com câmera parada, a pessoa visível do peito para cima, sem cortes e com movimentos claros.
2. **A imagem do personagem de IA.** Se ela não tiver, ofereça o prompt de criação de personagem que está em `references/prompts.md` para ela gerar no ChatGPT ou no Gemini.
3. **O que ela quer no fim:**
   - só o vídeo da IA;
   - tela dividida deitada (os dois vídeos inteiros, um em cima do outro, no formato do original);
   - tela dividida vertical 9:16 para Reels.

   Se ela não disser, entregue o vídeo da IA e a tela dividida deitada.

### 2. Preparar os trechos

```bash
python "<pasta da skill>/scripts/preparar.py" "<video>" --pasta troca_avatar
```

O que o script faz e por quê:

- **Divide o vídeo em trechos iguais de até 9 s**, porque o Flow edita no máximo ~10 s por vez.
- **Tira o som dos trechos**, porque com som o Flow recusa com "Não é possível editar a fala neste vídeo".
- **Comprime cada trecho para menos de 9,5 MB**, que é o limite do upload pelo navegador.
- **Converte vídeo HDR de iPhone**, que senão fica com a cor lavada.
- **Salva o `quadro_referencia.jpg`.**

Depois:

- Abra o `quadro_referencia.jpg` e a imagem do personagem com a ferramenta de leitura de imagem. Escreva o comando do Flow com o modelo de `references/prompts.md`, descrevendo:
  - o cenário com os objetos que aparecem no quadro (sofá, quadro na parede, cadeira, cor da parede);
  - a aparência do personagem (cabelo, olhos, roupa, acessórios).

  Esse detalhamento é o que mantém o cenário original. No primeiro teste, sem ele, o Flow levou a personagem para um jardim.
- Diga à pessoa quantos trechos são e quantos créditos isso deve gastar, e espere o "pode gerar".

### 3. Gerar no Google Flow

Siga `references/google_flow.md`: abrir o Flow, configurar, subir os arquivos `parteNN_sem_som.mp4` e a imagem, montar cada comando, aprovar e baixar em 720p. Gere um trecho por vez, sempre com o mesmo personagem e o mesmo texto base, mudando só o nome do arquivo. Assim o personagem fica igual em todos os trechos.

Ao baixar, mova cada arquivo para `troca_avatar/resultado01.mp4`, `resultado02.mp4`, … na ordem dos trechos. O Flow salva na pasta Downloads do navegador como `<nome_do_envio>_<data>.mp4`.

### 4. Montar e conferir

```bash
python "<pasta da skill>/scripts/montar.py" --pasta troca_avatar
```

Junta os resultados nos pontos de corte, com uma passagem de 0,16 s entre eles (usa os quadros que o Flow devolve a mais), troca o som pelo áudio original e gera `conferencia.png`. Na folha, a linha de cima é o original e a de baixo é a IA, nos mesmos instantes.

Abra a `conferencia.png` e confira:

- se o cenário é o mesmo;
- se a pessoa foi trocada em todos os trechos;
- se os gestos aparecem nos mesmos momentos.

Se um trecho saiu errado (outro cenário, gesto inventado, rosto diferente), mostre à pessoa e ofereça regerar só aquele trecho. Isso gasta créditos de novo e precisa do OK dela.

### 5. Sincronizar

```bash
python "<pasta da skill>/scripts/sincronizar.py" --pasta troca_avatar
```

O Flow copia os movimentos, mas não no tempo exato. No teste, ela vinha ~0,08 s atrasada em quase tudo e ~0,5 s num aceno, e na tela dividida isso aparece. O script compara o movimento dos dois vídeos quadro a quadro, reajusta só o tempo da IA (o original não é tocado) e mede de novo. Passe para a pessoa o "antes" e o "depois" que ele imprime. No teste, o atraso médio caiu de 0,17 s para 0,03 s.

### 6. Tela dividida (se ela quiser)

```bash
python "<pasta da skill>/scripts/tela_dividida.py" --pasta troca_avatar --formato deitado
python "<pasta da skill>/scripts/tela_dividida.py" --pasta troca_avatar --formato vertical
```

- `deitado` empilha os dois vídeos inteiros, sem cortar nada.
- `vertical` gera 1080x1920, com cada metade cortada no centro. Quem chega muito perto da câmera pode perder o topo da cabeça nesse formato. Avise a pessoa.
- `--ia-em-cima` inverte a ordem.

O som é sempre o do original.

### 7. Entregar

Entregue `ia_sincronizado.mp4` (o vídeo da IA) e a tela dividida, se pedida. Diga onde estão, quantos créditos foram usados e, se for anúncio, lembre da marcação de IA.

## Problemas comuns

| O que aconteceu | Por quê | O que fazer |
|---|---|---|
| "Não é possível editar a fala neste vídeo" | O vídeo enviado tem som | Envie os arquivos `_sem_som` |
| Bloqueio por política / "Input blocked" | O personagem parece pessoa real ou famosa | Use um personagem criado por IA. Não tente contornar |
| Ela aparece em outro lugar | O comando não descreveu o cenário | Descreva os objetos do `quadro_referencia.jpg` e regere |
| Gesto diferente num trecho | Variação do modelo | Regere só aquele trecho (com OK da pessoa) |
| Voz ou fala inventada no resultado | O Flow às vezes cria áudio | Nada: o `montar.py` descarta e usa o som original |
| O botão de upload abre uma janela que o Claude não alcança | O Flow usa o seletor de arquivos do sistema | Use a injeção de upload de `references/google_flow.md` ou peça para a pessoa arrastar |
| Cor lavada | Vídeo HDR do iPhone | O `preparar.py` já converte. Use o `original_sdr.mp4` que ele gera |
| Leve desencontro na tela dividida | O tempo do Flow não é exato | Rode o `sincronizar.py` |
