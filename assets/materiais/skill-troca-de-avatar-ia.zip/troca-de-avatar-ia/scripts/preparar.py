#!/usr/bin/env python3
"""Passo 1: divide o vídeo em trechos curtos e gera cópias SEM SOM para subir no Google Flow.

Por quê:
- o Flow (Omni) edita no máximo ~10 s por geração, então o vídeo vai em trechos de até 9 s;
- com som, o Flow recusa a edição ("Não é possível editar a fala neste vídeo"); sem som, funciona;
- o upload pelo Claude in Chrome aceita até 10 MB por envio, então cada trecho fica abaixo de 9,5 MB.

Uso:
    python preparar.py meu_video.mp4 [--pasta troca_avatar] [--max 9]

Gera em <pasta>/:
    parte01_sem_som.mp4, parte02_sem_som.mp4, ...   (os arquivos para subir no Flow)
    quadro_referencia.jpg                           (um quadro do vídeo, para descrever o cenário)
    cortes.json                                     (pontos de corte; os outros scripts leem daqui)
"""
import argparse, json, math, os, subprocess, sys

LIMITE_MB = 9.5


def rodar(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit("Erro no ffmpeg/ffprobe:\n" + r.stderr[-1500:])
    return r.stdout


def duracao(arq):
    return float(rodar(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", arq]).strip())


def tem_audio(arq):
    return "audio" in rodar(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type", "-of", "csv=p=0", arq])


HDR_PARA_SDR = ("zscale=t=linear:npl=203,format=gbrpf32le,zscale=p=bt709,tonemap=tonemap=hable:desat=0,"
                "zscale=t=bt709:m=bt709:r=tv,format=yuv420p")


def eh_hdr(arq):
    t = rodar(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=color_transfer", "-of", "csv=p=0", arq])
    return any(x in t for x in ("arib-std-b67", "smpte2084"))


def copia_sdr(arq, pasta):
    """Vídeo de iPhone em HDR fica com a cor lavada fora do celular: gera uma cópia SDR (com o som) e usa ela daqui pra frente."""
    saida = os.path.join(pasta, "original_sdr.mp4")
    base = ["ffmpeg", "-v", "error", "-y", "-i", arq]
    fim = ["-c:v", "libx264", "-preset", "slow", "-crf", "16", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", saida]
    r = subprocess.run(base + ["-vf", HDR_PARA_SDR] + fim, capture_output=True, text=True)
    if r.returncode != 0:  # ffmpeg sem zscale: converte sem tone mapping (melhor que nada)
        print("Aviso: este ffmpeg não tem zscale; convertendo HDR sem tone mapping.")
        rodar(base + ["-vf", "format=yuv420p"] + fim)
    return saida


def dimensoes_imagem(arq):
    s = rodar(["ffprobe", "-v", "error", "-show_entries", "stream=width,height", "-of", "csv=p=0", arq]).strip().split(",")
    return int(s[0]), int(s[1])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--pasta", default="troca_avatar")
    ap.add_argument("--max", type=float, default=9.0, help="duração máxima de cada trecho (s)")
    a = ap.parse_args()

    os.makedirs(a.pasta, exist_ok=True)
    if eh_hdr(a.video):
        print("Vídeo em HDR detectado: gerando cópia SDR (cores corretas)...")
        a.video = copia_sdr(a.video, a.pasta)
    dur = duracao(a.video)
    n = max(1, math.ceil(dur / a.max - 1e-6))
    seg = dur / n
    cortes = [[round(i * seg, 3), round(min(dur, (i + 1) * seg), 3)] for i in range(n)]

    # quadro de referência (já com a rotação do celular aplicada) -> orientação real do vídeo
    ref = os.path.join(a.pasta, "quadro_referencia.jpg")
    rodar(["ffmpeg", "-v", "error", "-y", "-ss", str(min(1.0, dur / 2)), "-i", a.video, "-frames:v", "1", "-q:v", "2", ref])
    w, h = dimensoes_imagem(ref)
    deitado = w >= h
    # lado maior até 1280 px (o Flow devolve em 720p; mais que isso só aumenta o arquivo)
    if max(w, h) > 1280:
        escala = "scale=1280:-2" if deitado else "scale=-2:1280"
    else:
        escala = "scale=trunc(iw/2)*2:trunc(ih/2)*2"

    partes = []
    for i, (ini, fim) in enumerate(cortes, 1):
        nome = os.path.join(a.pasta, f"parte{i:02d}_sem_som.mp4")
        for crf in (18, 21, 24, 27, 30):
            rodar(["ffmpeg", "-v", "error", "-y", "-ss", str(ini), "-to", str(fim), "-i", a.video,
                   "-vf", escala, "-r", "30", "-c:v", "libx264", "-preset", "slow", "-crf", str(crf),
                   "-pix_fmt", "yuv420p", "-an", "-movflags", "+faststart", nome])
            mb = os.path.getsize(nome) / 1e6
            if mb <= LIMITE_MB:
                break
        partes.append(os.path.basename(nome))
        print(f"{os.path.basename(nome)}: {ini:.2f}s a {fim:.2f}s  ({mb:.1f} MB)")

    info = {
        "original": os.path.abspath(a.video),
        "duracao": round(dur, 3),
        "orientacao": "deitado" if deitado else "em pe",
        "largura": w, "altura": h,
        "tem_audio": tem_audio(a.video),
        "cortes": cortes,
        "partes": partes,
    }
    json.dump(info, open(os.path.join(a.pasta, "cortes.json"), "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    print(f"\n{n} trecho(s) de ~{seg:.1f} s | vídeo {'deitado' if deitado else 'em pé'} {w}x{h} | áudio original: {'sim' if info['tem_audio'] else 'não'}")
    print(f"Quadro de referência: {ref}")


if __name__ == "__main__":
    main()
