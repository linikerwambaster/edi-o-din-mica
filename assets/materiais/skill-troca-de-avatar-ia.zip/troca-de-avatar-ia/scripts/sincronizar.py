#!/usr/bin/env python3
"""Passo 4: deixa a IA no MESMO TEMPO do original (sem mexer no original).

Por quê:
- o Flow copia os movimentos, mas não no tempo exato: no nosso teste ela vinha ~0,08 s atrasada em
  quase tudo e até ~0,5 s num aceno. Na tela dividida isso aparece;
- este script compara a "energia de movimento" dos dois vídeos (grade 4x2, 24 quadros/s), acha o
  melhor casamento quadro a quadro (DTW), suaviza e reescreve só o tempo da IA;
- no fim mede de novo e mostra o antes e depois.

Só precisa de Python 3 e ffmpeg (sem bibliotecas extras).

Uso:
    python sincronizar.py --pasta troca_avatar
    python sincronizar.py --original meu_video.mp4 --ia ia_completo.mp4 --saida ia_sincronizado.mp4

Gera: <pasta>/ia_sincronizado.mp4 (24 fps, som original)
"""
import argparse, json, math, os, shutil, subprocess, sys, tempfile

W, H, FPS = 64, 36, 24
GX, GY = 4, 2
BANDA = 18        # no máximo 0,75 s de diferença entre os dois
PENAL = 0.15      # custo extra para "esticar" o tempo (evita deformar à toa)
SUAV = 6          # suavização do atraso (+-6 quadros = 0,5 s)
FPS_SAIDA = 24    # mesmo fps do Flow: sem quadros repetidos à toa


def rodar(cmd, binario=False):
    r = subprocess.run(cmd, capture_output=True, text=not binario)
    if r.returncode != 0:
        err = r.stderr if not binario else r.stderr.decode("utf-8", "replace")
        sys.exit("Erro no ffmpeg/ffprobe:\n" + err[-2000:])
    return r.stdout


def duracao(arq):
    return float(rodar(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", arq]).strip())


def quadros(arq, inicio=0.0, dur=None):
    cmd = ["ffmpeg", "-v", "error", "-ss", str(inicio), "-i", arq]
    if dur:
        cmd += ["-t", str(dur)]
    cmd += ["-vf", f"fps={FPS},scale={W}:{H},format=gray", "-f", "rawvideo", "-"]
    d = rodar(cmd, binario=True)
    return [d[i * W * H:(i + 1) * W * H] for i in range(len(d) // (W * H))]


def energias(fr):
    """Energia de movimento por célula da grade, quadro a quadro (diferença para o quadro anterior)."""
    cw, ch = W // GX, H // GY
    out = [[0.0] * (GX * GY)]
    for k in range(1, len(fr)):
        a, b = fr[k - 1], fr[k]
        cel = [0.0] * (GX * GY)
        for y in range(H):
            gy = min(y // ch, GY - 1) * GX
            base = y * W
            for x in range(W):
                cel[gy + min(x // cw, GX - 1)] += abs(a[base + x] - b[base + x])
        out.append(cel)
    return out


def para_dtw(energ):
    """Log + média móvel + z-score por célula: deixa os dois vídeos comparáveis (pessoas e luz diferentes)."""
    bruto = [[math.log1p(v) for v in cel] for cel in energ]
    n = len(bruto)
    sm = [[sum(bruto[max(0, min(n - 1, k + o))][c] for o in (-1, 0, 1)) / 3 for c in range(GX * GY)] for k in range(n)]
    for c in range(GX * GY):
        col = [f[c] for f in sm]
        m = sum(col) / n
        s = math.sqrt(sum((v - m) ** 2 for v in col) / n) or 1.0
        for f in sm:
            f[c] = (f[c] - m) / s
    return sm


def atraso_medio(fo, fu):
    """Atraso médio (s) em janelas de 1,5 s onde o casamento é confiável (r >= 0,55). Usa a energia bruta."""
    JAN, PASSO, LAG = 36, 6, 14
    n = min(len(fo), len(fu))
    lags = []
    for c in range(JAN // 2 + LAG, n - JAN // 2 - LAG, PASSO):
        a = [v for k in range(c - JAN // 2, c + JAN // 2) for v in fo[k]]
        ma = sum(a) / len(a)
        sa = math.sqrt(sum((x - ma) ** 2 for x in a)) or 1.0
        melhor = (0, -2.0)
        for d in range(-LAG, LAG + 1):
            b = [v for k in range(c - JAN // 2 + d, c + JAN // 2 + d) for v in fu[k]]
            mb = sum(b) / len(b)
            sb = math.sqrt(sum((x - mb) ** 2 for x in b)) or 1.0
            r = sum((x - ma) * (y - mb) for x, y in zip(a, b)) / (sa * sb)
            if r > melhor[1]:
                melhor = (d, r)
        if melhor[1] >= 0.55:
            lags.append(melhor[0])
    if not lags:
        return None, 0
    return sum(abs(x) for x in lags) / len(lags) / FPS, sum(1 for x in lags if abs(x) <= 1) / len(lags)


def dtw(fo, fu):
    n, m = len(fo), len(fu)
    INF = float("inf")
    D = [dict() for _ in range(n)]
    P = [dict() for _ in range(n)]
    for i in range(n):
        for j in range(max(0, i - BANDA), min(m, i + BANDA + 1)):
            c = math.sqrt(sum((x - y) ** 2 for x, y in zip(fo[i], fu[j])))
            if i == 0 and j == 0:
                D[i][j] = c
                continue
            best, arg = INF, None
            for (pi, pj, pen) in ((i - 1, j - 1, 0.0), (i - 1, j, PENAL), (i, j - 1, PENAL)):
                if pi >= 0 and pj >= 0 and pj in D[pi] and D[pi][pj] + c + pen < best:
                    best, arg = D[pi][pj] + c + pen, (pi, pj)
            if arg:
                D[i][j], P[i][j] = best, arg
    i = n - 1
    j = min(D[i], key=lambda jj: D[i][jj])
    pares = {}
    while True:
        pares.setdefault(i, []).append(j)
        if (i, j) == (0, 0) or j not in P[i]:
            break
        i, j = P[i][j]
    return [sum(pares[k]) / len(pares[k]) - k if k in pares else 0.0 for k in range(n)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pasta", default="troca_avatar")
    ap.add_argument("--original")
    ap.add_argument("--ia")
    ap.add_argument("--saida")
    a = ap.parse_args()

    info = {}
    cj = os.path.join(a.pasta, "cortes.json")
    if os.path.exists(cj):
        info = json.load(open(cj, encoding="utf-8"))
    original = a.original or info.get("original")
    ia = a.ia or os.path.join(a.pasta, "ia_completo.mp4")
    saida = a.saida or os.path.join(a.pasta, "ia_sincronizado.mp4")
    if not original:
        sys.exit("Informe --original (ou rode preparar.py antes, para existir cortes.json).")
    inicio = info.get("cortes", [[0, 0]])[0][0]
    total = min(duracao(ia), duracao(original) - inicio)

    print("Lendo os movimentos dos dois vídeos...")
    eo = energias(quadros(original, inicio, total))
    eu = energias(quadros(ia))
    antes = atraso_medio(eo, eu)
    fo, fu = para_dtw(eo), para_dtw(eu)

    print("Casando quadro a quadro...")
    lag = dtw(fo, fu)
    n = len(lag)
    sm = [sum(lag[max(0, min(n - 1, k + o))] for o in range(-SUAV, SUAV + 1)) / (2 * SUAV + 1) for k in range(n)]
    # nas pontas o casamento é forçado a começar/terminar junto: mantém o atraso de logo antes da ponta
    k_ini, k_fim = min(n - 1, int(0.5 * FPS)), max(0, n - 1 - int(1.7 * FPS))
    if k_fim > k_ini:
        sm = [sm[k_ini] if k < k_ini else sm[k_fim] if k > k_fim else sm[k] for k in range(n)]
    m = len(fu)
    mapa, ult = [], -1.0
    for k in range(n):
        t = min(max(k + sm[k], ult + 0.4, 0.0), m - 1)
        mapa.append(t / FPS)
        ult = t

    def w(t):
        x = t * FPS
        i0 = min(int(x), n - 1)
        i1 = min(i0 + 1, n - 1)
        f = x - int(x)
        return mapa[i0] * (1 - f) + mapa[i1] * f

    tmp = tempfile.mkdtemp(prefix="sync_ia_")
    try:
        rodar(["ffmpeg", "-v", "error", "-i", ia, "-vf", f"fps={FPS}", "-q:v", "1", os.path.join(tmp, "q%05d.jpg")])
        nq = len([f for f in os.listdir(tmp) if f.endswith(".jpg")])
        linhas = ["ffconcat version 1.0"]
        n_out = int(round(total * FPS_SAIDA))
        idx = 1
        for k in range(n_out):
            idx = min(nq, max(1, int(round(w(k / FPS_SAIDA) * FPS)) + 1))
            linhas += [f"file 'q{idx:05d}.jpg'", f"duration {1 / FPS_SAIDA:.6f}"]
        linhas.append(f"file 'q{idx:05d}.jpg'")
        lista = os.path.join(tmp, "lista.ffconcat")
        open(lista, "w").write("\n".join(linhas) + "\n")
        cmd = ["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", lista,
               "-ss", str(inicio), "-i", original, "-map", "0:v"]
        if info.get("tem_audio", True):
            cmd += ["-map", "1:a:0?", "-c:a", "aac", "-b:a", "192k"]
        cmd += ["-vf", f"fps={FPS_SAIDA},format=yuv420p", "-t", f"{total:.3f}", "-c:v", "libx264", "-crf", "17",
                "-preset", "slow", "-movflags", "+faststart", saida]
        rodar(cmd)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    print("Conferindo o resultado...")
    depois = atraso_medio(eo, energias(quadros(saida)))
    def txt(x):
        return "sem trechos confiáveis" if x[0] is None else f"atraso médio {x[0]:.3f}s | {x[1]:.0%} do vídeo com até 1 quadro de diferença"
    print(f"ANTES : {txt(antes)}")
    print(f"DEPOIS: {txt(depois)}")
    print(f"OK: {saida}")


if __name__ == "__main__":
    main()
