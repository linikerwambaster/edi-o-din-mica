#!/usr/bin/env python3
"""Passo 3: junta os vídeos devolvidos pelo Flow na ordem, com o ÁUDIO ORIGINAL, e gera uma folha de conferência.

Por quê:
- cada resultado do Flow começa no mesmo instante do trecho enviado, então cada um entra no ponto de corte dele;
- o Flow costuma devolver uns quadros a mais no fim; essa sobra é usada numa passagem de 0,16 s entre os
  trechos, para não dar "pulo" na troca;
- o som do Flow é descartado (pode vir mudo ou com fala inventada) e entra o som do vídeo original.

Uso:
    python montar.py --pasta troca_avatar resultado01.mp4 resultado02.mp4 ...
    (sem arquivos: usa <pasta>/resultado*.mp4 em ordem alfabética)

Gera em <pasta>/:
    ia_completo.mp4      vídeo da IA inteiro, com o som original
    conferencia.png      linha de cima = original, linha de baixo = IA, nos mesmos instantes
"""
import argparse, glob, json, os, subprocess, sys

PASSAGEM = 0.16


def rodar(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit("Erro no ffmpeg/ffprobe:\n" + r.stderr[-2000:])
    return r.stdout


def duracao(arq):
    return float(rodar(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", arq]).strip())


def dims(arq):
    s = rodar(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height", "-of", "csv=p=0", arq]).strip().split(",")
    return int(s[0]), int(s[1])


def folha(original, ia, total, deitado, saida):
    w, h = (320, 180) if deitado else (180, 320)
    n = 8
    taxa = n / total
    tmp = []
    for i, arq in enumerate((original, ia)):
        t = saida + f".linha{i}.png"
        rodar(["ffmpeg", "-v", "error", "-y", "-i", arq, "-vf", f"fps={taxa:.5f},scale={w}:{h},tile={n}x1",
               "-frames:v", "1", t])
        tmp.append(t)
    rodar(["ffmpeg", "-v", "error", "-y", "-i", tmp[0], "-i", tmp[1], "-filter_complex", "vstack", saida])
    for t in tmp:
        os.remove(t)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("resultados", nargs="*")
    ap.add_argument("--pasta", default="troca_avatar")
    a = ap.parse_args()

    info = json.load(open(os.path.join(a.pasta, "cortes.json"), encoding="utf-8"))
    cortes = info["cortes"]
    res = a.resultados or sorted(glob.glob(os.path.join(a.pasta, "resultado*.mp4")))
    if len(res) != len(cortes):
        sys.exit(f"Tenho {len(cortes)} trecho(s) em cortes.json mas recebi {len(res)} resultado(s): {res}")

    W, H = dims(res[0])
    inicio0 = cortes[0][0]
    total = cortes[-1][1] - inicio0
    filtros, ent = [], []
    for i, (arq, (ini, fim)) in enumerate(zip(res, cortes)):
        L = fim - ini
        d = duracao(arq)
        precisa = L + (PASSAGEM if i < len(res) - 1 else 0)
        if d + 0.05 < L:
            print(f"Aviso: {os.path.basename(arq)} tem {d:.2f}s e o trecho tem {L:.2f}s; o último quadro será repetido no fim.")
        ent += ["-i", arq]
        filtros.append(f"[{i}:v]setpts=PTS-STARTPTS,fps=24,scale={W}:{H},setsar=1,format=yuv420p,"
                       f"tpad=stop_mode=clone:stop_duration=1,trim=duration={precisa:.3f},setpts=PTS-STARTPTS[v{i}]")
    atual = "v0"
    for i in range(1, len(res)):
        off = cortes[i][0] - inicio0
        filtros.append(f"[{atual}][v{i}]xfade=transition=fade:duration={PASSAGEM}:offset={off:.3f}[x{i}]")
        atual = f"x{i}"

    saida = os.path.join(a.pasta, "ia_completo.mp4")
    cmd = ["ffmpeg", "-v", "error", "-y"] + ent + ["-ss", str(inicio0), "-i", info["original"],
           "-filter_complex", ";".join(filtros), "-map", f"[{atual}]"]
    if info.get("tem_audio", True):
        cmd += ["-map", f"{len(res)}:a:0", "-c:a", "aac", "-b:a", "192k"]
    cmd += ["-t", f"{total:.3f}", "-c:v", "libx264", "-crf", "17", "-preset", "slow", "-pix_fmt", "yuv420p",
            "-movflags", "+faststart", saida]
    rodar(cmd)
    folha(info["original"], saida, total, info.get("orientacao", "deitado") == "deitado", os.path.join(a.pasta, "conferencia.png"))
    print(f"OK: {saida} ({duracao(saida):.2f}s, {W}x{H})")
    print(f"Conferência: {os.path.join(a.pasta, 'conferencia.png')} (cima = original, baixo = IA)")


if __name__ == "__main__":
    main()
