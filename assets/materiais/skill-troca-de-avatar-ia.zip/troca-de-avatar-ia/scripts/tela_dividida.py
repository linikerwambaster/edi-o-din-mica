#!/usr/bin/env python3
"""Passo 5 (opcional): tela dividida, original em cima e IA embaixo, sincronizados, com o som original.

Formatos:
    deitado  -> os dois vídeos INTEIROS no formato do original, um em cima do outro (sem cortar nada)
    vertical -> 1080x1920 (Reels/TikTok), cada metade 1080x960 com corte no centro

Uso:
    python tela_dividida.py --pasta troca_avatar [--formato deitado|vertical] [--ia-em-cima]
    python tela_dividida.py --original meu_video.mp4 --ia ia_sincronizado.mp4 --saida final.mp4

Gera: <pasta>/tela_dividida_<formato>.mp4
"""
import argparse, json, os, subprocess, sys, tempfile


def rodar(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit("Erro no ffmpeg/ffprobe:\n" + r.stderr[-2000:])
    return r.stdout


def duracao(arq):
    return float(rodar(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", arq]).strip())


def dims_reais(arq):
    """Largura x altura como o vídeo aparece (já com a rotação do celular)."""
    fd, png = tempfile.mkstemp(suffix=".png")
    os.close(fd)
    try:
        rodar(["ffmpeg", "-v", "error", "-y", "-i", arq, "-frames:v", "1", png])
        s = rodar(["ffprobe", "-v", "error", "-show_entries", "stream=width,height", "-of", "csv=p=0", png]).strip().split(",")
        return int(s[0]), int(s[1])
    finally:
        os.remove(png)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pasta", default="troca_avatar")
    ap.add_argument("--original")
    ap.add_argument("--ia")
    ap.add_argument("--saida")
    ap.add_argument("--formato", choices=["deitado", "vertical"], default="deitado")
    ap.add_argument("--ia-em-cima", action="store_true")
    a = ap.parse_args()

    info = {}
    cj = os.path.join(a.pasta, "cortes.json")
    if os.path.exists(cj):
        info = json.load(open(cj, encoding="utf-8"))
    original = a.original or info.get("original")
    ia = a.ia or os.path.join(a.pasta, "ia_sincronizado.mp4")
    if not os.path.exists(ia):
        ia = os.path.join(a.pasta, "ia_completo.mp4")
    saida = a.saida or os.path.join(a.pasta, f"tela_dividida_{a.formato}.mp4")
    inicio = info.get("cortes", [[0, 0]])[0][0]

    if a.formato == "vertical":
        LW, LH = 1080, 960
    else:
        wo, ho = dims_reais(original)
        wi, _ = dims_reais(ia)
        LW = max(wi, 720) // 2 * 2
        LH = int(round(LW * ho / wo / 2)) * 2

    def metade(i):
        return (f"[{i}:v]scale={LW}:{LH}:force_original_aspect_ratio=increase:flags=lanczos,"
                f"crop={LW}:{LH},fps=30,setsar=1,setpts=PTS-STARTPTS")

    total = min(duracao(ia), duracao(original) - inicio)
    ordem = "[i][o]" if a.ia_em_cima else "[o][i]"
    filtro = f"{metade(0)}[o];{metade(1)}[i];{ordem}vstack[v]"
    cmd = ["ffmpeg", "-v", "error", "-y", "-ss", str(inicio), "-i", original, "-i", ia,
           "-filter_complex", filtro, "-map", "[v]", "-map", "0:a:0?", "-t", f"{total:.3f}",
           "-c:v", "libx264", "-crf", "18", "-preset", "slow", "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", saida]
    rodar(cmd)
    print(f"OK: {saida} ({LW}x{LH * 2}, {total:.2f}s) | {'IA em cima' if a.ia_em_cima else 'original em cima'}")


if __name__ == "__main__":
    main()
